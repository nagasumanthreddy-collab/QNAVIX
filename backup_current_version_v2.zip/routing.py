import math
import requests
import json
import time

def haversine_distance(lat1, lon1, lat2, lon2):
    """Calculate Great Circle distance in kilometers."""
    R = 6371.0  # Earth's radius in km
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat / 2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c

def get_traffic_profile(traffic_condition="auto", hour=10):
    """
    Returns realistic Indian city road traffic profile:
    multiplier, congestion level, hex color, extra fuel penalty, and description.
    """
    tc = str(traffic_condition or "auto").lower()
    if tc == "peak_morning":
        return {"multiplier": 1.65, "level": "Heavy Congestion", "color": "#ef4444", "fuel_penalty": 0.22, "desc": "Morning Peak Rush Hour (08:30-11:30 AM)"}
    elif tc == "moderate_midday":
        return {"multiplier": 1.25, "level": "Moderate Traffic", "color": "#f59e0b", "fuel_penalty": 0.08, "desc": "Midday Arterial Traffic (12:00-04:30 PM)"}
    elif tc == "peak_evening":
        return {"multiplier": 1.75, "level": "Severe Congestion", "color": "#dc2626", "fuel_penalty": 0.25, "desc": "Evening Peak Commuter Gridlock (05:00-08:30 PM)"}
    elif tc == "monsoon_rain":
        return {"multiplier": 1.85, "level": "Monsoon / Rain Delay", "color": "#9333ea", "fuel_penalty": 0.28, "desc": "Waterlogging & Rainy Weather Delay"}
    elif tc == "free_flow":
        return {"multiplier": 1.05, "level": "Free Flow", "color": "#10b981", "fuel_penalty": 0.0, "desc": "Late Night / Early Morning Express"}
    else:
        # Dynamic AI prediction based on departure hour in Indian metros
        if 8 <= hour <= 11:
            return {"multiplier": 1.62, "level": "Morning Peak Congestion", "color": "#ef4444", "fuel_penalty": 0.20, "desc": "AI Detected: Morning Office Rush Hour"}
        elif 17 <= hour <= 20:
            return {"multiplier": 1.72, "level": "Evening Peak Gridlock", "color": "#dc2626", "fuel_penalty": 0.24, "desc": "AI Detected: Evening Commuter Peak"}
        elif 12 <= hour <= 16:
            return {"multiplier": 1.25, "level": "Moderate Flow", "color": "#f59e0b", "fuel_penalty": 0.08, "desc": "AI Detected: Normal Afternoon Traffic"}
        else:
            return {"multiplier": 1.08, "level": "Smooth Flow", "color": "#10b981", "fuel_penalty": 0.02, "desc": "AI Detected: Off-Peak Express Flow"}

def get_indian_traffic_multiplier(hour=11):
    return get_traffic_profile("auto", hour)["multiplier"]

class RoutingService:
    def __init__(self, google_api_key=None):
        self.google_api_key = google_api_key

    def get_route_segment(self, start_lat, start_lng, end_lat, end_lng, departure_hour=10, traffic_condition="auto"):
        """
        Get road route between two points with traffic delay and congestion profile.
        """
        traffic = get_traffic_profile(traffic_condition, departure_hour)
        traffic_factor = traffic["multiplier"]

        # Try OSRM driving service first
        try:
            url = f"https://router.project-osrm.org/route/v1/driving/{start_lng},{start_lat};{end_lng},{end_lat}?overview=full&geometries=geojson"
            res = requests.get(url, timeout=3.5)
            if res.status_code == 200:
                data = res.json()
                if data.get("code") == "Ok" and len(data.get("routes", [])) > 0:
                    route = data["routes"][0]
                    distance_km = round(route["distance"] / 1000.0, 2)
                    base_duration_min = round(route["duration"] / 60.0, 1)
                    duration_min = round(base_duration_min * traffic_factor, 1)
                    traffic_delay = max(0.0, round(duration_min - base_duration_min, 1))
                    
                    coordinates = route["geometry"]["coordinates"]
                    points = [[c[1], c[0]] for c in coordinates]
                    return {
                        "distance_km": distance_km,
                        "duration_minutes": duration_min,
                        "traffic_delay_minutes": traffic_delay,
                        "traffic_level": traffic["level"],
                        "traffic_color": traffic["color"],
                        "traffic_desc": traffic["desc"],
                        "fuel_penalty_factor": traffic["fuel_penalty"],
                        "polyline": points,
                        "source": "osrm"
                    }
        except Exception:
            pass

        # Google Routes API if key is available
        if self.google_api_key:
            try:
                url = (
                    f"https://maps.googleapis.com/maps/api/directions/json?"
                    f"origin={start_lat},{start_lng}&destination={end_lat},{end_lng}&key={self.google_api_key}"
                )
                res = requests.get(url, timeout=3)
                if res.status_code == 200:
                    gdata = res.json()
                    if gdata.get("status") == "OK" and len(gdata.get("routes", [])) > 0:
                        route = gdata["routes"][0]
                        leg = route["legs"][0]
                        dist_km = round(leg["distance"]["value"] / 1000.0, 2)
                        dur_min = round(leg["duration"]["value"] / 60.0, 1)
                        # We can extract step polyline or simple interpolation
                        points = [[start_lat, start_lng], [end_lat, end_lng]]
                        return {
                            "distance_km": dist_km,
                            "duration_minutes": dur_min,
                            "polyline": points,
                            "source": "google"
                        }
            except Exception:
                pass

        # High-Fidelity Indian Road Model Fallback
        straight_km = haversine_distance(start_lat, start_lng, end_lat, end_lng)
        road_detour = 1.28
        distance_km = round(max(0.5, straight_km * road_detour), 2)
        
        # Average Indian city/arterial speed: ~32 km/h modulated by traffic
        base_speed_kmh = 32.0
        avg_speed_kmh = max(12.0, base_speed_kmh / traffic_factor)
        duration_minutes = round((distance_km / avg_speed_kmh) * 60.0, 1)
        base_duration = round((distance_km / base_speed_kmh) * 60.0, 1)
        traffic_delay = max(0.0, round(duration_minutes - base_duration, 1))

        # Generate realistic intermediate road waypoints with road curvature
        steps = max(5, int(straight_km * 2))
        points = []
        for i in range(steps + 1):
            t = i / steps
            curve = math.sin(t * math.pi) * 0.0035 * (1 if (int(start_lat * 100) % 2 == 0) else -1)
            lat = start_lat + (end_lat - start_lat) * t + curve
            lng = start_lng + (end_lng - start_lng) * t - curve * 0.5
            points.append([round(lat, 6), round(lng, 6)])

        return {
            "distance_km": distance_km,
            "duration_minutes": duration_minutes,
            "traffic_delay_minutes": traffic_delay,
            "traffic_level": traffic["level"],
            "traffic_color": traffic["color"],
            "traffic_desc": traffic["desc"],
            "fuel_penalty_factor": traffic["fuel_penalty"],
            "polyline": points,
            "source": "road_model"
        }

    def build_full_route(self, stops, departure_hour=9, traffic_condition="auto"):
        """
        Build full sequential route through list of stops with Indian traffic prediction:
        stops: list of dicts with 'lat', 'lng', 'name', 'type', 'id', 'weight', 'timeWindowStart', etc.
        """
        if not stops or len(stops) < 2:
            return {
                "total_distance_km": 0,
                "total_duration_minutes": 0,
                "total_traffic_delay_minutes": 0,
                "traffic_summary": "No traffic delay",
                "segments": [],
                "full_polyline": []
            }

        total_dist = 0.0
        total_dur = 0.0
        total_traffic_delay = 0.0
        segments = []
        full_polyline = []
        overall_traffic = get_traffic_profile(traffic_condition, departure_hour)

        for i in range(len(stops) - 1):
            s1 = stops[i]
            s2 = stops[i + 1]
            # Adjust departure hour as delivery route progresses
            hour_estimate = int(departure_hour + (total_dur / 60.0)) % 24
            seg = self.get_route_segment(s1['lat'], s1['lng'], s2['lat'], s2['lng'], hour_estimate, traffic_condition)
            
            total_dist += seg['distance_km']
            total_dur += seg['duration_minutes']
            total_traffic_delay += seg.get('traffic_delay_minutes', 0.0)
            
            # Add service time if stopping at a delivery
            service_time = s2.get('serviceTime', 10) if s2.get('type') == 'delivery' else 0
            
            segments.append({
                "from_index": i,
                "to_index": i + 1,
                "from_name": s1.get('name', f"Stop {i}"),
                "to_name": s2.get('name', f"Stop {i+1}"),
                "distance_km": seg['distance_km'],
                "duration_minutes": seg['duration_minutes'],
                "traffic_delay_minutes": seg.get('traffic_delay_minutes', 0.0),
                "traffic_level": seg.get('traffic_level', overall_traffic['level']),
                "traffic_color": seg.get('traffic_color', overall_traffic['color']),
                "traffic_desc": seg.get('traffic_desc', overall_traffic['desc']),
                "fuel_penalty_factor": seg.get('fuel_penalty_factor', 0.0),
                "service_time": service_time,
                "polyline": seg['polyline']
            })
            
            # Combine polyline smoothly without duplicate endpoints
            if not full_polyline:
                full_polyline.extend(seg['polyline'])
            else:
                full_polyline.extend(seg['polyline'][1:])

        return {
            "total_distance_km": round(total_dist, 2),
            "total_duration_minutes": round(total_dur, 1),
            "total_traffic_delay_minutes": round(total_traffic_delay, 1),
            "traffic_condition": traffic_condition,
            "traffic_summary": f"{overall_traffic['level']} (+{round(total_traffic_delay)} mins delay)",
            "traffic_color": overall_traffic['color'],
            "fuel_penalty_percent": round(overall_traffic['fuel_penalty'] * 100, 1),
            "segments": segments,
            "full_polyline": full_polyline
        }
