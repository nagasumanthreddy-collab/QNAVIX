import sqlite3
import os
import json

DB_PATH = os.path.join(os.path.dirname(__file__), 'logistics.db')

# Comprehensive seed of 50+ major Indian logistics hubs and industrial depots
DEFAULT_DEPOTS = [
    {"name": "Delhi Central Distribution Hub", "city": "Delhi", "state": "Delhi", "address": "Okhla Industrial Area Phase-III, New Delhi", "lat": 28.5355, "lng": 77.2731, "type": "Main Distribution Center", "capacity": 150000},
    {"name": "Gurugram Logistics Logistics Park", "city": "Gurugram", "state": "Haryana", "address": "Binola Industrial Area, NH-48, Gurugram", "lat": 28.3242, "lng": 76.8716, "type": "Regional Warehouse", "capacity": 120000},
    {"name": "Noida Fulfillment Hub", "city": "Noida", "state": "Uttar Pradesh", "address": "Sector 63 Logistics Zone, Noida", "lat": 28.6219, "lng": 77.3812, "type": "Fulfillment Center", "capacity": 80000},
    {"name": "Faridabad Supply Depot", "city": "Faridabad", "state": "Haryana", "address": "Sector 24 Industrial Hub, Faridabad", "lat": 28.3846, "lng": 77.3159, "type": "Cross-Dock", "capacity": 60000},
    {"name": "Mumbai Port & Logistics Terminal", "city": "Mumbai", "state": "Maharashtra", "address": "Bhiwandi Logistics Park, Mumbai MMR", "lat": 19.2967, "lng": 73.0631, "type": "Main Distribution Center", "capacity": 200000},
    {"name": "Navi Mumbai Cargo Hub", "city": "Navi Mumbai", "state": "Maharashtra", "address": "Taloja MIDC, Navi Mumbai", "lat": 19.0558, "lng": 73.1256, "type": "Regional Warehouse", "capacity": 110000},
    {"name": "Pune Auto & Cargo Hub", "city": "Pune", "state": "Maharashtra", "address": "Chakan MIDC Industrial Area, Pune", "lat": 18.7606, "lng": 73.8636, "type": "Regional Warehouse", "capacity": 95000},
    {"name": "Nashik Distribution Center", "city": "Nashik", "state": "Maharashtra", "address": "Ambad MIDC, Nashik", "lat": 19.9572, "lng": 73.7314, "type": "City Warehouse", "capacity": 50000},
    {"name": "Nagpur Multimodal Logistics Hub (MIHAN)", "city": "Nagpur", "state": "Maharashtra", "address": "MIHAN SEZ Logistics Park, Nagpur", "lat": 21.0543, "lng": 79.0345, "type": "Main Distribution Center", "capacity": 180000},
    {"name": "Aurangabad Logistics Hub", "city": "Aurangabad", "state": "Maharashtra", "address": "Waluj MIDC, Chhatrapati Sambhajinagar", "lat": 19.8398, "lng": 75.2504, "type": "City Warehouse", "capacity": 45000},
    {"name": "Bengaluru E-Commerce Mega Hub", "city": "Bengaluru", "state": "Karnataka", "address": "Hosakote Logistics Cluster, Bengaluru", "lat": 13.0699, "lng": 77.7981, "type": "Main Distribution Center", "capacity": 160000},
    {"name": "Bengaluru South Micro Hub", "city": "Bengaluru", "state": "Karnataka", "address": "Bommasandra Industrial Area, Electronic City", "lat": 12.8164, "lng": 77.6923, "type": "Micro Hub", "capacity": 40000},
    {"name": "Mysuru Supply Depot", "city": "Mysuru", "state": "Karnataka", "address": "Hebbal Industrial Area, Mysuru", "lat": 12.3653, "lng": 76.6111, "type": "City Warehouse", "capacity": 45000},
    {"name": "Mangaluru Port Hub", "city": "Mangaluru", "state": "Karnataka", "address": "Baikampady Industrial Estate, Mangaluru", "lat": 12.9463, "lng": 74.8219, "type": "Regional Warehouse", "capacity": 70000},
    {"name": "Hyderabad Gateway Logistics Hub", "city": "Hyderabad", "state": "Telangana", "address": "Shamshabad Cargo Airport Corridor, Hyderabad", "lat": 17.2403, "lng": 78.4294, "type": "Main Distribution Center", "capacity": 140000},
    {"name": "Hyderabad Medchal Logistics Center", "city": "Hyderabad", "state": "Telangana", "address": "Medchal Industrial Area, NH-44, Hyderabad", "lat": 17.6297, "lng": 78.4814, "type": "Regional Warehouse", "capacity": 90000},
    {"name": "Vijayawada Logistics Cluster", "city": "Vijayawada", "state": "Andhra Pradesh", "address": "Gannavaram Highway Hub, Vijayawada", "lat": 16.5413, "lng": 80.7963, "type": "Regional Warehouse", "capacity": 65000},
    {"name": "Visakhapatnam Port Logistics Hub", "city": "Visakhapatnam", "state": "Andhra Pradesh", "address": "Autonagar Industrial Area, Visakhapatnam", "lat": 17.6974, "lng": 83.2104, "type": "Regional Warehouse", "capacity": 85000},
    {"name": "Guntur Agri & Cargo Center", "city": "Guntur", "state": "Andhra Pradesh", "address": "Autonagar, Nallapadu, Guntur", "lat": 16.2942, "lng": 80.4079, "type": "City Warehouse", "capacity": 50000},
    {"name": "Chennai Port Logistics Hub", "city": "Chennai", "state": "Tamil Nadu", "address": "Sriperumbudur Industrial Corridor, Chennai", "lat": 12.9675, "lng": 79.9405, "type": "Main Distribution Center", "capacity": 175000},
    {"name": "Chennai North Container Freight Hub", "city": "Chennai", "state": "Tamil Nadu", "address": "Madhavaram Logistics Park, Chennai", "lat": 13.1534, "lng": 80.2312, "type": "Fulfillment Center", "capacity": 75000},
    {"name": "Coimbatore Industrial Supply Hub", "city": "Coimbatore", "state": "Tamil Nadu", "address": "Peelamedu Logistics Corridor, Coimbatore", "lat": 11.0311, "lng": 77.0194, "type": "Regional Warehouse", "capacity": 60000},
    {"name": "Madurai South Hub", "city": "Madurai", "state": "Tamil Nadu", "address": "Kappalur Industrial Area, Madurai", "lat": 9.8705, "lng": 78.0436, "type": "City Warehouse", "capacity": 40000},
    {"name": "Tiruchirappalli Cargo Hub", "city": "Tiruchirappalli", "state": "Tamil Nadu", "address": "Thuvakudi Industrial Estate, Trichy", "lat": 10.7602, "lng": 78.8049, "type": "City Warehouse", "capacity": 38000},
    {"name": "Kolkata Eastern Logistics Gateway", "city": "Kolkata", "state": "West Bengal", "address": "Dankuni Industrial & Freight Corridor, Kolkata", "lat": 22.6845, "lng": 88.2917, "type": "Main Distribution Center", "capacity": 150000},
    {"name": "Kolkata Port Logistics Zone", "city": "Kolkata", "state": "West Bengal", "address": "Taratala Road Cargo Terminal, Kolkata", "lat": 22.5085, "lng": 88.3129, "type": "Regional Warehouse", "capacity": 70000},
    {"name": "Ahmedabad Logistics Hub", "city": "Ahmedabad", "state": "Gujarat", "address": "Changodar Industrial Area, Sanand Road, Ahmedabad", "lat": 22.9238, "lng": 72.4418, "type": "Main Distribution Center", "capacity": 130000},
    {"name": "Surat Diamond & Textile Cargo Hub", "city": "Surat", "state": "Gujarat", "address": "Sachin GIDC Industrial Area, Surat", "lat": 21.0827, "lng": 72.8687, "type": "Regional Warehouse", "capacity": 85000},
    {"name": "Vadodara Industrial Depot", "city": "Vadodara", "state": "Gujarat", "address": "Makarpura GIDC, Vadodara", "lat": 22.2536, "lng": 73.1952, "type": "City Warehouse", "capacity": 55000},
    {"name": "Rajkot Engineering Logistics Center", "city": "Rajkot", "state": "Gujarat", "address": "Shapar-Veraval Industrial Area, Rajkot", "lat": 22.1812, "lng": 70.7818, "type": "City Warehouse", "capacity": 42000},
    {"name": "Jaipur Express Logistics Hub", "city": "Jaipur", "state": "Rajasthan", "address": "VKI Industrial Area, Sikar Road, Jaipur", "lat": 26.9859, "lng": 75.7725, "type": "Regional Warehouse", "capacity": 80000},
    {"name": "Lucknow Freight Depot", "city": "Lucknow", "state": "Uttar Pradesh", "address": "Transport Nagar, Kanpur Road, Lucknow", "lat": 26.7901, "lng": 80.8924, "type": "Regional Warehouse", "capacity": 75000},
    {"name": "Kanpur Logistics Cluster", "city": "Kanpur", "state": "Uttar Pradesh", "address": "Panki Industrial Area, Kanpur", "lat": 26.4716, "lng": 80.2452, "type": "City Warehouse", "capacity": 65000},
    {"name": "Agra Express Freight Center", "city": "Agra", "state": "Uttar Pradesh", "address": "Sikandra Industrial Area, Agra", "lat": 27.2195, "lng": 77.9392, "type": "City Warehouse", "capacity": 45000},
    {"name": "Varanasi Eastern Cargo Hub", "city": "Varanasi", "state": "Uttar Pradesh", "address": "Ramnagar Industrial Area, Varanasi", "lat": 25.2758, "lng": 83.0298, "type": "City Warehouse", "capacity": 50000},
    {"name": "Indore Central India Logistics Center", "city": "Indore", "state": "Madhya Pradesh", "address": "Pithampur Sector 3 Logistics Park, Indore", "lat": 22.6186, "lng": 75.6881, "type": "Regional Warehouse", "capacity": 90000},
    {"name": "Bhopal Supply Depot", "city": "Bhopal", "state": "Madhya Pradesh", "address": "Govindpura Industrial Area, Bhopal", "lat": 23.2558, "lng": 77.4589, "type": "City Warehouse", "capacity": 48000},
    {"name": "Patna Ganga Logistics Terminal", "city": "Patna", "state": "Bihar", "address": "Fatuha Industrial Area, NH-30, Patna", "lat": 25.5034, "lng": 85.3129, "type": "Regional Warehouse", "capacity": 60000},
    {"name": "Kochi International Container & Cargo Hub", "city": "Kochi", "state": "Kerala", "address": "Kalamassery Industrial Belt, Kochi", "lat": 10.0528, "lng": 76.3242, "type": "Regional Warehouse", "capacity": 70000},
    {"name": "Thiruvananthapuram Tech Logistics Hub", "city": "Thiruvananthapuram", "state": "Kerala", "address": "Kazhakkoottam Technopark Corridor, Trivandrum", "lat": 8.5686, "lng": 76.8731, "type": "City Warehouse", "capacity": 35000},
    {"name": "Chandigarh Tricity Logistics Park", "city": "Chandigarh", "state": "Punjab", "address": "Industrial Area Phase 1, Chandigarh", "lat": 30.7046, "lng": 76.7989, "type": "Regional Warehouse", "capacity": 65000},
    {"name": "Ludhiana Cargo & Textile Terminal", "city": "Ludhiana", "state": "Punjab", "address": "Focal Point Phase-V, Ludhiana", "lat": 30.8793, "lng": 75.9126, "type": "Regional Warehouse", "capacity": 80000},
    {"name": "Amritsar Border Freight Depot", "city": "Amritsar", "state": "Punjab", "address": "GT Road Logistics Corridor, Amritsar", "lat": 31.6340, "lng": 74.8723, "type": "City Warehouse", "capacity": 40000},
    {"name": "Ranchi Chota Nagpur Cargo Hub", "city": "Ranchi", "state": "Jharkhand", "address": "Tupudana Industrial Area, Ranchi", "lat": 23.2942, "lng": 85.3056, "type": "City Warehouse", "capacity": 45000},
    {"name": "Bhubaneswar Kalinga Logistics Hub", "city": "Bhubaneswar", "state": "Odisha", "address": "Mancheswar Industrial Estate, Bhubaneswar", "lat": 20.3246, "lng": 85.8491, "type": "Regional Warehouse", "capacity": 60000},
    {"name": "Guwahati Northeast Gateway Hub", "city": "Guwahati", "state": "Assam", "address": "Amingaon Inland Container Depot, Guwahati", "lat": 26.1844, "lng": 91.6811, "type": "Regional Warehouse", "capacity": 65000},
    {"name": "Raipur Central Logistics Hub", "city": "Raipur", "state": "Chhattisgarh", "address": "Urla Industrial Area, Raipur", "lat": 21.3129, "lng": 81.6023, "type": "City Warehouse", "capacity": 55000},
    {"name": "Dehradun Himalayan Gateway Depot", "city": "Dehradun", "state": "Uttarakhand", "address": "Patel Nagar Industrial Corridor, Dehradun", "lat": 30.3165, "lng": 78.0322, "type": "City Warehouse", "capacity": 30000},
    {"name": "Jammu Logistics Freight Center", "city": "Jammu", "state": "Jammu and Kashmir", "address": "Bari Brahmana Industrial Complex, Jammu", "lat": 32.6412, "lng": 74.9197, "type": "City Warehouse", "capacity": 38000},
    {"name": "Srinagar Valley Distribution Depot", "city": "Srinagar", "state": "Jammu and Kashmir", "address": "Rangreth Industrial Estate, Srinagar", "lat": 33.9984, "lng": 74.7924, "type": "City Warehouse", "capacity": 25000}
]

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cursor = conn.cursor()

    # Depots table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS depots (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        city TEXT NOT NULL,
        state TEXT NOT NULL,
        country TEXT DEFAULT 'India',
        address TEXT NOT NULL,
        latitude REAL NOT NULL,
        longitude REAL NOT NULL,
        depotType TEXT NOT NULL,
        capacity INTEGER DEFAULT 100000,
        active INTEGER DEFAULT 1
    )
    ''')

    # Drivers table (automatically generated fictional drivers)
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS drivers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        driverId TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        age INTEGER NOT NULL,
        experience INTEGER NOT NULL,
        phone TEXT NOT NULL,
        licenseType TEXT NOT NULL,
        rating REAL NOT NULL,
        vehicleId TEXT,
        status TEXT DEFAULT 'Active'
    )
    ''')

    # Vehicles table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS vehicles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        vehicleId TEXT UNIQUE NOT NULL,
        vehicleType TEXT NOT NULL,
        capacity REAL NOT NULL,
        currentLoad REAL DEFAULT 0,
        fuelType TEXT NOT NULL,
        fuelEfficiency REAL NOT NULL,
        fuelTankCapacity REAL NOT NULL,
        maximumRange REAL NOT NULL,
        depotId INTEGER,
        driverId TEXT,
        status TEXT DEFAULT 'Available',
        currentLatitude REAL,
        currentLongitude REAL,
        FOREIGN KEY (depotId) REFERENCES depots(id),
        FOREIGN KEY (driverId) REFERENCES drivers(driverId)
    )
    ''')

    # Deliveries table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS deliveries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        orderId TEXT UNIQUE NOT NULL,
        customerName TEXT NOT NULL,
        address TEXT NOT NULL,
        latitude REAL NOT NULL,
        longitude REAL NOT NULL,
        product TEXT NOT NULL,
        quantity INTEGER NOT NULL,
        weight REAL NOT NULL,
        priority TEXT DEFAULT 'Medium',
        timeWindowStart TEXT DEFAULT '09:00',
        timeWindowEnd TEXT DEFAULT '18:00',
        serviceTime INTEGER DEFAULT 10,
        assignedVehicle TEXT,
        status TEXT DEFAULT 'Pending',
        eta TEXT
    )
    ''')

    # Routes table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS routes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        vehicleId TEXT NOT NULL,
        depotId INTEGER NOT NULL,
        totalDistance REAL NOT NULL,
        travelTime REAL NOT NULL,
        fuelUsed REAL NOT NULL,
        fuelCost REAL NOT NULL,
        co2 REAL NOT NULL,
        routeStatus TEXT DEFAULT 'Planned',
        polyline TEXT,
        createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    ''')

    # Route stops table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS route_stops (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        routeId INTEGER NOT NULL,
        sequence INTEGER NOT NULL,
        deliveryId INTEGER,
        stopType TEXT DEFAULT 'delivery',
        latitude REAL NOT NULL,
        longitude REAL NOT NULL,
        name TEXT NOT NULL,
        address TEXT,
        arrivalTime TEXT,
        departureTime TEXT,
        distanceFromPrevious REAL DEFAULT 0,
        travelTimeFromPrevious REAL DEFAULT 0,
        status TEXT DEFAULT 'Scheduled',
        FOREIGN KEY (routeId) REFERENCES routes(id)
    )
    ''')

    # App Settings & Fuel Prices
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
    )
    ''')

    # Seed depots if empty
    cursor.execute('SELECT COUNT(*) FROM depots')
    count = cursor.fetchone()[0]
    if count == 0:
        for d in DEFAULT_DEPOTS:
            cursor.execute('''
            INSERT INTO depots (name, city, state, country, address, latitude, longitude, depotType, capacity, active)
            VALUES (?, ?, ?, 'India', ?, ?, ?, ?, ?, 1)
            ''', (d['name'], d['city'], d['state'], d['address'], d['lat'], d['lng'], d['type'], d['capacity']))

    # Default settings
    default_settings = {
        'price_diesel': '92.50',
        'price_petrol': '104.20',
        'price_cng': '86.50',
        'price_electric': '12.00',
        'emission_diesel': '2.68',   # kg CO2 / L
        'emission_petrol': '2.31',   # kg CO2 / L
        'emission_cng': '1.82',      # kg CO2 / kg
        'emission_electric': '0.45', # kg CO2 / kWh
        'google_maps_api_key': '',
        'automatic_depot_assignment': '0'
    }
    for k, v in default_settings.items():
        cursor.execute('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)', (k, v))

    conn.commit()
    conn.close()

if __name__ == '__main__':
    init_db()
    print("Database initialized successfully!")
