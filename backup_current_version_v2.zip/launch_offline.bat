@echo off
title QNAVIX — Quantum Route Intelligence (Offline Launcher)
color 0B
cls
echo =====================================================================
echo           QNAVIX - Quantum Route Intelligence (Offline Edition)
echo =====================================================================
echo.
echo  Initializing QNAVIX Last-Mile Dispatch System in Offline Mode...
echo.

:: Check if Python is available
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [NOTE] Python environment not detected.
    echo Starting QNAVIX in Standalone In-Browser Engine mode...
    start "" "%~dp0static\index.html"
    exit /b
)

:: Python is present, start local server
echo [OK] Python detected. Starting local offline web server on http://127.0.0.1:5000 ...
start "QNAVIX Offline Server" /min python "%~dp0app.py"

:: Wait 2 seconds for server boot
timeout /t 2 /nobreak >nul

:: Open browser
echo [OK] Opening QNAVIX Command Center in your default browser...
start http://127.0.0.1:5000

echo.
echo =====================================================================
echo  QNAVIX is now running offline! 
echo  Access URL: http://127.0.0.1:5000
echo  Keep this terminal window open while using the platform.
echo =====================================================================
echo.
pause
