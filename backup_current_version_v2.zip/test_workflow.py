import unittest
import json
import os
from app import app
from database import init_db, get_db

class TestLogisticsPlatform(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        init_db()
        cls.client = app.test_client()

    def setUp(self):
        # Reset database before tests
        self.client.post('/api/reset')

    def test_01_initial_empty_state(self):
        """Master Prompt Section 47: Empty application state initially (Vehicles: 0, Deliveries: 0)."""
        res_v = self.client.get('/api/vehicles')
        self.assertEqual(res_v.status_code, 200)
        self.assertEqual(len(res_v.json['vehicles']), 0)

        res_d = self.client.get('/api/deliveries')
        self.assertEqual(res_d.status_code, 200)
        self.assertEqual(len(res_d.json['deliveries']), 0)

    def test_02_india_depots_available(self):
        """Master Prompt Section 4: 50+ depots across major Indian cities."""
        res = self.client.get('/api/depots')
        self.assertEqual(res.status_code, 200)
        depots = res.json['depots']
        self.assertGreaterEqual(len(depots), 40)
        
        cities = [d['city'] for d in depots]
        for expected_city in ['Delhi', 'Mumbai', 'Bengaluru', 'Hyderabad', 'Chennai', 'Kolkata', 'Pune', 'Ahmedabad']:
            self.assertIn(expected_city, cities)

    def test_03_acceptance_test_1_to_15(self):
        """Systematic test of Acceptance Criteria #1 through #15."""
        
        # Test 1 & 2: User enters 2 vehicles and selects Mumbai Depot
        # Find Mumbai depot
        res_depots = self.client.get('/api/depots?city=Mumbai')
        mumbai_depot = res_depots.json['depots'][0]
        mumbai_depot_id = mumbai_depot['id']

        # Generate 2 vehicles
        res_gen = self.client.post('/api/vehicles/generate', json={
            'count': 2,
            'depotId': mumbai_depot_id,
            'vehicleType': 'Van',
            'capacity': 1000,
            'fuelType': 'Diesel',
            'fuelEfficiency': 14.0
        })
        self.assertEqual(res_gen.status_code, 200)
        self.assertEqual(len(res_gen.json['created']), 2)
        
        # Verify driver information was automatically generated
        driver1 = res_gen.json['created'][0]['driver']
        self.assertTrue(driver1['name'])
        self.assertTrue(driver1['phone'].startswith('+91-'))
        self.assertTrue(driver1['driverId'].startswith('DRV-'))
        print(f"[PASS] Test 1: 2 vehicles created with auto-generated driver '{driver1['name']}' ({driver1['phone']})")
        print(f"[PASS] Test 2: Starting depot set to '{mumbai_depot['name']}' in Mumbai")

        # Test 3 & 4: User adds 5 delivery locations
        test_deliveries = [
            {"customerName": "Reliance Retail Hub", "address": "BKC Bandra Kurla Complex, Mumbai", "weight": 35, "priority": "Critical"},
            {"customerName": "Amazon Fulfillment", "address": "Andheri East MIDC, Mumbai", "weight": 40, "priority": "High"},
            {"customerName": "Tata Consumer Store", "address": "Hiranandani Gardens, Powai, Mumbai", "weight": 25, "priority": "Medium"},
            {"customerName": "DMart Megastore", "address": "Thane West Commercial Center, Maharashtra", "weight": 110, "priority": "High"},
            {"customerName": "Flipkart Last-Mile", "address": "Vashi Commercial Sector, Navi Mumbai", "weight": 45, "priority": "Medium"}
        ]

        created_deliv_ids = []
        for d in test_deliveries:
            res_d = self.client.post('/api/deliveries', json=d)
            self.assertEqual(res_d.status_code, 200)
            deliv_item = res_d.json['delivery']
            self.assertIsNotNone(deliv_item['latitude'])
            self.assertIsNotNone(deliv_item['longitude'])
            created_deliv_ids.append(deliv_item['id'])

        self.assertEqual(len(created_deliv_ids), 5)
        print("[PASS] Test 3 & 4: 5 delivery locations added and geocoded on map")

        # Test 5 & 6 & 7: Optimize Routes -> System generates routes automatically
        res_opt = self.client.post('/api/optimize', json={'autoDepot': False})
        self.assertEqual(res_opt.status_code, 200)
        opt_data = res_opt.json
        self.assertTrue(opt_data['success'])
        
        routes = opt_data['routes']
        self.assertEqual(len(routes), 2)
        print("[PASS] Test 5 & 6: Optimizer generated routes dynamically")

        # Test 7: Verify different route colors
        colors = [r['color'] for r in routes]
        self.assertEqual(len(colors), len(set(colors)))
        print(f"[PASS] Test 7: Routes assigned unique distinguishable colors: {colors}")

        # Test 8: Route Details displays vehicle, driver, distance, time, fuel, fuel cost, load, capacity, stops
        r0 = routes[0]
        self.assertIn('vehicleId', r0)
        self.assertIn('driverId', r0)
        self.assertIn('totalDistanceKm', r0)
        self.assertGreater(r0['totalDistanceKm'], 0)
        self.assertIn('travelTimeMinutes', r0)
        self.assertIn('fuelUsedLiters', r0)
        self.assertIn('fuelCostInr', r0)
        self.assertIn('capacityKg', r0)
        self.assertIn('stops', r0)
        self.assertGreater(len(r0['stops']), 2)  # Depot -> stops -> Depot
        print(f"[PASS] Test 8: Route {r0['vehicleId']}: Dist={r0['totalDistanceKm']}km, Fuel={r0['fuelUsedLiters']}L, Cost=INR {r0['fuelCostInr']}, Stops={len(r0['stops'])}")

        # Test 9: Fuel analytics updates
        analytics = opt_data['analytics']
        self.assertGreater(analytics['totalFuelLiters'], 0)
        self.assertGreater(analytics['totalFuelCostInr'], 0)
        self.assertGreater(analytics['averageFuelEfficiency'], 0)
        print(f"[PASS] Test 9: Fuel Analytics total fuel={analytics['totalFuelLiters']}L, cost=INR {analytics['totalFuelCostInr']}")

        # Test 10: Delivery table updates
        res_delivs_after = self.client.get('/api/deliveries')
        for d in res_delivs_after.json['deliveries']:
            self.assertEqual(d['status'], 'In Transit')
            self.assertIsNotNone(d['assignedVehicle'])
            self.assertIsNotNone(d['eta'])
        print("[PASS] Test 10: Delivery table assigned vehicles and ETAs verified")

        # Test 11: Dashboard KPI cards update
        self.assertEqual(analytics['deliveryLocations'], 5)
        self.assertGreater(analytics['totalDistanceKm'], 0)
        print("[PASS] Test 11: KPI cards reflect real calculated metrics")

        # Test 12: User adds 6th delivery -> Re-optimize -> Recalculates
        res_d6 = self.client.post('/api/deliveries', json={
            "customerName": "Godrej Enterprise",
            "address": "Worli Sea Face Corridor, Mumbai",
            "weight": 20,
            "priority": "High"
        })
        self.assertEqual(res_d6.status_code, 200)
        res_reopt = self.client.post('/api/optimize', json={'autoDepot': False})
        self.assertEqual(res_reopt.status_code, 200)
        self.assertEqual(res_reopt.json['analytics']['deliveryLocations'], 6)
        print("[PASS] Test 12: Re-optimize successfully accommodated new delivery (Total 6)")

        # Test 13: User changes fuel price -> Fuel cost immediately recalculates
        # Update diesel price from 92.50 to 110.00
        old_cost = res_reopt.json['analytics']['totalFuelCostInr']
        self.client.post('/api/settings', json={'price_diesel': '110.00'})
        res_recalc = self.client.post('/api/recalculate')
        self.assertEqual(res_recalc.status_code, 200)
        new_cost = res_recalc.json['analytics']['totalFuelCostInr']
        self.assertGreater(new_cost, old_cost)
        print(f"[PASS] Test 13: Fuel price change from INR 92.50 to INR 110.00 recalculated cost: INR {old_cost} -> INR {new_cost}")

        # Test 14: User changes vehicle fuel efficiency -> Fuel and cost recalculate
        # Get vehicle 1 and change fuelEfficiency from 14.0 to 18.0 km/L
        v_list = self.client.get('/api/vehicles').json['vehicles']
        v1_id = v_list[0]['id']
        self.client.put(f'/api/vehicles/{v1_id}', json={'fuelEfficiency': 18.0})
        res_recalc2 = self.client.post('/api/recalculate')
        self.assertEqual(res_recalc2.status_code, 200)
        cost_after_eff = res_recalc2.json['analytics']['totalFuelCostInr']
        self.assertLess(cost_after_eff, new_cost)
        print(f"[PASS] Test 14: Fuel efficiency increased to 18 km/L -> fuel cost dropped: INR {new_cost} -> INR {cost_after_eff}")

        # Test 15: User changes depot -> Routes recalculate from new depot
        # Change depot to Pune
        res_pune = self.client.get('/api/depots?city=Pune')
        pune_depot_id = res_pune.json['depots'][0]['id']
        self.client.put(f'/api/vehicles/{v1_id}', json={'depotId': pune_depot_id})
        res_opt_pune = self.client.post('/api/optimize', json={'autoDepot': False})
        self.assertEqual(res_opt_pune.status_code, 200)
        route_depot_names = [r['depot']['city'] for r in res_opt_pune.json['routes']]
        self.assertIn('Pune', route_depot_names)
        print(f"[PASS] Test 15: Vehicle depot changed to Pune, routes successfully re-optimized with new depot")

if __name__ == '__main__':
    unittest.main()
