// QNAVIX Service Worker - Offline Progressive Web App Engine
const CACHE_NAME = 'qnavix-cache-v1';

const PRECACHE_ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './css/style.css',
  './js/offline_engine.js',
  './js/api.js',
  './js/map.js',
  './js/analytics.js',
  './js/app.js',
  './images/qnavix_logo.png',
  './vendor/leaflet/leaflet.js',
  './vendor/leaflet/leaflet.css',
  './vendor/leaflet/images/marker-icon.png',
  './vendor/leaflet/images/marker-icon-2x.png',
  './vendor/leaflet/images/marker-shadow.png',
  './vendor/chartjs/chart.umd.min.js'
];

// Install Event: Pre-cache core application shell
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('[QNAVIX SW] Pre-caching offline application shell...');
      return cache.addAll(PRECACHE_ASSETS).catch((err) => {
        console.warn('[QNAVIX SW] Pre-cache non-fatal warning:', err);
      });
    }).then(() => self.skipWaiting())
  );
});

// Activate Event: Remove legacy caches and claim clients immediately
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            console.log('[QNAVIX SW] Removing legacy cache:', key);
            return caches.delete(key);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

// Fetch Event: Cache-First for static assets; Network-First with cache fallback for others
self.addEventListener('fetch', (event) => {
  const req = event.request;
  const url = new URL(req.url);

  // Skip non-GET requests
  if (req.method !== 'GET') {
    return;
  }

  // Handle API requests: network first, let client-side OfflineEngine handle failures
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(
      fetch(req).catch(() => {
        // Return 503 so client-side API falls back to offline engine
        return new Response(JSON.stringify({ offline: true, error: 'Server unreachable. Local offline engine active.' }), {
          status: 503,
          headers: { 'Content-Type': 'application/json' }
        });
      })
    );
    return;
  }

  // Handle map tiles: cache dynamic tiles for offline navigation viewing
  if (url.hostname.includes('tile.openstreetmap.org') || url.hostname.includes('basemaps.cartocdn.com')) {
    event.respondWith(
      caches.match(req).then((cached) => {
        if (cached) return cached;
        return fetch(req).then((res) => {
          if (res && res.status === 200) {
            const resClone = res.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(req, resClone));
          }
          return res;
        }).catch(() => {
          // In offline mode without cached tile, fail silently so map falls back to dark grid
          return new Response('', { status: 408 });
        });
      })
    );
    return;
  }

  // For app assets & HTML: Cache First, fallback to Network
  event.respondWith(
    caches.match(req).then((cached) => {
      if (cached) {
        // Fetch in background to update cache (Stale-While-Revalidate)
        fetch(req).then((networkRes) => {
          if (networkRes && networkRes.status === 200) {
            caches.open(CACHE_NAME).then((cache) => cache.put(req, networkRes));
          }
        }).catch(() => {});
        return cached;
      }

      return fetch(req).then((networkRes) => {
        if (networkRes && networkRes.status === 200) {
          const resClone = networkRes.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(req, resClone));
        }
        return networkRes;
      }).catch(() => {
        // Fallback to index.html for navigation requests
        if (req.mode === 'navigate') {
          return caches.match('./index.html') || caches.match('/index.html');
        }
      });
    })
  );
});
