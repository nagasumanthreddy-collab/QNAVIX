// Main Application Controller

// Comprehensive Vehicle Specifications Preset Matrix (Indian & Global Commercial Transport)
const VEHICLE_SPECS_PRESETS = {
  'Van': {
    name: 'Van (Express Last-Mile Delivery)',
    capacity: 1000,
    fuelType: 'Diesel',
    fuelEfficiency: 14.0,
    tankCapacity: 50,
    maxRange: 700,
    effUnit: 'km/L',
    tankUnit: 'Fuel Tank Capacity (L)',
    desc: '1,000 kg Load • Diesel • 14.0 km/L • 50 L Tank • 700 km Range'
  },
  'Mini Truck': {
    name: 'Mini Truck (Tata Ace / Chhota Hathi)',
    capacity: 750,
    fuelType: 'Diesel',
    fuelEfficiency: 16.0,
    tankCapacity: 30,
    maxRange: 480,
    effUnit: 'km/L',
    tankUnit: 'Fuel Tank Capacity (L)',
    desc: '750 kg Load • Diesel • 16.0 km/L • 30 L Tank • 480 km Range'
  },
  'Light Commercial Vehicle': {
    name: 'Light Commercial Vehicle (LCV / Tata 407 / Bolero)',
    capacity: 2500,
    fuelType: 'Diesel',
    fuelEfficiency: 11.5,
    tankCapacity: 60,
    maxRange: 690,
    effUnit: 'km/L',
    tankUnit: 'Fuel Tank Capacity (L)',
    desc: '2,500 kg Load • Diesel • 11.5 km/L • 60 L Tank • 690 km Range'
  },
  'Medium Commercial Vehicle': {
    name: 'Medium Commercial Vehicle (MCV / 14-17ft Eicher)',
    capacity: 5000,
    fuelType: 'Diesel',
    fuelEfficiency: 7.5,
    tankCapacity: 120,
    maxRange: 900,
    effUnit: 'km/L',
    tankUnit: 'Fuel Tank Capacity (L)',
    desc: '5,000 kg Load • Diesel • 7.5 km/L • 120 L Tank • 900 km Range'
  },
  'Heavy Commercial Truck': {
    name: 'Heavy Commercial Truck (HCV / 16-Wheeler Multi-Axle)',
    capacity: 12000,
    fuelType: 'Diesel',
    fuelEfficiency: 4.5,
    tankCapacity: 220,
    maxRange: 990,
    effUnit: 'km/L',
    tankUnit: 'Fuel Tank Capacity (L)',
    desc: '12,000 kg Load • Diesel • 4.5 km/L • 220 L Tank • 990 km Range'
  },
  'Heavy Truck': {
    name: 'Heavy Commercial Truck (HCV / 16-Wheeler Multi-Axle)',
    capacity: 12000,
    fuelType: 'Diesel',
    fuelEfficiency: 4.5,
    tankCapacity: 220,
    maxRange: 990,
    effUnit: 'km/L',
    tankUnit: 'Fuel Tank Capacity (L)',
    desc: '12,000 kg Load • Diesel • 4.5 km/L • 220 L Tank • 990 km Range'
  },
  'EV Cargo Van': {
    name: 'Electric Cargo Van (Tata Ace EV / E-Delivery)',
    capacity: 800,
    fuelType: 'Electric',
    fuelEfficiency: 6.5,
    tankCapacity: 24,
    maxRange: 156,
    effUnit: 'km/kWh',
    tankUnit: 'Battery Pack Size (kWh)',
    desc: '800 kg Load • Electric • 6.5 km/kWh • 24 kWh Battery • 156 km Range'
  },
  '3-Wheeler Auto Cargo': {
    name: '3-Wheeler Auto Cargo (Bajaj Maxima / Ape CNG)',
    capacity: 500,
    fuelType: 'CNG',
    fuelEfficiency: 28.0,
    tankCapacity: 10,
    maxRange: 280,
    effUnit: 'km/kg',
    tankUnit: 'CNG Cylinder Capacity (kg)',
    desc: '500 kg Load • CNG • 28.0 km/kg • 10 kg Cylinder • 280 km Range'
  },
  'Electric 3-Wheeler': {
    name: 'Electric 3-Wheeler (Euler HiLoad / Zor Grand)',
    capacity: 680,
    fuelType: 'Electric',
    fuelEfficiency: 8.5,
    tankCapacity: 14,
    maxRange: 119,
    effUnit: 'km/kWh',
    tankUnit: 'Battery Pack Size (kWh)',
    desc: '680 kg Load • Electric • 8.5 km/kWh • 14 kWh Battery • 119 km Range'
  },
  'Two-Wheeler Bike': {
    name: 'Two-Wheeler Delivery Bike (Quick Commerce / Parcel)',
    capacity: 45,
    fuelType: 'Petrol',
    fuelEfficiency: 45.0,
    tankCapacity: 10,
    maxRange: 450,
    effUnit: 'km/L',
    tankUnit: 'Fuel Tank Capacity (L)',
    desc: '45 kg Load • Petrol • 45.0 km/L • 10 L Tank • 450 km Range'
  }
};

class LogisticsApp {
  constructor() {
    this.mapEngine = new MapEngine('map');
    this.analytics = new AnalyticsManager();
    this.depots = [];
    this.vehicles = [];
    this.deliveries = [];
    this.routes = [];
    this.settings = {};
    this.selectedDepotId = null;
    this.currentView = 'dashboard';
    this.autoDepotAssignment = false;
    this.selectedVehicleIds = new Set();
    this.currentFuelRates = null;
  }

  async init() {
    try {
      // 1. Fetch settings
      this.settings = await API.getSettings();
      this.autoDepotAssignment = this.settings.automatic_depot_assignment === '1';

      // 2. Initialize map engine
      this.mapEngine.init(this.settings.google_maps_api_key);

      // 3. Load depots
      await this.loadDepots();

      // 4. Initialize Daily Indian Fuel Rates Matrix
      await this.initDailyFuelRates();

      // 5. Load initial state
      await this.refreshAllData();

      // 6. Setup event listeners
      this.setupEventListeners();

      // 7. Initialize default vehicle specs preset
      this.applyVehicleSpecs('fleet', false);

      // 8. Execute High-Tech 3-Second Logo Splash Screen Animation
      this.runSplashSequence();

    } catch (err) {
      console.error('App init error:', err);
      this.showToast('Failed to load application data: ' + err.message, 'error');
    }
  }

  // ==================== DAILY INDIAN FUEL RATES ====================
  async initDailyFuelRates() {
    try {
      const citySelect = document.getElementById('fuel-city-select');
      const initialCity = citySelect ? citySelect.value : 'Hyderabad';
      const data = await API.getDailyFuelRates(initialCity);
      const rates = data.rates || data;
      this.currentFuelRates = rates;
      this.updateDailyFuelUI(rates);
    } catch (e) {
      console.warn('Daily fuel rate init note:', e);
    }
  }

  updateDailyFuelUI(rates) {
    if (!rates) return;
    const dEl = document.getElementById('ticker-rate-diesel');
    const pEl = document.getElementById('ticker-rate-petrol');
    const cEl = document.getElementById('ticker-rate-cng');
    const eEl = document.getElementById('ticker-rate-ev');

    if (dEl && rates.diesel) dEl.textContent = `₹${rates.diesel.toFixed(2)}`;
    if (pEl && rates.petrol) pEl.textContent = `₹${rates.petrol.toFixed(2)}`;
    if (cEl && rates.cng) cEl.textContent = `₹${rates.cng.toFixed(2)}`;
    if (eEl && rates.electric) eEl.textContent = `₹${rates.electric.toFixed(2)}`;
  }

  async switchDailyFuelCity(city) {
    try {
      const data = await API.syncDailyFuelRates(city);
      const rates = data.rates || data;
      this.currentFuelRates = rates;
      this.updateDailyFuelUI(rates);
      this.showToast(`Daily fuel prices updated for ${city} (Diesel: ₹${rates.diesel})`);
      if (this.routes && this.routes.length > 0) {
        await this.recalculate();
      }
    } catch (e) {
      this.showToast(`Failed to update fuel rates for ${city}: ${e.message}`, 'error');
    }
  }

  // ==================== 3-SECOND SPLASH & ENTRANCE ANIMATIONS ====================
  runSplashSequence() {
    const splash = document.getElementById('splash-screen');
    const overlay = document.getElementById('login-overlay');
    const percentEl = document.getElementById('splash-percent-counter');
    const statusEl = document.getElementById('splash-status-text');

    if (overlay) overlay.style.display = 'none';

    let progress = 0;
    const intervalTime = 25; // 25ms interval * 120 ticks = 3000ms total
    const timer = setInterval(() => {
      progress += 1;
      const displayPct = Math.min(100, Math.floor((progress / 120) * 100));
      if (percentEl) percentEl.textContent = `${displayPct}%`;

      if (progress === 25 && statusEl) {
        statusEl.textContent = 'Calibrating Indian Road Traffic Multipliers & Congestion Factors...';
      } else if (progress === 60 && statusEl) {
        statusEl.textContent = 'Synchronizing Daily Fuel Rates (Diesel, Petrol, CNG, EV)...';
      } else if (progress === 95 && statusEl) {
        statusEl.textContent = 'Activating Quantum Hybrid TSP Optimization Engine...';
      } else if (progress >= 120) {
        clearInterval(timer);
        if (percentEl) percentEl.textContent = '100%';
        if (statusEl) statusEl.textContent = 'QNAVIX Command Center Ready.';

        setTimeout(() => {
          if (splash) {
            splash.classList.add('fade-out');
            setTimeout(() => {
              splash.style.display = 'none';
              if (overlay) {
                overlay.style.display = '';
                const card = overlay.querySelector('.login-card');
                if (card) {
                  card.style.animation = 'none';
                  void card.offsetHeight; // reflow
                  card.style.animation = 'loginCardEntrance 0.7s cubic-bezier(0.16, 1, 0.3, 1) forwards';
                }
              }
              this.checkAuth();
            }, 500);
          } else {
            if (overlay) overlay.style.display = '';
            this.checkAuth();
          }
        }, 300);
      }
    }, intervalTime);
  }

  checkAuth(forceShowLogin = false) {
    const user = localStorage.getItem('logistics_user');
    const overlay = document.getElementById('login-overlay');
    const sessionActive = sessionStorage.getItem('qnavix_session_active');

    if (user && sessionActive && !forceShowLogin) {
      try {
        const u = JSON.parse(user);
        const nameEl = document.getElementById('user-display-name');
        const roleEl = document.getElementById('user-display-role');
        const avatarEl = document.getElementById('user-avatar');
        if (nameEl) nameEl.textContent = u.name || 'Dispatcher';
        if (roleEl) roleEl.textContent = u.role || 'Dynamic Mode';
        if (avatarEl) avatarEl.textContent = (u.name || 'D').split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
        overlay?.classList.add('hidden');
      } catch (e) {
        overlay?.classList.remove('hidden');
      }
    } else {
      if (user) {
        try {
          const u = JSON.parse(user);
          const emailInput = document.getElementById('login-email');
          if (emailInput && u.email) emailInput.value = u.email;
        } catch (e) {}
      }
      overlay?.classList.remove('hidden');
    }
  }

  async loadDepots(params = {}) {
    const data = await API.getDepots(params);
    this.depots = data.depots || [];
    
    // Populate state and city filter dropdowns
    this.populateDepotDropdowns(data.states || [], data.cities || []);
    this.populateFleetDepotSelect();
  }

  populateDepotDropdowns(states, cities) {
    const stateSelect = document.getElementById('filter-depot-state');
    if (stateSelect && states.length) {
      stateSelect.innerHTML = '<option value="">All States</option>' +
        states.map(s => `<option value="${s}">${s}</option>`).join('');
    }

    const citySelect = document.getElementById('filter-depot-city');
    if (citySelect && cities.length) {
      citySelect.innerHTML = '<option value="">All Cities</option>' +
        cities.map(c => `<option value="${c}">${c}</option>`).join('');
    }
  }

  populateFleetDepotSelect() {
    const fleetDepotSelect = document.getElementById('fleet-default-depot');
    if (fleetDepotSelect && this.depots.length) {
      fleetDepotSelect.innerHTML = this.depots.map(d => 
        `<option value="${d.id}" ${d.city === 'Hyderabad' ? 'selected' : ''}>${d.city} — ${d.name}</option>`
      ).join('');
    }
  }

  // ==================== VEHICLE SPECIFICATIONS AUTO-SELECTION ====================
  applyVehicleSpecs(prefix = 'fleet', triggerPulse = true) {
    const typeSelect = document.getElementById(`${prefix}-vehicle-type`);
    if (!typeSelect) return;

    const selectedType = typeSelect.value;
    const preset = VEHICLE_SPECS_PRESETS[selectedType] || VEHICLE_SPECS_PRESETS['Van'];

    const capInput = document.getElementById(`${prefix}-capacity`);
    const fuelSelect = document.getElementById(`${prefix}-fuel-type`);
    const effInput = document.getElementById(`${prefix}-fuel-efficiency`);
    const tankInput = document.getElementById(`${prefix}-tank-capacity`);
    const rangeInput = document.getElementById(`${prefix}-max-range`);
    const summarySpan = document.getElementById(`${prefix}-spec-summary`);
    const effLabel = document.getElementById(`${prefix}-fuel-efficiency-label`);
    const tankLabel = document.getElementById(`${prefix}-tank-capacity-label`);

    if (capInput) capInput.value = preset.capacity;
    if (fuelSelect) fuelSelect.value = preset.fuelType;
    if (effInput) effInput.value = preset.fuelEfficiency;
    if (tankInput) tankInput.value = preset.tankCapacity;
    if (rangeInput) rangeInput.value = preset.maxRange;

    if (summarySpan) {
      summarySpan.innerHTML = `<strong>${preset.name.split('(')[0].trim()}:</strong> ${preset.desc}`;
    }

    if (effLabel) {
      effLabel.textContent = `Mileage / Fuel Efficiency (${preset.effUnit})`;
    }

    if (tankLabel) {
      tankLabel.textContent = preset.tankUnit;
    }

    if (triggerPulse) {
      const inputs = [capInput, fuelSelect, effInput, tankInput, rangeInput].filter(Boolean);
      inputs.forEach(el => {
        el.classList.remove('spec-pulse-active');
        void el.offsetWidth; // Trigger reflow for animation restart
        el.classList.add('spec-pulse-active');
      });
      setTimeout(() => {
        inputs.forEach(el => el.classList.remove('spec-pulse-active'));
      }, 1200);
    }
  }

  updateDynamicVehicleUnits(prefix = 'fleet') {
    const fuelSelect = document.getElementById(`${prefix}-fuel-type`);
    const effLabel = document.getElementById(`${prefix}-fuel-efficiency-label`);
    const tankLabel = document.getElementById(`${prefix}-tank-capacity-label`);
    if (!fuelSelect) return;

    const fuel = fuelSelect.value;
    let effUnit = 'km/L';
    let tankUnit = 'Fuel Tank Capacity (L)';

    if (fuel === 'Electric') {
      effUnit = 'km/kWh';
      tankUnit = 'Battery Pack Size (kWh)';
    } else if (fuel === 'CNG') {
      effUnit = 'km/kg';
      tankUnit = 'CNG Cylinder Capacity (kg)';
    }

    if (effLabel) effLabel.textContent = `Mileage / Fuel Efficiency (${effUnit})`;
    if (tankLabel) tankLabel.textContent = tankUnit;
  }

  recalculateMaxRange(prefix = 'fleet') {
    const effInput = document.getElementById(`${prefix}-fuel-efficiency`);
    const tankInput = document.getElementById(`${prefix}-tank-capacity`);
    const rangeInput = document.getElementById(`${prefix}-max-range`);

    if (effInput && tankInput && rangeInput) {
      const eff = parseFloat(effInput.value);
      const tank = parseFloat(tankInput.value);
      if (!isNaN(eff) && !isNaN(tank) && eff > 0 && tank > 0) {
        rangeInput.value = Math.round(eff * tank);
      }
    }
  }

  openEditVehicleModal(vehicleId) {
    const v = this.vehicles.find(item => item.id === vehicleId);
    if (!v) {
      this.showToast('Vehicle record not found.', 'error');
      return;
    }

    const idInput = document.getElementById('edit-vehicle-id');
    const vidInput = document.getElementById('edit-vehicle-vid');
    const driverInput = document.getElementById('edit-vehicle-driver');
    if (idInput) idInput.value = v.id;
    if (vidInput) vidInput.value = v.vehicleId;
    if (driverInput) driverInput.value = `${v.driverName || 'Generated Driver'} (Rating ★ ${v.driverRating || 4.7})`;

    const typeSelect = document.getElementById('edit-vehicle-type');
    if (typeSelect) {
      const match = Array.from(typeSelect.options).find(o => o.value === v.vehicleType);
      typeSelect.value = match ? v.vehicleType : 'Van';
    }

    const capInput = document.getElementById('edit-capacity');
    const fuelSelect = document.getElementById('edit-fuel-type');
    const effInput = document.getElementById('edit-fuel-efficiency');
    const tankInput = document.getElementById('edit-tank-capacity');
    const rangeInput = document.getElementById('edit-max-range');

    if (capInput) capInput.value = v.capacity || 1000;
    if (fuelSelect) fuelSelect.value = v.fuelType || 'Diesel';
    if (effInput) effInput.value = v.fuelEfficiency || 14.0;
    if (tankInput) tankInput.value = v.fuelTankCapacity || 50;
    if (rangeInput) rangeInput.value = v.maximumRange || 700;

    this.updateDynamicVehicleUnits('edit');
    const summarySpan = document.getElementById('edit-spec-summary');
    if (summarySpan) {
      const p = VEHICLE_SPECS_PRESETS[typeSelect?.value] || VEHICLE_SPECS_PRESETS['Van'];
      summarySpan.textContent = p.desc;
    }

    this.openModal('modal-edit-vehicle');
  }


  async refreshAllData() {
    // Fetch vehicles & deliveries
    const [vehData, delivData] = await Promise.all([
      API.getVehicles(),
      API.getDeliveries()
    ]);

    this.vehicles = vehData.vehicles || [];
    this.deliveries = delivData.deliveries || [];

    // Ensure selectedVehicleIds has entries
    if (this.selectedVehicleIds.size === 0 && this.vehicles.length > 0) {
      this.vehicles.forEach(v => this.selectedVehicleIds.add(String(v.id)));
    }

    // Update Tables, Checklist & Panels
    this.renderDepotFleetChecklist();
    this.renderDeliveriesTable();
    this.renderVehiclesList();
    this.renderRouteDetails();

    // Re-render map markers
    this.mapEngine.clearAll();
    this.updateMapDisplay();

    // Check if empty state
    this.updateEmptyStateNotice();

    // If no routes are calculated yet, keep KPI cards and fuel stats displaying clean dashes '--'
    if (!this.routes || this.routes.length === 0) {
      this.analytics.updateKPIs({
        activeVehicles: this.vehicles.length > 0 ? `0 / ${this.vehicles.length}` : '--',
        deliveryLocations: this.deliveries.length,
        totalDistanceKm: 0,
        totalFuelCostInr: 0,
        averageDeliveryTimeMinutes: 0,
        lateDeliveries: null
      });
      this.analytics.updateFuelAnalytics({
        totalFuelLiters: 0,
        averageFuelEfficiency: 0,
        totalFuelCostInr: 0,
        costPerKm: 0,
        costPerDelivery: 0,
        totalCo2Kg: 0,
        co2PerDelivery: 0,
        co2SavedKg: 0
      }, []);
    }
  }

  // ==================== DEPOT FLEET AVAILABILITY CHECKLIST ====================
  renderDepotFleetChecklist() {
    const container = document.getElementById('depot-fleet-checklist');
    const countEl = document.getElementById('depot-fleet-count');
    if (!container) return;

    if (!this.vehicles || this.vehicles.length === 0) {
      container.innerHTML = `
        <div style="grid-column: 1 / -1; padding: 18px; text-align: center; color: #64748b; font-size: 0.82rem;">
          No vehicles in depot yet. Click <strong>+ Add Fleet</strong> to configure vehicles with automatic mechanical specs.
        </div>
      `;
      if (countEl) countEl.textContent = '(0 / 0 Available)';
      return;
    }

    // Default select all if empty
    if (this.selectedVehicleIds.size === 0) {
      this.vehicles.forEach(v => this.selectedVehicleIds.add(String(v.id)));
    }

    const availableCount = this.vehicles.filter(v => this.selectedVehicleIds.has(String(v.id))).length;
    if (countEl) {
      countEl.textContent = `(${availableCount} / ${this.vehicles.length} Available for Dispatch)`;
    }

    container.innerHTML = this.vehicles.map(v => {
      const isSelected = this.selectedVehicleIds.has(String(v.id));
      const fuelEffUnit = (v.fuelType === 'Electric') ? 'km/kWh' : (v.fuelType === 'CNG' ? 'km/kg' : 'km/L');
      const tankUnit = (v.fuelType === 'Electric') ? 'kWh' : (v.fuelType === 'CNG' ? 'kg' : 'L');

      return `
        <div class="vehicle-check-item ${isSelected ? 'selected' : 'excluded'}" id="v-check-row-${v.id}">
          <div class="v-check-left" onclick="app.toggleVehicleAvailability('${v.id}')">
            <input type="checkbox" class="v-check-box" data-vid="${v.id}" ${isSelected ? 'checked' : ''} onclick="event.stopPropagation(); app.toggleVehicleAvailability('${v.id}')">
            <div class="v-check-info">
              <div class="v-check-id">${v.vehicleId} <span style="font-weight: normal; color: #94a3b8; font-size: 0.74rem;">(${v.vehicleType})</span></div>
              <div class="v-check-specs">
                ${Number(v.capacity).toLocaleString('en-IN')} kg &bull; ${v.fuelType} &bull; ${Number(v.fuelEfficiency).toFixed(1)} ${fuelEffUnit} &bull; Range: ${v.maximumRange || Math.round((v.fuelEfficiency || 14) * (v.fuelTankCapacity || 50))} km
              </div>
            </div>
          </div>
          <div class="v-check-actions">
            <span class="badge-status ${isSelected ? 'status-transit' : 'status-pending'}" style="font-size: 0.65rem; padding: 2px 7px;">
              ${isSelected ? 'Available' : 'Standby'}
            </span>
            <button class="btn btn-sm btn-quantum" onclick="app.inspectVehicleSpecs('${v.id}')" title="Inspect Vehicle Telemetry & Specifications" style="padding: 2px 8px; font-size: 0.7rem;">
              🔍 Specs
            </button>
          </div>
        </div>
      `;
    }).join('');
  }

  toggleVehicleAvailability(vid) {
    vid = String(vid);
    if (this.selectedVehicleIds.has(vid)) {
      this.selectedVehicleIds.delete(vid);
    } else {
      this.selectedVehicleIds.add(vid);
    }
    this.renderDepotFleetChecklist();
    this.renderVehiclesList();
  }

  selectAllVehicles(select = true) {
    if (select) {
      this.vehicles.forEach(v => this.selectedVehicleIds.add(String(v.id)));
      this.showToast(`All ${this.vehicles.length} vehicles marked Available for dispatch.`);
    } else {
      this.selectedVehicleIds.clear();
      this.showToast('All vehicles marked Standby (excluded from routing).', 'info');
    }
    this.renderDepotFleetChecklist();
    this.renderVehiclesList();
  }

  // ==================== VEHICLE SPECIFICATIONS AUTO-DETECTION & INSPECTION ====================
  inspectVehicleSpecs(vehicleId) {
    const v = this.vehicles.find(item => String(item.id) === String(vehicleId) || String(item.vehicleId) === String(vehicleId));
    if (!v) {
      this.showToast('Vehicle telemetry record not found.', 'error');
      return;
    }

    const vidEl = document.getElementById('telem-vid');
    const typeEl = document.getElementById('telem-type');
    const statusEl = document.getElementById('telem-status');
    const fuelBadgeEl = document.getElementById('telem-fuel-badge');
    const mileageEl = document.getElementById('telem-mileage');
    const capEl = document.getElementById('telem-capacity');
    const tankEl = document.getElementById('telem-tank');
    const rangeEl = document.getElementById('telem-max-range');
    const drvNameEl = document.getElementById('telem-driver-name');
    const drvPhoneEl = document.getElementById('telem-driver-phone');
    const depotCityEl = document.getElementById('telem-depot-city');
    const depotNameEl = document.getElementById('telem-depot-name');
    const iconEl = document.getElementById('telem-icon');

    const fuelType = v.fuelType || 'Diesel';
    const isElectric = fuelType === 'Electric';
    const isCng = fuelType === 'CNG';
    const effUnit = isElectric ? 'km/kWh' : (isCng ? 'km/kg' : 'km/L');
    const tankUnit = isElectric ? 'kWh' : (isCng ? 'kg' : 'L');

    if (iconEl) {
      iconEl.textContent = isElectric ? '⚡' : (v.vehicleType?.includes('Truck') ? '🚛' : (v.vehicleType?.includes('Bike') ? '🏍️' : '🚚'));
    }
    if (vidEl) vidEl.textContent = v.vehicleId;
    if (typeEl) typeEl.textContent = v.vehicleType;
    if (statusEl) {
      const isAvailable = this.selectedVehicleIds.has(String(v.id));
      statusEl.textContent = isAvailable ? 'Available for Dispatch' : 'Standby in Depot';
      statusEl.className = `badge-status ${isAvailable ? 'status-transit' : 'status-pending'}`;
    }
    if (fuelBadgeEl) fuelBadgeEl.textContent = fuelType;
    if (mileageEl) mileageEl.textContent = `${Number(v.fuelEfficiency || 14.0).toFixed(1)} ${effUnit}`;
    if (capEl) capEl.textContent = `${Number(v.capacity || 1000).toLocaleString('en-IN')} kg`;
    if (tankEl) tankEl.textContent = `${v.fuelTankCapacity || 50} ${tankUnit}`;
    const calculatedRange = v.maximumRange || Math.round((v.fuelEfficiency || 14) * (v.fuelTankCapacity || 50));
    if (rangeEl) rangeEl.textContent = `${calculatedRange} km`;
    if (drvNameEl) drvNameEl.textContent = v.driverName || 'Generated Driver';
    if (drvPhoneEl) drvPhoneEl.textContent = `${v.driverPhone || '+91 98765 43210'} • ★ ${v.driverRating || 4.8} Rating`;
    if (depotCityEl) depotCityEl.textContent = `${v.depotCity || 'Hub Depot'}`;
    if (depotNameEl) depotNameEl.textContent = `${v.depotName || 'Logistics Hub'}`;

    const editBtn = document.getElementById('btn-edit-from-telem');
    if (editBtn) {
      editBtn.onclick = () => {
        this.closeModal('modal-vehicle-telemetry');
        this.openEditVehicleModal(v.id);
      };
    }

    this.openModal('modal-vehicle-telemetry');
  }

  updateMapDisplay() {
    this.mapEngine.clearAll();

    // Render depots
    this.mapEngine.renderDepots(this.depots, this.routes);

    // Render delivery markers
    this.mapEngine.renderDeliveries(this.deliveries);

    // Render route polylines
    if (this.routes && this.routes.length > 0) {
      this.mapEngine.renderRoutes(this.routes);
    }

    // Auto zoom fit bounds
    const allPts = [];
    this.deliveries.forEach(d => allPts.push({ lat: d.latitude, lng: d.longitude }));
    if (this.routes && this.routes.length > 0) {
      this.routes.forEach(r => {
        if (r.depot) allPts.push({ lat: r.depot.latitude, lng: r.depot.longitude });
      });
    } else if (this.depots.length > 0) {
      // If no deliveries yet, show major depots
      this.depots.slice(0, 10).forEach(d => allPts.push({ lat: d.latitude, lng: d.longitude }));
    }

    this.mapEngine.fitBoundsToLocations(allPts);
  }

  updateEmptyStateNotice() {
    const emptyNotice = document.getElementById('empty-state-notice');
    if (!emptyNotice) return;

    if (this.vehicles.length === 0 && this.deliveries.length === 0) {
      emptyNotice.style.display = 'block';
    } else {
      emptyNotice.style.display = 'none';
    }
  }

  // ==================== RENDERING UI ====================
  renderRouteDetails() {
    const container = document.getElementById('route-cards-list');
    if (!container) return;

    if (!this.routes || this.routes.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <p style="font-size: 0.85rem; color: #94a3b8;">No active routes generated yet.</p>
          <p style="font-size: 0.75rem; color: #64748b; margin-top: 4px;">Click <strong>⚡ Optimize Routes</strong> above to calculate optimal delivery sequences.</p>
        </div>
      `;
      return;
    }

    container.innerHTML = this.routes.map(r => {
      const stopsHtml = (r.stops || []).map(s => {
        if (s.type === 'depot') {
          return `<span class="stop-pill" style="color: #f59e0b; background: rgba(245, 158, 11, 0.15);">Depot</span>`;
        }
        return `<span class="stop-pill" title="${s.name} (ETA: ${s.arrivalTime})">${s.orderId || 'D'}</span>`;
      }).join(' → ');

      const driver = this.vehicles.find(v => v.vehicleId === r.vehicleId) || {};
      const driverName = driver.driverName || 'Assigned Driver';
      const driverRating = driver.driverRating ? `★ ${driver.driverRating}` : '';

      return `
        <div class="vehicle-route-card" style="--route-color: ${r.color};">
          <div class="vehicle-route-header">
            <span class="v-badge" style="cursor: pointer;" onclick="app.inspectVehicleSpecs('${r.vehicleId}')" title="Click to view auto-detected specifications">
              ${r.vehicleId} (${r.vehicleType || 'Van'}) 🔍
            </span>
            <span class="v-driver">
              👤 ${driverName} <span style="color: #f59e0b; font-size: 0.72rem;">${driverRating}</span>
            </span>
          </div>

          <div class="v-depot-tag">
            <span>🏭</span> Depot: <strong>${r.depot ? r.depot.name : 'Central Hub'}</strong>
          </div>

          ${r.trafficSummary ? `
          <div style="margin: 6px 0 10px; padding: 5px 8px; border-radius: 6px; background: rgba(15, 23, 42, 0.75); border-left: 3px solid ${r.trafficColor || '#10b981'}; display: flex; justify-content: space-between; align-items: center; font-size: 0.72rem;">
            <span style="color: ${r.trafficColor || '#10b981'}; font-weight: 600;">🚦 ${r.trafficSummary}</span>
            <span style="color: #94a3b8;">Congestion Delay: +${Math.round(r.trafficDelayMinutes || 0)} min</span>
          </div>
          ` : ''}

          <div class="v-metrics-grid">
            <div class="v-metric-item">
              <span class="v-metric-label">Distance</span>
              <span class="v-metric-val">${Number(r.totalDistanceKm || 0).toFixed(1)} km</span>
            </div>
            <div class="v-metric-item">
              <span class="v-metric-label">Travel Time</span>
              <span class="v-metric-val">${Math.round(r.travelTimeMinutes || 0)} min</span>
            </div>
            <div class="v-metric-item">
              <span class="v-metric-label">Fuel Used</span>
              <span class="v-metric-val">${Number(r.fuelUsedLiters || 0).toFixed(1)} L</span>
            </div>
            <div class="v-metric-item">
              <span class="v-metric-label">Fuel Cost</span>
              <span class="v-metric-val" style="color: #34d399;">₹${Number(r.fuelCostInr || 0).toLocaleString('en-IN')}</span>
            </div>
            <div class="v-metric-item">
              <span class="v-metric-label">Load / Cap</span>
              <span class="v-metric-val">${r.currentLoadKg || 0} / ${r.capacityKg} kg</span>
            </div>
            <div class="v-metric-item">
              <span class="v-metric-label">CO₂ Emitted</span>
              <span class="v-metric-val">${Number(r.co2Kg || 0).toFixed(1)} kg</span>
            </div>
          </div>

          <div class="utilization-bar-wrap">
            <div class="util-labels">
              <span>Capacity Utilization</span>
              <strong>${r.utilizationPercent || 0}%</strong>
            </div>
            <div class="util-bar">
              <div class="util-fill" style="width: ${Math.min(100, r.utilizationPercent || 0)}%;"></div>
            </div>
          </div>

          <div class="route-path-summary">
            ${stopsHtml}
          </div>
        </div>
      `;
    }).join('');
  }

  renderDeliveriesTable() {
    const tbody = document.getElementById('deliveries-table-body');
    if (!tbody) return;

    if (!this.deliveries || this.deliveries.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="8" style="text-align: center; padding: 30px; color: #64748b;">
            No deliveries added yet. Click <strong>+ Add Delivery</strong> or load a demo scenario.
          </td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = this.deliveries.map((d, idx) => {
      const priClass = `priority-${d.priority ? d.priority.toLowerCase() : 'medium'}`;
      let statusClass = 'status-pending';
      let statusText = d.status || 'Pending';

      if (d.status === 'In Transit') {
        statusClass = 'status-transit';
      }

      return `
        <tr>
          <td><strong style="color: #38bdf8;">D${idx + 1} (${d.orderId})</strong></td>
          <td>${d.customerName}</td>
          <td style="max-width: 240px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${d.address}">${d.address}</td>
          <td>${d.product} (${d.weight} kg)</td>
          <td><span class="badge-priority ${priClass}">${d.priority}</span></td>
          <td>${d.timeWindowStart} - ${d.timeWindowEnd}</td>
          <td><strong style="color: #60a5fa;">${d.assignedVehicle || '—'}</strong></td>
          <td><span class="badge-status ${statusClass}">${d.eta || statusText}</span></td>
          <td>
            <button class="btn btn-sm btn-outline-danger" onclick="app.deleteDeliveryItem(${d.id})">✕</button>
          </td>
        </tr>
      `;
    }).join('');
  }

  renderVehiclesList() {
    const tbody = document.getElementById('vehicles-table-body');
    if (!tbody) return;

    if (!this.vehicles || this.vehicles.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="8" style="text-align: center; padding: 30px; color: #64748b;">
            No fleet vehicles configured yet. Click <strong>+ Add Fleet</strong>.
          </td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = this.vehicles.map(v => {
      const isSelected = this.selectedVehicleIds.has(String(v.id));
      const fuelEffUnit = (v.fuelType === 'Electric') ? 'km/kWh' : (v.fuelType === 'CNG' ? 'km/kg' : 'km/L');

      return `
        <tr>
          <td>
            <strong style="color: #60a5fa; cursor: pointer; text-decoration: underline;" onclick="app.inspectVehicleSpecs('${v.id}')" title="Inspect Vehicle Telemetry & Specifications">
              ${v.vehicleId} 🔍
            </strong>
          </td>
          <td>${v.vehicleType}</td>
          <td>${Number(v.capacity).toLocaleString('en-IN')} kg</td>
          <td>${v.fuelType} (${Number(v.fuelEfficiency).toFixed(1)} ${fuelEffUnit})</td>
          <td>${v.depotCity || 'Hub'}</td>
          <td>
            <div style="font-weight: 600; color: #f8fafc;">${v.driverName || 'Generated Driver'}</div>
            <div style="font-size: 0.72rem; color: #94a3b8;">${v.driverPhone || ''} | ★ ${v.driverRating || 4.7}</div>
          </td>
          <td>
            <span class="badge-status ${isSelected ? 'status-transit' : 'status-pending'}">
              ${isSelected ? 'Available' : 'Standby'}
            </span>
          </td>
          <td>
            <button class="btn btn-sm btn-quantum" onclick="app.inspectVehicleSpecs('${v.id}')" title="Inspect Auto-Detected Specs" style="padding: 2px 7px; font-size: 0.72rem;">🔍 Specs</button>
            <button class="btn btn-sm btn-secondary" onclick="app.openEditVehicleModal(${v.id})" title="Edit Vehicle">⚙️</button>
            <button class="btn btn-sm btn-outline-danger" onclick="app.deleteVehicleItem(${v.id})" title="Delete Vehicle">✕</button>
          </td>
        </tr>
      `;
    }).join('');
  }

  // ==================== ACTIONS & WORKFLOWS ====================
  async optimize() {
    if (this.vehicles.length === 0) {
      this.showToast('Please add at least 1 vehicle before optimizing.', 'error');
      this.openModal('modal-add-fleet');
      return;
    }

    if (this.selectedVehicleIds.size === 0) {
      this.showToast('No available vehicles selected in Depot Checklist! Please check at least 1 vehicle.', 'error');
      return;
    }

    if (this.deliveries.length === 0) {
      this.showToast('Please add delivery orders before optimizing.', 'error');
      this.openModal('modal-add-delivery');
      return;
    }

    const optBtn = document.getElementById('btn-optimize-main');
    if (optBtn) {
      optBtn.disabled = true;
      optBtn.innerHTML = '<span>⚡ Optimizing via Quantum Heuristic & Traffic AI...</span>';
    }

    const trafficSelect = document.getElementById('traffic-condition-select');
    const trafficCondition = trafficSelect ? trafficSelect.value : 'auto';
    const selectedIds = Array.from(this.selectedVehicleIds);

    try {
      const res = await API.optimize(this.autoDepotAssignment, selectedIds, trafficCondition);
      if (res.success) {
        this.routes = res.routes || [];
        this.analytics.updateKPIs(res.analytics);
        this.analytics.updateFuelAnalytics(res.analytics, this.routes);
        this.analytics.updateComparisonTable(res.comparison);

        await this.refreshAllData();
        const trafficLabel = trafficSelect ? trafficSelect.options[trafficSelect.selectedIndex].text : 'Traffic Aware';
        this.showToast(`Routes optimized for ${selectedIds.length} vehicles under ${trafficLabel}!`);
      }
    } catch (err) {
      console.error('Optimization error:', err);
      this.showToast('Optimization failed: ' + err.message, 'error');
    } finally {
      if (optBtn) {
        optBtn.disabled = false;
        optBtn.innerHTML = '<span>⚡ Optimize Routes</span>';
      }
    }
  }

  async recalculate() {
    try {
      const res = await API.recalculate();
      if (res.success) {
        this.analytics.updateKPIs(res.analytics);
        this.analytics.updateFuelAnalytics(res.analytics, this.routes);
        this.showToast('Fuel metrics and costs recalculated instantaneously.');
      }
    } catch (err) {
      console.error('Recalculate error:', err);
    }
  }

  async loadDemoScenario(city = 'hyderabad') {
    try {
      const res = await API.loadDemo(city);
      if (res.success) {
        this.showToast(res.message);
        await this.refreshAllData();
        // Immediately trigger optimization for demonstration
        await this.optimize();
      }
    } catch (err) {
      this.showToast('Failed to load demo: ' + err.message, 'error');
    }
  }

  async resetAllData() {
    if (!confirm('Are you sure you want to reset all vehicles, deliveries, and routes to initial empty state?')) return;
    try {
      await API.resetAll();
      this.routes = [];
      this.analytics.updateKPIs({
        activeVehicles: '--',
        deliveryLocations: 0,
        totalDistanceKm: 0,
        totalFuelCostInr: 0,
        averageDeliveryTimeMinutes: 0,
        lateDeliveries: null
      });
      this.analytics.updateFuelAnalytics({
        totalFuelLiters: 0,
        averageFuelEfficiency: 0,
        totalFuelCostInr: 0,
        costPerKm: 0,
        costPerDelivery: 0,
        totalCo2Kg: 0,
        co2PerDelivery: 0,
        co2SavedKg: 0
      }, []);
      await this.refreshAllData();
      this.showToast('Application reset to clean empty state (0 vehicles, 0 deliveries).');
    } catch (err) {
      this.showToast('Reset failed: ' + err.message, 'error');
    }
  }

  async deleteDeliveryItem(id) {
    try {
      await API.deleteDelivery(id);
      await this.refreshAllData();
      this.showToast('Delivery order removed.');
    } catch (err) {
      this.showToast('Failed to delete delivery: ' + err.message, 'error');
    }
  }

  async deleteVehicleItem(id) {
    try {
      await API.deleteVehicle(id);
      await this.refreshAllData();
      this.showToast('Vehicle and driver unassigned.');
    } catch (err) {
      this.showToast('Failed to delete vehicle: ' + err.message, 'error');
    }
  }

  // ==================== EVENT LISTENERS & MODALS ====================
  setupEventListeners() {
    // Top Nav buttons
    document.querySelectorAll('.nav-item').forEach(item => {
      item.addEventListener('click', (e) => {
        document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
        item.classList.add('active');
        const view = item.getAttribute('data-view');
        this.switchView(view);
      });
    });

    // Progressive Web App (PWA) Offline Installation
    let deferredPrompt = null;
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      deferredPrompt = e;
      const installBtn = document.getElementById('btn-install-pwa');
      if (installBtn) {
        installBtn.style.display = 'inline-flex';
        installBtn.onclick = async () => {
          if (deferredPrompt) {
            deferredPrompt.prompt();
            const { outcome } = await deferredPrompt.userChoice;
            if (outcome === 'accepted') {
              this.showToast('QNAVIX installed! App is now accessible offline on your system.');
            }
            deferredPrompt = null;
            installBtn.style.display = 'none';
          }
        };
      }
    });

    window.addEventListener('appinstalled', () => {
      this.showToast('QNAVIX installed successfully for offline usage!');
      const installBtn = document.getElementById('btn-install-pwa');
      if (installBtn) installBtn.style.display = 'none';
    });

    // Network Online / Offline notifications
    window.addEventListener('offline', () => {
      this.showToast('Network disconnected: QNAVIX running in In-Browser Offline Engine ⚡', 'info');
      API.notifyStatusChange(true);
    });

    window.addEventListener('online', () => {
      this.showToast('Network reconnected: Connected to QNAVIX Cloud Server 🟢', 'success');
      API.checkServerHealth();
    });

    // Map style toggle buttons
    document.querySelectorAll('.map-view-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.map-view-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const style = btn.getAttribute('data-style');
        this.mapEngine.setTileLayer(style);
      });
    });

    // Authentication event listeners
    document.getElementById('form-login')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = document.getElementById('login-email')?.value || 'dispatcher@logistics.in';
      const role = document.getElementById('login-role')?.value || 'Fleet Operations Dispatcher';
      const name = email.split('@')[0].replace(/[._]/g, ' ').replace(/\b\w/g, l => l.toUpperCase()) || 'Dispatcher';
      const cleanSlate = document.getElementById('login-clean-slate')?.checked ?? true;

      sessionStorage.setItem('qnavix_session_active', 'true');
      localStorage.setItem('logistics_user', JSON.stringify({ email, role, name, mode: 'dynamic' }));
      this.checkAuth();

      if (cleanSlate) {
        try {
          await API.resetAll();
          this.routes = [];
          await this.refreshAllData();
          this.showToast(`Dynamic Fleet Mode: Welcome ${name}! Enter vehicles & deliveries dynamically.`);
          // Open fleet generation modal so user can immediately input vehicles!
          this.openModal('modal-add-fleet');
        } catch (err) {
          console.error(err);
          this.showToast(`Logged in as ${name} (${role})`);
        }
      } else {
        await this.refreshAllData();
        this.showToast(`Dynamic Fleet Mode: Welcome ${name}!`);
      }
    });

    document.getElementById('btn-quick-login')?.addEventListener('click', async () => {
      sessionStorage.setItem('qnavix_session_active', 'true');
      localStorage.setItem('logistics_user', JSON.stringify({
        email: 'admin@logistics.in',
        role: 'Chief Dispatcher',
        name: 'Rajesh Sharma',
        mode: 'demo'
      }));
      this.checkAuth();
      this.showToast('Demo Access: Loading Hyderabad Pre-populated Fleet Scenario...');
      try {
        await this.loadDemoScenario('hyderabad');
      } catch (err) {
        console.error(err);
      }
    });

    document.getElementById('btn-logout')?.addEventListener('click', () => {
      sessionStorage.removeItem('qnavix_session_active');
      localStorage.removeItem('logistics_user');
      this.checkAuth(true);
      this.showToast('Signed out of QNAVIX Portal.');
    });

    // Locate Me on Map
    document.getElementById('btn-locate-me')?.addEventListener('click', () => {
      this.showToast('Locating your current GPS coordinates...');
      this.mapEngine.locateCurrentPosition((pos) => {
        this.showToast(`GPS Position: ${pos.lat.toFixed(4)}, ${pos.lng.toFixed(4)}`);
      });
    });

    // Pick Delivery on Map
    document.getElementById('btn-pick-deliv-map')?.addEventListener('click', () => {
      this.closeModal('modal-add-delivery');
      this.showToast('Click anywhere on the map to set delivery location pin 📍', 'info');
      this.mapEngine.enableLocationPicker(async (lat, lng) => {
        this.showToast('Resolving Indian address from map coordinates...');
        let addr = `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
        try {
          const geo = await API.reverseGeocode(lat, lng);
          if (geo && geo.address) addr = geo.address;
        } catch (err) {}

        const addrInput = document.getElementById('deliv-address');
        const latInput = document.getElementById('deliv-lat');
        const lngInput = document.getElementById('deliv-lng');
        if (addrInput) addrInput.value = addr;
        if (latInput) latInput.value = lat.toFixed(6);
        if (lngInput) lngInput.value = lng.toFixed(6);

        this.openModal('modal-add-delivery');
        this.showToast(`Location set from map: ${addr}`);
      });
    });

    // Use GPS for Delivery
    document.getElementById('btn-locate-deliv-gps')?.addEventListener('click', () => {
      this.showToast('Fetching device GPS coordinates...');
      this.mapEngine.locateCurrentPosition(async (pos) => {
        const latInput = document.getElementById('deliv-lat');
        const lngInput = document.getElementById('deliv-lng');
        const addrInput = document.getElementById('deliv-address');
        if (latInput) latInput.value = pos.lat.toFixed(6);
        if (lngInput) lngInput.value = pos.lng.toFixed(6);
        try {
          const geo = await API.reverseGeocode(pos.lat, pos.lng);
          if (geo && geo.address && addrInput) addrInput.value = geo.address;
        } catch (e) {}
        this.showToast(`GPS Coordinates filled: ${pos.lat.toFixed(4)}, ${pos.lng.toFixed(4)}`);
      });
    });

    // Modal open buttons
    document.getElementById('btn-add-fleet-modal')?.addEventListener('click', () => this.openModal('modal-add-fleet'));
    document.getElementById('btn-add-delivery-modal')?.addEventListener('click', () => this.openModal('modal-add-delivery'));
    document.getElementById('btn-optimize-main')?.addEventListener('click', () => this.optimize());
    document.getElementById('btn-reoptimize')?.addEventListener('click', () => this.optimize());
    document.getElementById('btn-demo-hyd')?.addEventListener('click', () => this.loadDemoScenario('hyderabad'));
    document.getElementById('btn-demo-mum')?.addEventListener('click', () => this.loadDemoScenario('mumbai'));
    document.getElementById('btn-reset-all')?.addEventListener('click', () => this.resetAllData());
    document.getElementById('btn-settings-modal')?.addEventListener('click', () => this.openModal('modal-settings'));
    document.getElementById('btn-depots-modal')?.addEventListener('click', () => this.openModal('modal-depots'));

    // Daily Indian Fuel Rates Selector & Sync
    document.getElementById('fuel-city-select')?.addEventListener('change', (e) => {
      this.switchDailyFuelCity(e.target.value);
    });

    document.getElementById('btn-sync-fuel')?.addEventListener('click', () => {
      const city = document.getElementById('fuel-city-select')?.value || 'Hyderabad';
      this.switchDailyFuelCity(city);
    });

    // Depot Fleet Checklist Select All / Deselect All
    document.getElementById('btn-select-all-vehicles')?.addEventListener('click', () => {
      this.selectAllVehicles(true);
    });

    document.getElementById('btn-deselect-all-vehicles')?.addEventListener('click', () => {
      this.selectAllVehicles(false);
    });

    // Traffic Condition Selector Change
    document.getElementById('traffic-condition-select')?.addEventListener('change', (e) => {
      const label = e.target.options[e.target.selectedIndex].text;
      this.showToast(`Traffic prediction profile set to: ${label}`);
    });

    // Simulation controls
    document.getElementById('btn-sim-play')?.addEventListener('click', () => {
      const isRunning = this.mapEngine.simulationRunning;
      if (isRunning) {
        this.mapEngine.stopSimulation();
        document.getElementById('btn-sim-play').innerHTML = '<span>▶ Simulate</span>';
      } else {
        if (this.routes.length === 0) {
          this.showToast('Please optimize routes first to simulate tracking.', 'error');
          return;
        }
        this.mapEngine.startSimulation(this.routes);
        document.getElementById('btn-sim-play').innerHTML = '<span>⏸ Pause</span>';
      }
    });

    document.getElementById('sim-speed-select')?.addEventListener('change', (e) => {
      this.mapEngine.setSimulationSpeed(Number(e.target.value));
    });

    // Vehicle Specs Presets & Dynamic Unit / Range Auto-Calculation
    document.getElementById('fleet-vehicle-type')?.addEventListener('change', () => {
      this.applyVehicleSpecs('fleet', true);
      const selName = document.getElementById('fleet-vehicle-type').value;
      this.showToast(`Auto-selected specs: ${selName}`);
    });

    document.getElementById('fleet-fuel-type')?.addEventListener('change', () => {
      this.updateDynamicVehicleUnits('fleet');
      this.recalculateMaxRange('fleet');
    });

    document.getElementById('fleet-fuel-efficiency')?.addEventListener('input', () => {
      this.recalculateMaxRange('fleet');
    });

    document.getElementById('fleet-tank-capacity')?.addEventListener('input', () => {
      this.recalculateMaxRange('fleet');
    });

    // Edit Vehicle Modal Listeners
    document.getElementById('edit-vehicle-type')?.addEventListener('change', () => {
      this.applyVehicleSpecs('edit', true);
      const selName = document.getElementById('edit-vehicle-type').value;
      this.showToast(`Auto-selected specs: ${selName}`);
    });

    document.getElementById('edit-fuel-type')?.addEventListener('change', () => {
      this.updateDynamicVehicleUnits('edit');
      this.recalculateMaxRange('edit');
    });

    document.getElementById('edit-fuel-efficiency')?.addEventListener('input', () => {
      this.recalculateMaxRange('edit');
    });

    document.getElementById('edit-tank-capacity')?.addEventListener('input', () => {
      this.recalculateMaxRange('edit');
    });

    document.getElementById('form-edit-vehicle')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const id = parseInt(document.getElementById('edit-vehicle-id').value, 10);
      const vehicleType = document.getElementById('edit-vehicle-type').value;
      const capacity = parseFloat(document.getElementById('edit-capacity').value);
      const fuelType = document.getElementById('edit-fuel-type').value;
      const fuelEfficiency = parseFloat(document.getElementById('edit-fuel-efficiency').value);
      const fuelTankCapacity = parseFloat(document.getElementById('edit-tank-capacity').value);
      const maximumRange = parseFloat(document.getElementById('edit-max-range').value);

      try {
        await API.updateVehicle(id, {
          vehicleType,
          capacity,
          fuelType,
          fuelEfficiency,
          fuelTankCapacity,
          maximumRange
        });
        this.closeModal('modal-edit-vehicle');
        await this.refreshAllData();
        this.showToast(`Vehicle specifications updated successfully!`);
      } catch (err) {
        this.showToast('Failed to update vehicle: ' + err.message, 'error');
      }
    });

    // Form Submissions
    document.getElementById('form-add-fleet')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const count = parseInt(document.getElementById('fleet-count').value, 10);
      const vehicleType = document.getElementById('fleet-vehicle-type').value;
      const capacity = parseFloat(document.getElementById('fleet-capacity').value);
      const fuelType = document.getElementById('fleet-fuel-type').value;
      const fuelEfficiency = parseFloat(document.getElementById('fleet-fuel-efficiency').value);
      const fuelTank = parseFloat(document.getElementById('fleet-tank-capacity').value);
      const maxRange = parseFloat(document.getElementById('fleet-max-range').value);
      const depotId = parseInt(document.getElementById('fleet-default-depot').value, 10);

      try {
        await API.generateFleet({
          count,
          vehicleType,
          capacity,
          fuelType,
          fuelEfficiency,
          fuelTankCapacity: fuelTank,
          maximumRange: maxRange,
          depotId
        });
        this.closeModal('modal-add-fleet');
        await this.refreshAllData();
        this.showToast(`Generated ${count} vehicles with realistic fictional Indian driver profiles!`);
      } catch (err) {
        this.showToast('Failed to create fleet: ' + err.message, 'error');
      }
    });

    document.getElementById('form-add-delivery')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const customerName = document.getElementById('deliv-customer').value;
      const address = document.getElementById('deliv-address').value;
      const product = document.getElementById('deliv-product').value;
      const weight = parseFloat(document.getElementById('deliv-weight').value);
      const priority = document.getElementById('deliv-priority').value;
      const timeWindowStart = document.getElementById('deliv-tw-start').value;
      const timeWindowEnd = document.getElementById('deliv-tw-end').value;
      const serviceTime = parseInt(document.getElementById('deliv-service-time').value, 10);
      const latVal = document.getElementById('deliv-lat')?.value;
      const lngVal = document.getElementById('deliv-lng')?.value;
      const latitude = latVal ? parseFloat(latVal) : null;
      const longitude = lngVal ? parseFloat(lngVal) : null;

      try {
        await API.addDelivery({
          customerName,
          address,
          product,
          weight,
          priority,
          timeWindowStart,
          timeWindowEnd,
          serviceTime,
          latitude,
          longitude
        });
        this.closeModal('modal-add-delivery');
        e.target.reset();
        await this.refreshAllData();
        this.showToast('Delivery order added and geocoded on map!');
      } catch (err) {
        this.showToast('Failed to add delivery: ' + err.message, 'error');
      }
    });

    // Address search autocomplete for Add Delivery
    const addressInput = document.getElementById('deliv-address');
    if (addressInput) {
      let timeout = null;
      addressInput.addEventListener('input', () => {
        clearTimeout(timeout);
        const q = addressInput.value.trim();
        if (q.length < 3) return;
        timeout = setTimeout(async () => {
          try {
            const data = await API.searchPlaces(q);
            const suggestionsDiv = document.getElementById('deliv-address-suggestions');
            if (suggestionsDiv && data.suggestions && data.suggestions.length) {
              suggestionsDiv.innerHTML = data.suggestions.map(s => `
                <div class="suggestion-item" style="padding: 6px 10px; cursor: pointer; border-bottom: 1px solid rgba(255,255,255,0.05); font-size: 0.8rem;" onclick="app.selectAddressSuggestion('${s.address.replace(/'/g, "\\'")}')">
                  <strong>${s.title}</strong> — <span style="color: #94a3b8;">${s.address}</span>
                </div>
              `).join('');
              suggestionsDiv.style.display = 'block';
            }
          } catch (e) {}
        }, 350);
      });
    }

    // Fuel settings form
    document.getElementById('form-fuel-settings')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const diesel = document.getElementById('set-price-diesel').value;
      const petrol = document.getElementById('set-price-petrol').value;
      const cng = document.getElementById('set-price-cng').value;
      const ev = document.getElementById('set-price-ev').value;
      const apiKey = document.getElementById('set-google-key').value;

      try {
        await API.updateSettings({
          price_diesel: diesel,
          price_petrol: petrol,
          price_cng: cng,
          price_electric: ev,
          google_maps_api_key: apiKey
        });
        this.closeModal('modal-settings');
        this.showToast('Settings updated. Recalculating costs...');
        await this.recalculate();
      } catch (err) {
        this.showToast('Failed to save settings: ' + err.message, 'error');
      }
    });

    // Depot filters in modal
    document.getElementById('filter-depot-state')?.addEventListener('change', (e) => {
      this.filterDepotsList();
    });
    document.getElementById('filter-depot-city')?.addEventListener('change', (e) => {
      this.filterDepotsList();
    });
    document.getElementById('filter-depot-search')?.addEventListener('input', (e) => {
      this.filterDepotsList();
    });

    // Pick Depot on Map
    document.getElementById('btn-pick-depot-map')?.addEventListener('click', () => {
      this.closeModal('modal-depots');
      this.showToast('Click anywhere on the map to set depot location pin 🏭', 'info');
      this.mapEngine.enableLocationPicker(async (lat, lng) => {
        let addr = `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
        let city = '';
        let state = '';
        try {
          const geo = await API.reverseGeocode(lat, lng);
          if (geo) {
            if (geo.address) addr = geo.address;
            if (geo.city) city = geo.city;
            if (geo.state) state = geo.state;
          }
        } catch (err) {}

        const addrInput = document.getElementById('depot-custom-address');
        const cityInput = document.getElementById('depot-custom-city');
        const stateInput = document.getElementById('depot-custom-state');
        const latInput = document.getElementById('depot-custom-lat');
        const lngInput = document.getElementById('depot-custom-lng');

        if (addrInput) addrInput.value = addr;
        if (cityInput && city) cityInput.value = city;
        if (stateInput && state) stateInput.value = state;
        if (latInput) latInput.value = lat.toFixed(6);
        if (lngInput) lngInput.value = lng.toFixed(6);

        this.openModal('modal-depots');
        this.showToast(`Depot coordinates picked: ${lat.toFixed(4)}, ${lng.toFixed(4)}`);
      });
    });

    // Add custom depot form
    document.getElementById('form-add-depot')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const name = document.getElementById('depot-custom-name').value;
      const city = document.getElementById('depot-custom-city').value;
      const state = document.getElementById('depot-custom-state').value;
      const address = document.getElementById('depot-custom-address').value;
      const depotType = document.getElementById('depot-custom-type').value;
      const latVal = document.getElementById('depot-custom-lat')?.value;
      const lngVal = document.getElementById('depot-custom-lng')?.value;
      const latitude = latVal ? parseFloat(latVal) : null;
      const longitude = lngVal ? parseFloat(lngVal) : null;

      try {
        await API.addDepot({ name, city, state, address, depotType, latitude, longitude });
        await this.loadDepots();
        this.renderDepotsModalList();
        e.target.reset();
        this.showToast('New Indian logistics depot added to network!');
      } catch (err) {
        this.showToast('Failed to add depot: ' + err.message, 'error');
      }
    });

    // Global Search Bar in Header with Live Dropdown
    const searchInput = document.getElementById('global-search');
    const searchDropdown = document.getElementById('search-results-dropdown');
    let searchDebounce = null;

    searchInput?.addEventListener('input', (e) => {
      const q = e.target.value.trim();
      this.filterDashboardTables(q.toLowerCase());
      clearTimeout(searchDebounce);

      if (!q) {
        if (searchDropdown) {
          searchDropdown.innerHTML = '';
          searchDropdown.style.display = 'none';
        }
        return;
      }

      searchDebounce = setTimeout(async () => {
        try {
          const results = await API.globalSearch(q);
          this.renderSearchResults(results, q);
        } catch (err) {
          console.error('Search error:', err);
        }
      }, 250);
    });

    // Close search dropdown on click outside
    document.addEventListener('click', (e) => {
      if (!e.target.closest('.header-search')) {
        if (searchDropdown) searchDropdown.style.display = 'none';
      }
    });
  }

  renderSearchResults(data, query) {
    const dropdown = document.getElementById('search-results-dropdown');
    if (!dropdown) return;

    const { depots = [], vehicles = [], deliveries = [], routes = [] } = data;
    const totalCount = depots.length + vehicles.length + deliveries.length + routes.length;

    if (totalCount === 0) {
      dropdown.innerHTML = `
        <div style="padding: 12px 16px; font-size: 0.78rem; color: #94a3b8; text-align: center;">
          No matching logistics records found for "<strong>${query}</strong>"
        </div>
      `;
      dropdown.style.display = 'block';
      return;
    }

    this.latestSearchResults = { depots, vehicles, deliveries, routes };
    let html = '';

    // Depots Group
    if (depots.length > 0) {
      html += `
        <div class="search-group">
          <div class="search-group-title"><span>🏭</span> Depots & Hubs (${depots.length})</div>
          ${depots.map((d, idx) => `
            <div class="search-item" onclick="app.selectSearchResultItem('depots', ${idx})">
              <div class="search-item-left">
                <span class="search-item-primary">${d.name} (${d.city})</span>
                <span class="search-item-secondary">${d.state} &bull; ${d.address}</span>
              </div>
              <span class="search-item-badge">${d.depotType || 'Hub'}</span>
            </div>
          `).join('')}
        </div>
      `;
    }

    // Deliveries Group
    if (deliveries.length > 0) {
      html += `
        <div class="search-group">
          <div class="search-group-title"><span>📦</span> Deliveries (${deliveries.length})</div>
          ${deliveries.map((d, idx) => `
            <div class="search-item" onclick="app.selectSearchResultItem('deliveries', ${idx})">
              <div class="search-item-left">
                <span class="search-item-primary">${d.orderId} &mdash; ${d.customerName}</span>
                <span class="search-item-secondary">${d.address} &bull; ${d.product} (${d.weight} kg)</span>
              </div>
              <span class="search-item-badge" style="color: ${d.priority === 'High' ? '#ef4444' : '#3b82f6'};">${d.priority}</span>
            </div>
          `).join('')}
        </div>
      `;
    }

    // Vehicles & Drivers Group
    if (vehicles.length > 0) {
      html += `
        <div class="search-group">
          <div class="search-group-title"><span>🚚</span> Fleet & Drivers (${vehicles.length})</div>
          ${vehicles.map((v, idx) => `
            <div class="search-item" onclick="app.selectSearchResultItem('vehicles', ${idx})">
              <div class="search-item-left">
                <span class="search-item-primary">${v.vehicleId} &bull; Driver: ${v.driverName || 'Assigned'}</span>
                <span class="search-item-secondary">${v.vehicleType} (${v.fuelType}) &bull; ${v.depotCity ? 'Hub: ' + v.depotCity : 'Central'}</span>
              </div>
              <span class="search-item-badge" style="color: #10b981;">★ ${v.driverRating || '4.8'}</span>
            </div>
          `).join('')}
        </div>
      `;
    }

    dropdown.innerHTML = html;
    dropdown.style.display = 'block';
  }

  selectSearchResultItem(category, index) {
    const list = this.latestSearchResults?.[category];
    if (!list || !list[index]) return;
    const item = list[index];

    const dropdown = document.getElementById('search-results-dropdown');
    if (dropdown) dropdown.style.display = 'none';

    if (category === 'depots') {
      if (item.latitude && item.longitude) {
        this.mapEngine.panToLocation(item.latitude, item.longitude, 13);
        this.showToast(`Navigated to Depot: ${item.name} (${item.city})`);
      }
    } else if (category === 'deliveries') {
      if (item.latitude && item.longitude) {
        this.mapEngine.panToLocation(item.latitude, item.longitude, 15);
        this.showToast(`Navigated to Delivery: ${item.orderId} - ${item.customerName}`);
      }
      this.switchView('deliveries');
    } else if (category === 'vehicles') {
      this.switchView('vehicles');
      this.showToast(`Selected Fleet Vehicle: ${item.vehicleId} (Driver: ${item.driverName || 'Assigned'})`);
      if (item.depotLat && item.depotLng) {
        this.mapEngine.panToLocation(item.depotLat, item.depotLng, 12);
      }
    }
  }

  selectAddressSuggestion(addr) {
    const input = document.getElementById('deliv-address');
    if (input) input.value = addr;
    const suggestionsDiv = document.getElementById('deliv-address-suggestions');
    if (suggestionsDiv) suggestionsDiv.style.display = 'none';
  }

  filterDashboardTables(q) {
    // Filter deliveries table rows
    const delivRows = document.querySelectorAll('#deliveries-table-body tr');
    delivRows.forEach(row => {
      const text = row.innerText.toLowerCase();
      row.style.display = (!q || text.includes(q)) ? '' : 'none';
    });
  }

  async filterDepotsList() {
    const state = document.getElementById('filter-depot-state')?.value || '';
    const city = document.getElementById('filter-depot-city')?.value || '';
    const search = document.getElementById('filter-depot-search')?.value || '';

    const data = await API.getDepots({ state, city, search });
    this.renderDepotsModalList(data.depots || []);
  }

  renderDepotsModalList(depots = this.depots) {
    const container = document.getElementById('depots-modal-list');
    if (!container) return;

    container.innerHTML = depots.map(d => `
      <div style="background: rgba(30, 41, 59, 0.6); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 8px; padding: 10px 14px; margin-bottom: 8px; display: flex; align-items: center; justify-content: space-between;">
        <div>
          <div style="font-weight: 700; color: #f8fafc; font-size: 0.85rem;">🏭 ${d.name}</div>
          <div style="font-size: 0.75rem; color: #94a3b8;">${d.city}, ${d.state} — <span style="color: #64748b;">${d.address}</span></div>
          <div style="font-size: 0.7rem; color: #f59e0b; margin-top: 2px;">${d.depotType} | Cap: ${Number(d.capacity).toLocaleString()} kg</div>
        </div>
        <button class="btn btn-sm btn-secondary" onclick="app.setFleetDepot(${d.id})">Select</button>
      </div>
    `).join('');
  }

  setFleetDepot(depotId) {
    const select = document.getElementById('fleet-default-depot');
    if (select) select.value = depotId;
    this.closeModal('modal-depots');
    this.showToast('Depot selected as starting point.');
  }

  switchView(view) {
    this.currentView = view;
    // Scroll smoothly to target section
    const targetMap = {
      'dashboard': 'sec-dashboard',
      'routes': 'sec-routes',
      'deliveries': 'sec-deliveries',
      'vehicles': 'sec-vehicles',
      'analytics': 'sec-analytics',
      'optimizer': 'sec-comparison'
    };
    const targetId = targetMap[view];
    if (targetId) {
      document.getElementById(targetId)?.scrollIntoView({ behavior: 'smooth' });
    }
  }

  openModal(modalId) {
    if (modalId === 'modal-settings') {
      document.getElementById('set-price-diesel').value = this.settings.price_diesel || 92.50;
      document.getElementById('set-price-petrol').value = this.settings.price_petrol || 104.20;
      document.getElementById('set-price-cng').value = this.settings.price_cng || 86.50;
      document.getElementById('set-price-ev').value = this.settings.price_electric || 12.00;
      document.getElementById('set-google-key').value = this.settings.google_maps_api_key || '';
    }
    if (modalId === 'modal-depots') {
      this.renderDepotsModalList();
    }
    document.getElementById(modalId)?.classList.add('active');
  }

  closeModal(modalId) {
    document.getElementById(modalId)?.classList.remove('active');
  }

  showToast(message, type = 'success') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.style.cssText = `
      background: ${type === 'error' ? 'rgba(239, 68, 68, 0.95)' : 'rgba(15, 23, 42, 0.95)'};
      backdrop-filter: blur(12px);
      border: 1px solid ${type === 'error' ? '#ef4444' : '#3b82f6'};
      color: #fff;
      padding: 10px 16px;
      border-radius: 8px;
      font-size: 0.82rem;
      margin-bottom: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.5);
      animation: fadeIn 0.3s ease;
      display: flex;
      align-items: center;
      gap: 8px;
    `;
    toast.innerHTML = `<span>${type === 'error' ? '⚠️' : '✓'}</span> <span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      setTimeout(() => toast.remove(), 300);
    }, 4000);
  }
}

// Global instance
const app = new LogisticsApp();
window.app = app;
window.addEventListener('DOMContentLoaded', () => app.init());
