// Analytics & Charts Controller (Chart.js integration)

class AnalyticsManager {
  constructor() {
    this.fuelChart = null;
    this.efficiencyChart = null;
  }

  updateKPIs(data) {
    if (!data) return;

    // Active Vehicles
    const activeVehEl = document.getElementById('kpi-active-vehicles');
    if (activeVehEl) {
      const v = data.activeVehicles;
      activeVehEl.textContent = (v && v !== '0 / 0' && v !== '0' && v !== '0 /') ? v : '--';
    }

    // Delivery Locations
    const delivEl = document.getElementById('kpi-deliveries');
    if (delivEl) {
      const count = Number(data.deliveryLocations || 0);
      delivEl.textContent = count > 0 ? count : '--';
    }

    // Total Distance
    const distEl = document.getElementById('kpi-total-distance');
    if (distEl) {
      const dist = Number(data.totalDistanceKm || 0);
      distEl.textContent = dist > 0 ? `${dist.toFixed(1)} km` : '--';
    }

    // Estimated Fuel Cost
    const costEl = document.getElementById('kpi-fuel-cost');
    if (costEl) {
      const cost = Number(data.totalFuelCostInr || 0);
      costEl.textContent = cost > 0 ? `₹${cost.toLocaleString('en-IN')}` : '--';
    }

    // Average Delivery Time
    const timeEl = document.getElementById('kpi-delivery-time');
    if (timeEl) {
      const mins = Math.round(data.averageDeliveryTimeMinutes || 0);
      timeEl.textContent = mins > 0 ? (mins >= 60 ? `${Math.floor(mins / 60)}h ${mins % 60}m` : `${mins} min`) : '--';
    }

    // Late Deliveries
    const lateEl = document.getElementById('kpi-late-deliveries');
    if (lateEl) {
      const lateCount = data.lateDeliveries;
      const hasDeliveries = Number(data.deliveryLocations || 0) > 0;
      if (!hasDeliveries || lateCount === undefined || lateCount === null) {
        lateEl.textContent = '--';
        lateEl.style.color = '#94a3b8';
      } else {
        lateEl.textContent = lateCount > 0 ? lateCount : '0';
        lateEl.style.color = lateCount > 0 ? '#ef4444' : '#10b981';
      }
    }
  }

  updateFuelAnalytics(analytics, routes = []) {
    if (!analytics) return;

    const totalFuel = Number(analytics.totalFuelLiters || 0);
    const avgEff = Number(analytics.averageFuelEfficiency || 0);
    const totalCost = Number(analytics.totalFuelCostInr || 0);
    const costKm = Number(analytics.costPerKm || 0);
    const costDeliv = Number(analytics.costPerDelivery || 0);
    const totalCo2 = Number(analytics.totalCo2Kg || 0);
    const co2Deliv = Number(analytics.co2PerDelivery || 0);
    const co2Saved = Number(analytics.co2SavedKg || 0);

    // Metrics elements
    const totalFuelEl = document.getElementById('analytics-total-fuel');
    if (totalFuelEl) totalFuelEl.textContent = totalFuel > 0 ? `${totalFuel.toFixed(1)} L` : '--';

    const avgEffEl = document.getElementById('analytics-avg-efficiency');
    if (avgEffEl) avgEffEl.textContent = avgEff > 0 ? `${avgEff.toFixed(1)} km/L` : '--';

    const totalCostEl = document.getElementById('analytics-total-cost');
    if (totalCostEl) totalCostEl.textContent = totalCost > 0 ? `₹${totalCost.toLocaleString('en-IN')}` : '--';

    const costKmEl = document.getElementById('analytics-cost-km');
    if (costKmEl) costKmEl.textContent = costKm > 0 ? `₹${costKm.toFixed(2)}` : '--';

    const costDelivEl = document.getElementById('analytics-cost-delivery');
    if (costDelivEl) costDelivEl.textContent = costDeliv > 0 ? `₹${costDeliv.toFixed(2)}` : '--';

    // CO2 elements
    const totalCo2El = document.getElementById('analytics-total-co2');
    if (totalCo2El) totalCo2El.textContent = totalCo2 > 0 ? `${totalCo2.toFixed(1)} kg` : '--';

    const co2DelivEl = document.getElementById('analytics-co2-deliv');
    if (co2DelivEl) co2DelivEl.textContent = co2Deliv > 0 ? `${co2Deliv.toFixed(2)} kg` : '--';

    const co2SavedEl = document.getElementById('analytics-co2-saved');
    if (co2SavedEl) co2SavedEl.textContent = co2Saved > 0 ? `${co2Saved.toFixed(1)} kg` : '--';

    // Render Charts
    this.renderFuelChart(routes);
    this.renderEfficiencyChart(routes);
  }

  renderFuelChart(routes) {
    const ctx = document.getElementById('chart-fuel-consumption');
    if (!ctx || !window.Chart) return;

    if (this.fuelChart) {
      this.fuelChart.destroy();
    }

    const labels = routes.map(r => r.vehicleId);
    const fuelData = routes.map(r => r.fuelUsedLiters || 0);
    const costData = routes.map(r => r.fuelCostInr || 0);

    this.fuelChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels.length ? labels : ['No Active Routes'],
        datasets: [
          {
            label: 'Fuel Used (Liters)',
            data: fuelData.length ? fuelData : [0],
            backgroundColor: 'rgba(59, 130, 246, 0.7)',
            borderColor: '#3b82f6',
            borderWidth: 1,
            borderRadius: 6,
            yAxisID: 'y'
          },
          {
            label: 'Fuel Cost (₹)',
            data: costData.length ? costData : [0],
            backgroundColor: 'rgba(168, 85, 247, 0.7)',
            borderColor: '#a855f7',
            borderWidth: 1,
            borderRadius: 6,
            yAxisID: 'y1'
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            labels: { color: '#94a3b8', font: { size: 11 } }
          }
        },
        scales: {
          x: {
            ticks: { color: '#94a3b8', font: { size: 10 } },
            grid: { color: 'rgba(255, 255, 255, 0.05)' }
          },
          y: {
            type: 'linear',
            position: 'left',
            ticks: { color: '#60a5fa', font: { size: 10 } },
            grid: { color: 'rgba(255, 255, 255, 0.05)' },
            title: { display: true, text: 'Liters', color: '#60a5fa', font: { size: 10 } }
          },
          y1: {
            type: 'linear',
            position: 'right',
            ticks: { color: '#c084fc', font: { size: 10 } },
            grid: { display: false },
            title: { display: true, text: 'INR (₹)', color: '#c084fc', font: { size: 10 } }
          }
        }
      }
    });
  }

  renderEfficiencyChart(routes) {
    const ctx = document.getElementById('chart-route-utilization');
    if (!ctx || !window.Chart) return;

    if (this.efficiencyChart) {
      this.efficiencyChart.destroy();
    }

    const labels = routes.map(r => r.vehicleId);
    const utilData = routes.map(r => r.utilizationPercent || 0);
    const colors = routes.map(r => r.color || '#3b82f6');

    this.efficiencyChart = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: labels.length ? labels : ['No Vehicles'],
        datasets: [{
          data: utilData.length ? utilData : [100],
          backgroundColor: colors.length ? colors : ['#334155'],
          borderColor: '#0f172a',
          borderWidth: 2
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'right',
            labels: { color: '#94a3b8', font: { size: 11 } }
          },
          tooltip: {
            callbacks: {
              label: (item) => ` ${item.label}: ${item.raw}% Utilization`
            }
          }
        },
        cutout: '65%'
      }
    });
  }

  updateComparisonTable(comparison) {
    const tbody = document.getElementById('comparison-table-body');
    if (!tbody) return;

    if (!comparison || (!comparison.distance?.after && !comparison.fuel?.after)) {
      tbody.innerHTML = `
        <tr>
          <td colspan="4" style="text-align: center; color: #64748b; padding: 24px;">
            Run route optimization to view real baseline vs optimized performance comparisons.
          </td>
        </tr>
      `;
      return;
    }

    const rows = [
      { key: 'distance', label: 'Total Distance', unit: 'km', ...comparison.distance },
      { key: 'fuel', label: 'Fuel Consumed', unit: 'L', ...comparison.fuel },
      { key: 'cost', label: 'Total Fuel Cost', unit: '₹', ...comparison.cost, isCurrency: true },
      { key: 'time', label: 'Travel Time', unit: 'min', ...comparison.time },
      { key: 'co2', label: 'CO₂ Emissions', unit: 'kg', ...comparison.co2 }
    ];

    tbody.innerHTML = rows.map(r => {
      const beforeStr = r.isCurrency ? `₹${Number(r.before || 0).toLocaleString('en-IN')}` : `${Number(r.before || 0).toFixed(1)} ${r.unit}`;
      const afterStr = r.isCurrency ? `₹${Number(r.after || 0).toLocaleString('en-IN')}` : `${Number(r.after || 0).toFixed(1)} ${r.unit}`;
      const savedStr = r.isCurrency ? `₹${Number(r.saved || 0).toLocaleString('en-IN')}` : `${Number(r.saved || 0).toFixed(1)} ${r.unit}`;

      return `
        <tr>
          <td style="font-weight: 600; color: #f8fafc;">${r.label}</td>
          <td style="color: #94a3b8;">${beforeStr}</td>
          <td style="color: #60a5fa; font-weight: 700;">${afterStr}</td>
          <td>
            <span class="savings-pill">
              <span>↓</span> ${savedStr} (${r.savedPercent || 0}%)
            </span>
          </td>
        </tr>
      `;
    }).join('');
  }
}
