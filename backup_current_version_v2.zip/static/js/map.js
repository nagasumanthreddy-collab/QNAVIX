// India-Wide Route Optimization - Map Engine
// Supports both Leaflet (Zero-config out of box) & Native Google Maps JavaScript API

class MapEngine {
  constructor(containerId = 'map') {
    this.containerId = containerId;
    this.mode = 'leaflet'; // 'leaflet' or 'google'
    this.map = null;
    this.tileLayer = null;
    this.depotMarkers = [];
    this.deliveryMarkers = [];
    this.routePolylines = [];
    this.vehicleMarkers = [];
    this.currentTileStyle = 'dark'; // 'dark', 'satellite', 'street'
    this.simulationRunning = false;
    this.simSpeed = 1;
    this.simAnimFrame = null;
    this.googleApiKey = null;
    this.pickerActive = false;
    this.pickerCallback = null;
    this.pickerMarker = null;
  }

  init(googleApiKey = '') {
    this.googleApiKey = googleApiKey;
    if (googleApiKey && window.google && window.google.maps) {
      this.initGoogleMap();
    } else {
      this.initLeafletMap();
    }
  }

  // ==================== LEAFLET ENGINE ====================
  initLeafletMap() {
    this.mode = 'leaflet';
    const container = document.getElementById(this.containerId);
    if (!container) return;

    // Centered on India
    this.map = L.map(this.containerId, {
      center: [20.5937, 78.9629],
      zoom: 5,
      zoomControl: true
    });

    this.map.on('click', (e) => this.handleMapClick(e.latlng.lat, e.latlng.lng));

    this.setTileLayer('dark');
  }

  setTileLayer(style) {
    this.currentTileStyle = style;
    if (this.mode !== 'leaflet') return;

    if (this.tileLayer) {
      this.map.removeLayer(this.tileLayer);
    }

    if (style === 'dark') {
      this.tileLayer = L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; CartoDB & OpenStreetMap',
        maxZoom: 19
      });
    } else if (style === 'satellite') {
      this.tileLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        attribution: '&copy; Esri & Maxar',
        maxZoom: 18
      });
    } else {
      // Standard Roadmap
      this.tileLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors',
        maxZoom: 19
      });
    }

    this.tileLayer.on('tileerror', () => {
      this.showOfflineNotice();
    });

    this.tileLayer.on('load', () => {
      this.hideOfflineNotice();
    });

    this.tileLayer.addTo(this.map);
  }

  showOfflineNotice() {
    let notice = document.getElementById('map-offline-badge');
    if (!notice) {
      const container = document.getElementById(this.containerId);
      if (container) {
        notice = document.createElement('div');
        notice.id = 'map-offline-badge';
        notice.className = 'map-offline-notice';
        notice.innerHTML = '<span>⚡ Offline Navigation Grid Active (Local GPS Coordinates)</span>';
        container.style.position = 'relative';
        container.appendChild(notice);
      }
    }
    if (notice) notice.style.display = 'flex';
  }

  hideOfflineNotice() {
    const notice = document.getElementById('map-offline-badge');
    if (notice) notice.style.display = 'none';
  }

  // ==================== GOOGLE MAPS ENGINE ====================
  initGoogleMap() {
    this.mode = 'google';
    const container = document.getElementById(this.containerId);
    if (!container) return;

    this.map = new google.maps.Map(container, {
      center: { lat: 20.5937, lng: 78.9629 },
      zoom: 5,
      mapTypeId: this.currentTileStyle === 'satellite' ? 'hybrid' : 'roadmap',
      styles: this.currentTileStyle === 'dark' ? this.getGoogleDarkStyles() : []
    });

    this.map.addListener('click', (e) => {
      this.handleMapClick(e.latLng.lat(), e.latLng.lng());
    });
  }

  getGoogleDarkStyles() {
    return [
      { elementType: "geometry", stylers: [{ color: "#1d2c4d" }] },
      { elementType: "labels.text.fill", stylers: [{ color: "#8ec3b9" }] },
      { elementType: "labels.text.stroke", stylers: [{ color: "#1a3646" }] },
      { featureType: "administrative.country", elementType: "geometry.stroke", stylers: [{ color: "#4b6878" }] },
      { featureType: "road", elementType: "geometry", stylers: [{ color: "#304a7d" }] },
      { featureType: "road", elementType: "geometry.stroke", stylers: [{ color: "#1f2835" }] },
      { featureType: "water", elementType: "geometry", stylers: [{ color: "#0e1626" }] }
    ];
  }

  // ==================== MARKERS & POLYLINES ====================
  clearAll() {
    this.stopSimulation();

    if (this.mode === 'leaflet') {
      this.depotMarkers.forEach(m => this.map.removeLayer(m));
      this.deliveryMarkers.forEach(m => this.map.removeLayer(m));
      this.routePolylines.forEach(p => this.map.removeLayer(p));
      this.vehicleMarkers.forEach(v => this.map.removeLayer(v));
    } else if (this.mode === 'google') {
      this.depotMarkers.forEach(m => m.setMap(null));
      this.deliveryMarkers.forEach(m => m.setMap(null));
      this.routePolylines.forEach(p => p.setMap(null));
      this.vehicleMarkers.forEach(v => v.setMap(null));
    }

    this.depotMarkers = [];
    this.deliveryMarkers = [];
    this.routePolylines = [];
    this.vehicleMarkers = [];
  }

  renderDepots(depots, routes = []) {
    depots.forEach(depot => {
      // Calculate vehicles and deliveries assigned to this depot
      const assignedRoutes = routes.filter(r => r.depot && r.depot.id === depot.id);
      const vehicleCount = assignedRoutes.length;
      let deliveryCount = 0;
      let totalDist = 0;
      assignedRoutes.forEach(r => {
        deliveryCount += (r.stops ? r.stops.filter(s => s.type === 'delivery').length : 0);
        totalDist += (r.totalDistanceKm || 0);
      });

      const popupHtml = `
        <div style="font-family: inherit; font-size: 13px; line-height: 1.4; min-width: 200px;">
          <div style="font-weight: 700; color: #f59e0b; margin-bottom: 4px; display: flex; align-items: center; gap: 6px;">
            <span>🏭</span> ${depot.name}
          </div>
          <div style="color: #94a3b8; font-size: 11px; margin-bottom: 8px;">${depot.address}</div>
          <div style="border-top: 1px solid rgba(255,255,255,0.1); padding-top: 6px;">
            <div style="display: flex; justify-content: space-between; margin-bottom: 3px;">
              <span style="color: #64748b;">Assigned Vehicles:</span>
              <strong style="color: #60a5fa;">${vehicleCount}</strong>
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 3px;">
              <span style="color: #64748b;">Deliveries:</span>
              <strong style="color: #34d399;">${deliveryCount}</strong>
            </div>
            <div style="display: flex; justify-content: space-between;">
              <span style="color: #64748b;">Total Route Dist:</span>
              <strong style="color: #f8fafc;">${totalDist.toFixed(1)} km</strong>
            </div>
          </div>
        </div>
      `;

      if (this.mode === 'leaflet') {
        const icon = L.divIcon({
          className: 'custom-depot-marker',
          html: `<div style="width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; font-size: 15px;">🏭</div>`,
          iconSize: [28, 28],
          iconAnchor: [14, 14]
        });
        const marker = L.marker([depot.latitude, depot.longitude], { icon })
          .bindPopup(popupHtml)
          .addTo(this.map);
        this.depotMarkers.push(marker);
      } else if (this.mode === 'google') {
        const marker = new google.maps.Marker({
          position: { lat: depot.latitude, lng: depot.longitude },
          map: this.map,
          title: depot.name,
          icon: {
            url: "https://maps.google.com/mapfiles/kml/shapes/warehouse.png",
            scaledSize: new google.maps.Size(32, 32)
          }
        });
        const infoWindow = new google.maps.InfoWindow({ content: popupHtml });
        marker.addListener('click', () => infoWindow.open(this.map, marker));
        this.depotMarkers.push(marker);
      }
    });
  }

  renderDeliveries(deliveries) {
    deliveries.forEach((d, idx) => {
      const label = `D${idx + 1}`;
      const priColor = d.priority === 'Critical' ? '#ef4444' : (d.priority === 'High' ? '#f97316' : '#06b6d4');
      
      const popupHtml = `
        <div style="font-family: inherit; font-size: 13px; line-height: 1.4; min-width: 220px;">
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 4px;">
            <strong style="color: ${priColor}; font-size: 14px;">${label} — ${d.orderId}</strong>
            <span style="font-size: 10px; background: rgba(255,255,255,0.1); padding: 2px 6px; border-radius: 4px; color: ${priColor}; font-weight: 700;">${d.priority}</span>
          </div>
          <div style="font-weight: 600; color: #f8fafc; margin-bottom: 2px;">${d.customerName}</div>
          <div style="color: #94a3b8; font-size: 11px; margin-bottom: 8px;">${d.address}</div>
          <div style="border-top: 1px solid rgba(255,255,255,0.1); padding-top: 6px; font-size: 11px;">
            <div style="display: flex; justify-content: space-between; margin-bottom: 2px;">
              <span style="color: #64748b;">Product & Weight:</span>
              <strong style="color: #e2e8f0;">${d.product || 'Goods'} (${d.weight} kg)</strong>
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 2px;">
              <span style="color: #64748b;">Time Window:</span>
              <strong style="color: #e2e8f0;">${d.timeWindowStart} - ${d.timeWindowEnd}</strong>
            </div>
            <div style="display: flex; justify-content: space-between;">
              <span style="color: #64748b;">ETA / Vehicle:</span>
              <strong style="color: ${d.eta ? '#34d399' : '#94a3b8'};">${d.eta || 'Pending'} (${d.assignedVehicle || 'Unassigned'})</strong>
            </div>
          </div>
        </div>
      `;

      if (this.mode === 'leaflet') {
        const icon = L.divIcon({
          className: 'custom-delivery-marker',
          html: `<div style="width: 24px; height: 24px; background: ${priColor}; border-radius: 50%; color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 10px; border: 2px solid #ffffff; box-shadow: 0 0 10px ${priColor};">${label}</div>`,
          iconSize: [24, 24],
          iconAnchor: [12, 12]
        });
        const marker = L.marker([d.latitude, d.longitude], { icon })
          .bindPopup(popupHtml)
          .addTo(this.map);
        this.deliveryMarkers.push(marker);
      } else if (this.mode === 'google') {
        const marker = new google.maps.Marker({
          position: { lat: d.latitude, lng: d.longitude },
          map: this.map,
          label: {
            text: label,
            color: '#ffffff',
            fontWeight: 'bold',
            fontSize: '11px'
          }
        });
        const infoWindow = new google.maps.InfoWindow({ content: popupHtml });
        marker.addListener('click', () => infoWindow.open(this.map, marker));
        this.deliveryMarkers.push(marker);
      }
    });
  }

  renderRoutes(routes) {
    if (!routes || routes.length === 0) return;

    routes.forEach(r => {
      const poly = r.polyline || r.coordinates || [];
      if (poly.length < 2) return;

      const color = r.color || '#3b82f6';
      const trafficColor = r.trafficColor || r.traffic_color || color;
      const trafficSummary = r.trafficSummary || r.traffic_desc || 'Indian Traffic Model';
      const trafficDelay = r.trafficDelayMinutes || 0;

      if (this.mode === 'leaflet') {
        // Glowing background polyline effect
        const bgLine = L.polyline(poly, {
          color: color,
          weight: 7,
          opacity: 0.35
        }).addTo(this.map);

        // Traffic-aware active polyline with traffic congestion color
        const mainLine = L.polyline(poly, {
          color: trafficColor,
          weight: 4,
          opacity: 0.95,
          dashArray: '8, 6'
        }).addTo(this.map);

        const popupContent = `
          <div style="font-family: inherit; font-size: 12px; min-width: 170px;">
            <div style="font-weight: 700; color: ${color}; margin-bottom: 4px;">🚚 Vehicle Route: ${r.vehicleId}</div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 2px;">
              <span style="color: #64748b;">Distance:</span>
              <strong>${Number(r.totalDistanceKm || 0).toFixed(1)} km</strong>
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 2px;">
              <span style="color: #64748b;">Travel Time:</span>
              <strong>${Math.round(r.travelTimeMinutes || 0)} min</strong>
            </div>
            <div style="margin-top: 6px; padding: 4px 6px; border-radius: 4px; background: rgba(15,23,42,0.8); border-left: 3px solid ${trafficColor};">
              <div style="font-size: 11px; font-weight: 600; color: ${trafficColor};">🚦 ${trafficSummary}</div>
              <div style="font-size: 10px; color: #94a3b8;">Traffic Idling Delay: +${Math.round(trafficDelay)} min</div>
            </div>
          </div>
        `;
        mainLine.bindPopup(popupContent);

        this.routePolylines.push(bgLine);
        this.routePolylines.push(mainLine);
      } else if (this.mode === 'google') {
        const pathCoords = poly.map(pt => ({ lat: pt[0], lng: pt[1] }));
        const line = new google.maps.Polyline({
          path: pathCoords,
          geodesic: true,
          strokeColor: trafficColor,
          strokeOpacity: 0.9,
          strokeWeight: 4,
          map: this.map
        });
        this.routePolylines.push(line);
      }
    });
  }

  fitBoundsToLocations(allPoints) {
    if (!allPoints || allPoints.length === 0) {
      // Default to Center of India
      if (this.mode === 'leaflet' && this.map) {
        this.map.setView([20.5937, 78.9629], 5);
      } else if (this.mode === 'google' && this.map) {
        this.map.setCenter({ lat: 20.5937, lng: 78.9629 });
        this.map.setZoom(5);
      }
      return;
    }

    if (this.mode === 'leaflet' && this.map) {
      const bounds = L.latLngBounds(allPoints.map(p => [p.lat || p.latitude, p.lng || p.longitude]));
      this.map.fitBounds(bounds, { padding: [50, 50], maxZoom: 14 });
    } else if (this.mode === 'google' && this.map) {
      const bounds = new google.maps.LatLngBounds();
      allPoints.forEach(p => {
        bounds.extend({ lat: p.lat || p.latitude, lng: p.lng || p.longitude });
      });
      this.map.fitBounds(bounds);
    }
  }

  // ==================== LIVE SIMULATION MODE ====================
  startSimulation(routes, onUpdate = null) {
    this.stopSimulation();
    if (!routes || routes.length === 0) return;

    this.simulationRunning = true;
    const simVehicles = [];

    routes.forEach(r => {
      const poly = r.polyline || r.coordinates || [];
      if (poly.length > 1) {
        simVehicles.push({
          vehicleId: r.vehicleId,
          color: r.color || '#3b82f6',
          poly: poly,
          currIndex: 0,
          progress: 0.0,
          marker: null
        });
      }
    });

    if (simVehicles.length === 0) return;

    // Create marker for each simulated vehicle
    simVehicles.forEach(v => {
      const startPt = v.poly[0];
      if (this.mode === 'leaflet') {
        const icon = L.divIcon({
          className: 'custom-vehicle-marker',
          html: `<div style="background: ${v.color}; width: 26px; height: 26px; border-radius: 50%; border: 2px solid #fff; display: flex; align-items: center; justify-content: center; font-size: 14px; box-shadow: 0 0 12px ${v.color};">🚚</div>`,
          iconSize: [26, 26],
          iconAnchor: [13, 13]
        });
        v.marker = L.marker(startPt, { icon }).addTo(this.map);
        this.vehicleMarkers.push(v.marker);
      } else if (this.mode === 'google') {
        v.marker = new google.maps.Marker({
          position: { lat: startPt[0], lng: startPt[1] },
          map: this.map,
          title: `Vehicle ${v.vehicleId}`
        });
        this.vehicleMarkers.push(v.marker);
      }
    });

    const step = () => {
      if (!this.simulationRunning) return;

      simVehicles.forEach(v => {
        v.progress += 0.015 * this.simSpeed;
        if (v.progress >= 1.0) {
          v.progress = 0.0;
          v.currIndex = (v.currIndex + 1) % (v.poly.length - 1);
        }

        const p1 = v.poly[v.currIndex];
        const p2 = v.poly[Math.min(v.currIndex + 1, v.poly.length - 1)];

        const lat = p1[0] + (p2[0] - p1[0]) * v.progress;
        const lng = p1[1] + (p2[1] - p1[1]) * v.progress;

        if (this.mode === 'leaflet' && v.marker) {
          v.marker.setLatLng([lat, lng]);
        } else if (this.mode === 'google' && v.marker) {
          v.marker.setPosition({ lat, lng });
        }
      });

      if (onUpdate) onUpdate();
      this.simAnimFrame = requestAnimationFrame(step);
    };

    this.simAnimFrame = requestAnimationFrame(step);
  }

  stopSimulation() {
    this.simulationRunning = false;
    if (this.simAnimFrame) {
      cancelAnimationFrame(this.simAnimFrame);
      this.simAnimFrame = null;
    }
    if (this.mode === 'leaflet') {
      this.vehicleMarkers.forEach(m => this.map && this.map.removeLayer(m));
    } else if (this.mode === 'google') {
      this.vehicleMarkers.forEach(m => m.setMap(null));
    }
    this.vehicleMarkers = [];
  }

  setSimulationSpeed(speed) {
    this.simSpeed = speed;
  }

  // ==================== LOCATION PICKER & GEOLOCATION ====================
  handleMapClick(lat, lng) {
    if (this.pickerActive && this.pickerCallback) {
      this.dropPickerPin(lat, lng);
      const cb = this.pickerCallback;
      this.disableLocationPicker();
      cb({ lat, lng });
    }
  }

  enableLocationPicker(callback) {
    this.pickerActive = true;
    this.pickerCallback = callback;
    const container = document.getElementById(this.containerId);
    if (container) container.style.cursor = 'crosshair';

    let banner = document.getElementById('map-picker-banner');
    if (!banner) {
      banner = document.createElement('div');
      banner.id = 'map-picker-banner';
      banner.className = 'map-picker-banner';
      const mapCard = container.closest('.map-container-card') || container.parentNode;
      mapCard.appendChild(banner);
    }
    banner.innerHTML = `
      <span>📍 <strong>Location Picker Active:</strong> Click anywhere on the map to set location</span>
      <button class="btn btn-sm btn-secondary" onclick="app.mapEngine.disableLocationPicker()" style="padding: 3px 8px; font-size: 0.72rem;">Cancel</button>
    `;
    banner.style.display = 'flex';
  }

  disableLocationPicker() {
    this.pickerActive = false;
    this.pickerCallback = null;
    const container = document.getElementById(this.containerId);
    if (container) container.style.cursor = '';
    const banner = document.getElementById('map-picker-banner');
    if (banner) banner.style.display = 'none';
  }

  dropPickerPin(lat, lng) {
    if (this.pickerMarker) {
      if (this.mode === 'leaflet') this.map.removeLayer(this.pickerMarker);
      else if (this.mode === 'google') this.pickerMarker.setMap(null);
    }

    if (this.mode === 'leaflet') {
      const icon = L.divIcon({
        className: 'custom-picker-pin',
        html: `<div style="width: 32px; height: 32px; background: #ec4899; border-radius: 50%; color: #fff; display: flex; align-items: center; justify-content: center; font-size: 16px; border: 2px solid #fff; box-shadow: 0 0 16px #ec4899;">📍</div>`,
        iconSize: [32, 32],
        iconAnchor: [16, 32]
      });
      this.pickerMarker = L.marker([lat, lng], { icon }).addTo(this.map);
    } else if (this.mode === 'google') {
      this.pickerMarker = new google.maps.Marker({
        position: { lat, lng },
        map: this.map,
        animation: google.maps.Animation.DROP
      });
    }
  }

  panToLocation(lat, lng, zoom = 14) {
    if (this.mode === 'leaflet' && this.map) {
      this.map.flyTo([lat, lng], zoom, { duration: 1.2 });
    } else if (this.mode === 'google' && this.map) {
      this.map.panTo({ lat, lng });
      this.map.setZoom(zoom);
    }
  }

  locateCurrentPosition(callback) {
    if (!navigator.geolocation) {
      if (window.app) window.app.showToast('Geolocation is not supported by your browser.', 'error');
      return;
    }
    if (window.app) window.app.showToast('Acquiring your GPS location...');
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        this.panToLocation(lat, lng, 14);
        this.dropPickerPin(lat, lng);
        if (callback) callback({ lat, lng });
        if (window.app) window.app.showToast(`Located: ${lat.toFixed(4)}°N, ${lng.toFixed(4)}°E`);
      },
      (err) => {
        console.warn('Geolocation warning:', err);
        if (window.app) window.app.showToast('GPS permission denied or unavailable. Centered on Hyderabad Hub.', 'error');
        this.panToLocation(17.3850, 78.4867, 12);
      },
      { enableHighAccuracy: true, timeout: 7000 }
    );
  }
}

