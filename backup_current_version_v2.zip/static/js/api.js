// Hybrid API Client - Seamless Online / Offline Engine
// Automatically connects to Flask backend when online, and gracefully
// falls back to client-side OfflineEngine when running offline or standalone!

const API = {
  isOffline: false,
  offlineEngine: window.offlineEngine,

  initStatusListeners() {
    // Detect file:// protocol
    if (window.location.protocol === 'file:') {
      this.isOffline = true;
      this.notifyStatusChange(true);
    }

    // Listen to browser online/offline events
    window.addEventListener('offline', () => {
      this.isOffline = true;
      this.notifyStatusChange(true);
    });

    window.addEventListener('online', () => {
      this.checkServerHealth();
    });

    // Check health once on startup
    this.checkServerHealth();
  },

  async checkServerHealth() {
    if (window.location.protocol === 'file:') {
      this.isOffline = true;
      this.notifyStatusChange(true);
      return;
    }

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 2000);
      const res = await fetch('/api/settings', { signal: controller.signal });
      clearTimeout(timeoutId);
      if (res.ok) {
        this.isOffline = false;
        this.notifyStatusChange(false);
      } else {
        this.isOffline = true;
        this.notifyStatusChange(true);
      }
    } catch (e) {
      this.isOffline = true;
      this.notifyStatusChange(true);
    }
  },

  notifyStatusChange(isOffline) {
    this.isOffline = isOffline;
    const badge = document.getElementById('offline-status-indicator');
    if (badge) {
      if (isOffline) {
        badge.innerHTML = '<span class="status-dot offline"></span> <span>⚡ Offline Mode (Local Engine)</span>';
        badge.className = 'connection-status-pill offline';
        badge.title = 'Running locally in-browser with offline quantum heuristics & storage.';
      } else {
        badge.innerHTML = '<span class="status-dot online"></span> <span>🟢 Cloud / Server Connected</span>';
        badge.className = 'connection-status-pill online';
        badge.title = 'Synchronized live with QNAVIX logistics backend.';
      }
    }
  },

  // Base HTTP Methods with Automatic Offline Fallback
  async get(url, fallbackFn) {
    if (this.isOffline || window.location.protocol === 'file:') {
      return fallbackFn ? fallbackFn() : null;
    }

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 3500);
      const res = await fetch(url, { signal: controller.signal });
      clearTimeout(timeoutId);

      if (!res.ok) throw new Error(`HTTP error ${res.status}`);
      return await res.json();
    } catch (err) {
      console.warn(`[QNAVIX API] Network unavailable for ${url}, switching to OfflineEngine.`, err);
      this.isOffline = true;
      this.notifyStatusChange(true);
      return fallbackFn ? fallbackFn() : null;
    }
  },

  async post(url, data = {}, fallbackFn) {
    if (this.isOffline || window.location.protocol === 'file:') {
      return fallbackFn ? fallbackFn() : null;
    }

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 6000);
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
        signal: controller.signal
      });
      clearTimeout(timeoutId);

      if (!res.ok) throw new Error(`HTTP error ${res.status}`);
      return await res.json();
    } catch (err) {
      console.warn(`[QNAVIX API] Network unavailable for POST ${url}, switching to OfflineEngine.`, err);
      this.isOffline = true;
      this.notifyStatusChange(true);
      return fallbackFn ? fallbackFn() : null;
    }
  },

  async put(url, data = {}, fallbackFn) {
    if (this.isOffline || window.location.protocol === 'file:') {
      return fallbackFn ? fallbackFn() : null;
    }

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000);
      const res = await fetch(url, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
        signal: controller.signal
      });
      clearTimeout(timeoutId);

      if (!res.ok) throw new Error(`HTTP error ${res.status}`);
      return await res.json();
    } catch (err) {
      this.isOffline = true;
      this.notifyStatusChange(true);
      return fallbackFn ? fallbackFn() : null;
    }
  },

  async delete(url, fallbackFn) {
    if (this.isOffline || window.location.protocol === 'file:') {
      return fallbackFn ? fallbackFn() : null;
    }

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000);
      const res = await fetch(url, { method: 'DELETE', signal: controller.signal });
      clearTimeout(timeoutId);

      if (!res.ok) throw new Error(`HTTP error ${res.status}`);
      return await res.json();
    } catch (err) {
      this.isOffline = true;
      this.notifyStatusChange(true);
      return fallbackFn ? fallbackFn() : null;
    }
  },

  // ==================== ENDPOINT METHODS ====================

  // Depots
  getDepots(params = {}) {
    const qs = new URLSearchParams(params).toString();
    return this.get(`/api/depots${qs ? '?' + qs : ''}`, () => window.offlineEngine.getDepots(params));
  },
  addDepot(data) {
    return this.post('/api/depots', data, () => window.offlineEngine.addDepot(data));
  },
  deleteDepot(id) {
    return this.delete(`/api/depots/${id}`, () => window.offlineEngine.deleteDepot(id));
  },

  // Vehicles & Drivers
  getVehicles() {
    return this.get('/api/vehicles', () => window.offlineEngine.getVehicles());
  },
  generateFleet(data) {
    return this.post('/api/vehicles/generate', data, () => window.offlineEngine.generateFleet(data));
  },
  updateVehicle(id, data) {
    return this.put(`/api/vehicles/${id}`, data, () => window.offlineEngine.updateVehicle(id, data));
  },
  deleteVehicle(id) {
    return this.delete(`/api/vehicles/${id}`, () => window.offlineEngine.deleteVehicle(id));
  },
  clearVehicles() {
    return this.post('/api/vehicles/clear', {}, () => window.offlineEngine.clearVehicles());
  },
  updateDriver(driverId, data) {
    return this.put(`/api/drivers/${driverId}`, data, () => ({ success: true }));
  },

  // Deliveries
  getDeliveries() {
    return this.get('/api/deliveries', () => window.offlineEngine.getDeliveries());
  },
  addDelivery(data) {
    return this.post('/api/deliveries', data, () => window.offlineEngine.addDelivery(data));
  },
  deleteDelivery(id) {
    return this.delete(`/api/deliveries/${id}`, () => window.offlineEngine.deleteDelivery(id));
  },
  clearDeliveries() {
    return this.post('/api/deliveries/clear', {}, () => window.offlineEngine.clearDeliveries());
  },

  // Geocoding & Autocomplete
  geocode(q) {
    return this.get(`/api/geocode?q=${encodeURIComponent(q)}`, () => window.offlineEngine.geocode(q));
  },
  reverseGeocode(lat, lng) {
    return this.get(`/api/reverse-geocode?lat=${lat}&lng=${lng}`, () => window.offlineEngine.reverseGeocode(lat, lng));
  },
  searchPlaces(q) {
    return this.get(`/api/places/search?q=${encodeURIComponent(q)}`, () => window.offlineEngine.searchPlaces(q));
  },
  globalSearch(q) {
    return this.get(`/api/search?q=${encodeURIComponent(q)}`, () => window.offlineEngine.globalSearch(q));
  },

  // Optimization & Recalculation
  optimize(autoDepot = false, selectedVehicleIds = null, trafficCondition = 'auto') {
    return this.post('/api/optimize', { autoDepot, selectedVehicleIds, trafficCondition }, () => window.offlineEngine.optimize(autoDepot, selectedVehicleIds, trafficCondition));
  },
  recalculate() {
    return this.post('/api/recalculate', {}, () => window.offlineEngine.recalculate());
  },

  // Daily Indian Fuel Rates
  getDailyFuelRates(city = 'Hyderabad') {
    return this.get(`/api/fuel/daily-rates?city=${encodeURIComponent(city)}`, () => window.offlineEngine.getDailyFuelRates(city));
  },
  syncDailyFuelRates(city = 'Hyderabad') {
    return this.post('/api/fuel/daily-rates', { city }, () => window.offlineEngine.syncDailyRates(city));
  },

  // Settings
  getSettings() {
    return this.get('/api/settings', () => window.offlineEngine.getSettings());
  },
  updateSettings(data) {
    return this.post('/api/settings', data, () => window.offlineEngine.updateSettings(data));
  },

  // Scenarios
  loadDemo(city = 'hyderabad') {
    return this.post('/api/demo/load', { city }, () => window.offlineEngine.loadDemo(city));
  },
  resetAll() {
    return this.post('/api/reset', {}, () => window.offlineEngine.resetAll());
  },

  // Download export
  downloadReport(category = 'routes') {
    if (this.isOffline || window.location.protocol === 'file:') {
      window.offlineEngine.downloadReport(category);
    } else {
      window.location.href = `/api/reports/export?category=${category}`;
    }
  }
};

// Initialize listeners immediately
API.initStatusListeners();
