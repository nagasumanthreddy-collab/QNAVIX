import random

FIRST_NAMES = [
    "Rajesh", "Suresh", "Amit", "Vikram", "Manoj", "Rahul", "Dinesh", "Sanjay", 
    "Anil", "Pradeep", "Sunil", "Ramesh", "Deepak", "Ajay", "Kishore", "Arun",
    "Ganesh", "Mahesh", "Vijay", "Satish", "Naveen", "Praveen", "Ashok", "Karthik",
    "Mohan", "Harish", "Santosh", "Venkatesh", "Ravi", "Gopal", "Mukesh", "Anand"
]

LAST_NAMES = [
    "Sharma", "Verma", "Patel", "Singh", "Yadav", "Kumar", "Reddy", "Gupta",
    "Nair", "Rao", "Joshi", "Chauhan", "Mishra", "Deshmukh", "Pawar", "Bose",
    "Mukherjee", "Das", "Choudhury", "Pillai", "Iyer", "Menon", "Bhat", "Mehta",
    "Shah", "Soni", "Agarwal", "Trivedi", "Pandey", "Kulkarni", "Patil", "Naidu"
]

LICENSE_TYPES = [
    "HMV - Heavy Transport",
    "LMV - Commercial Freight",
    "LMV - Commercial Light Cargo",
    "Commercial Heavy Carrier"
]

def generate_driver(vehicle_id, index=1):
    first = random.choice(FIRST_NAMES)
    last = random.choice(LAST_NAMES)
    name = f"{first} {last}"
    
    age = random.randint(27, 54)
    experience = max(3, age - random.randint(21, 26))
    rating = round(random.uniform(4.4, 4.9), 1)
    
    phone_prefix = random.choice(["98", "97", "99", "94", "93", "88", "87", "70"])
    phone_mid = random.randint(100, 999)
    phone_last = random.randint(1000, 9999)
    phone = f"+91-{phone_prefix}{phone_mid}-{phone_last}"
    
    driver_id = f"DRV-{100 + index}"
    license_type = random.choice(LICENSE_TYPES)
    
    return {
        "driverId": driver_id,
        "name": name,
        "age": age,
        "experience": experience,
        "phone": phone,
        "licenseType": license_type,
        "rating": rating,
        "vehicleId": vehicle_id,
        "status": "Active"
    }
