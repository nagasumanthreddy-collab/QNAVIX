import math
import random
import datetime
from routing import haversine_distance, RoutingService

PRIORITY_WEIGHTS = {
    "Critical": 4.0,
    "High": 2.5,
    "Medium": 1.5,
    "Low": 1.0
}

def parse_time_to_minutes(time_str):
    """Convert 'HH:MM' string to minutes from midnight."""
    try:
        parts = time_str.split(':')
        return int(parts[0]) * 60 + int(parts[1])
    except Exception:
        return 10 * 60  # Default 10:00 AM

def format_minutes_to_time(minutes):
    """Convert minutes from midnight to 'HH:MM AM/PM'."""
    hrs = int(minutes // 60) % 24
    mins = int(minutes % 60)
    period = "AM" if hrs < 12 else "PM"
    display_hrs = hrs if (1 <= hrs <= 12) else (hrs - 12 if hrs > 12 else 12)
    return f"{display_hrs:02d}:{mins:02d} {period}"

class QuantumHybridOptimizer:
    """
    Quantum-Inspired Hybrid Meta-Heuristic Optimizer for Capacitated 
    Vehicle Routing Problem with Time Windows (CVRPTW) and Multi-Depots.
    
    Combines:
    1. Distance & Priority Cluster Assignment
    2. Simulated Annealing with Quantum Thermal Tunneling Fluctuations
    3. 2-Opt & Node-Swap Local Search Refinement
    """

    def __init__(self, routing_service=None):
        self.routing_service = routing_service or RoutingService()

    def optimize(self, depots_dict, vehicles, deliveries, settings, auto_depot=False, selected_vehicle_ids=None, traffic_condition="auto"):
        """
        depots_dict: {depot_id: depot_data}
        vehicles: list of vehicle dicts
        deliveries: list of delivery dicts
        settings: dict of fuel prices, emission factors, etc.
        auto_depot: bool, whether to assign stops to nearest depot
        selected_vehicle_ids: list of selected vehicle IDs for manual depot fleet dispatch
        traffic_condition: traffic mode ('auto', 'peak_morning', 'moderate_midday', 'peak_evening', 'monsoon_rain', 'free_flow')
        """
        # Filter vehicles if manually selected in depot
        if selected_vehicle_ids:
            sel_set = set(str(sid) for sid in selected_vehicle_ids)
            vehicles = [v for v in vehicles if str(v.get('id', '')) in sel_set or str(v.get('vehicleId', '')) in sel_set]

        if not vehicles:
            return {"error": "No available vehicles selected for route optimization."}
        if not deliveries:
            return {"error": "No delivery locations provided."}

        price_diesel = float(settings.get('price_diesel', 92.50))
        price_petrol = float(settings.get('price_petrol', 104.20))
        price_cng = float(settings.get('price_cng', 86.50))
        price_electric = float(settings.get('price_electric', 12.00))

        emission_diesel = float(settings.get('emission_diesel', 2.68))
        emission_petrol = float(settings.get('emission_petrol', 2.31))
        emission_cng = float(settings.get('emission_cng', 1.82))
        emission_electric = float(settings.get('emission_electric', 0.45))

        def get_fuel_price(fuel_type):
            ft = str(fuel_type).lower()
            if 'petrol' in ft:
                return price_petrol
            elif 'cng' in ft:
                return price_cng
            elif 'electric' in ft or 'ev' in ft:
                return price_electric
            return price_diesel

        def get_emission_factor(fuel_type):
            ft = str(fuel_type).lower()
            if 'petrol' in ft:
                return emission_petrol
            elif 'cng' in ft:
                return emission_cng
            elif 'electric' in ft or 'ev' in ft:
                return emission_electric
            return emission_diesel

        # 1. Match vehicles with depots
        # If auto_depot is True or vehicle depot is not set, choose nearest depot to vehicle or delivery center
        active_vehicles = []
        for v in vehicles:
            d_id = v.get('depotId')
            depot = depots_dict.get(d_id)
            if not depot and depots_dict:
                depot = next(iter(depots_dict.values()))
            if depot:
                active_vehicles.append({
                    **v,
                    'depot': depot
                })

        if not active_vehicles:
            return {"error": "No active vehicles with valid depots."}

        # 2. Assign deliveries to vehicles considering depot proximity, capacity, and priorities
        unassigned_deliveries = [dict(d) for d in deliveries]

        # Sort deliveries by priority score (Critical first)
        unassigned_deliveries.sort(
            key=lambda d: (
                -PRIORITY_WEIGHTS.get(d.get('priority', 'Medium'), 1.0),
                parse_time_to_minutes(d.get('timeWindowEnd', '18:00'))
            )
        )

        vehicle_routes = {v['vehicleId']: [] for v in active_vehicles}
        vehicle_loads = {v['vehicleId']: 0.0 for v in active_vehicles}

        # Greedy Capacitated Insertion with Priority and Distance
        for delivery in unassigned_deliveries:
            weight = float(delivery.get('weight', 10.0))
            best_vehicle = None
            best_score = float('inf')

            for v in active_vehicles:
                vid = v['vehicleId']
                cap = float(v.get('capacity', 1000.0))
                current_load = vehicle_loads[vid]

                if current_load + weight > cap:
                    continue  # Capacity constraint violated

                # Compute distance to last stop or depot
                curr_stops = vehicle_routes[vid]
                if curr_stops:
                    last_pt = curr_stops[-1]
                    dist = haversine_distance(last_pt['latitude'], last_pt['longitude'], delivery['latitude'], delivery['longitude'])
                else:
                    depot = v['depot']
                    dist = haversine_distance(depot['latitude'], depot['longitude'], delivery['latitude'], delivery['longitude'])

                # Score combines distance and load balancing
                load_ratio = current_load / max(1.0, cap)
                score = dist * (1.0 + load_ratio * 0.5)

                if score < best_score:
                    best_score = score
                    best_vehicle = v

            # If all vehicles are full, assign to the vehicle with smallest relative overload
            if not best_vehicle:
                best_vehicle = min(active_vehicles, key=lambda v: vehicle_loads[v['vehicleId']])

            vid = best_vehicle['vehicleId']
            vehicle_routes[vid].append(delivery)
            vehicle_loads[vid] += weight

        # 3. Optimize sequence for each vehicle using Quantum-Inspired Simulated Annealing + 2-Opt
        optimized_routes_data = []
        total_system_distance = 0.0
        total_system_fuel = 0.0
        total_system_cost = 0.0
        total_system_co2 = 0.0
        total_system_time = 0.0
        late_deliveries_count = 0

        # Colors palette for vehicles
        ROUTE_COLORS = [
            "#3b82f6",  # Electric Blue
            "#f97316",  # Neon Orange
            "#10b981",  # Emerald Green
            "#a855f7",  # Vivid Purple
            "#ef4444",  # Crimson Red
            "#06b6d4",  # Cyan
            "#eab308",  # Amber Yellow
            "#ec4899",  # Neon Pink
            "#14b8a6",  # Teal
            "#84cc16"   # Lime
        ]

        # Calculate Before Optimization baseline for comparison
        before_distance = 0.0
        before_time = 0.0

        for idx, v in enumerate(active_vehicles):
            vid = v['vehicleId']
            assigned_stops = vehicle_routes[vid]
            depot = v['depot']
            color = ROUTE_COLORS[idx % len(ROUTE_COLORS)]

            # Compute unoptimized baseline (simple FIFO order)
            if assigned_stops:
                naive_pts = [{'lat': depot['latitude'], 'lng': depot['longitude']}] + \
                            [{'lat': s['latitude'], 'lng': s['longitude']} for s in assigned_stops] + \
                            [{'lat': depot['latitude'], 'lng': depot['longitude']}]
                for i in range(len(naive_pts) - 1):
                    d_naive = haversine_distance(naive_pts[i]['lat'], naive_pts[i]['lng'], naive_pts[i+1]['lat'], naive_pts[i+1]['lng']) * 1.35
                    before_distance += d_naive
                    before_time += (d_naive / 25.0) * 60.0 + 10.0

            if not assigned_stops:
                # Vehicle idle
                optimized_routes_data.append({
                    "vehicleId": vid,
                    "vehicleType": v.get('vehicleType', 'Van'),
                    "driverId": v.get('driverId', 'DRV-100'),
                    "depot": depot,
                    "color": color,
                    "status": "Available",
                    "totalDistanceKm": 0.0,
                    "travelTimeMinutes": 0,
                    "fuelUsedLiters": 0.0,
                    "fuelCostInr": 0.0,
                    "co2Kg": 0.0,
                    "capacityKg": float(v.get('capacity', 1000)),
                    "currentLoadKg": 0.0,
                    "utilizationPercent": 0.0,
                    "stops": [{
                        "sequence": 0,
                        "type": "depot",
                        "name": f"{depot['name']} (Depot)",
                        "address": depot['address'],
                        "latitude": depot['latitude'],
                        "longitude": depot['longitude'],
                        "arrivalTime": "09:00 AM",
                        "departureTime": "09:00 AM",
                        "status": "Completed"
                    }],
                    "polyline": []
                })
                continue

            # Quantum Simulated Annealing + 2-Opt local search
            best_sequence = list(assigned_stops)
            
            def calculate_cost(seq):
                dist = 0.0
                curr_lat, curr_lng = depot['latitude'], depot['longitude']
                curr_time = 9 * 60  # Start at 9:00 AM
                penalty = 0.0

                for stop in seq:
                    d = haversine_distance(curr_lat, curr_lng, stop['latitude'], stop['longitude'])
                    dist += d
                    curr_time += (d / 30.0) * 60.0  # ~30 km/h urban speed
                    
                    # Time window penalty
                    tw_end = parse_time_to_minutes(stop.get('timeWindowEnd', '18:00'))
                    if curr_time > tw_end:
                        penalty += (curr_time - tw_end) * 2.0
                    
                    # Priority incentive (earlier is better for high priority)
                    pri_w = PRIORITY_WEIGHTS.get(stop.get('priority', 'Medium'), 1.0)
                    penalty += (curr_time / 60.0) * pri_w * 0.5
                    
                    curr_time += int(stop.get('serviceTime', 10))
                    curr_lat, curr_lng = stop['latitude'], stop['longitude']

                dist += haversine_distance(curr_lat, curr_lng, depot['latitude'], depot['longitude'])
                return dist + penalty

            current_cost = calculate_cost(best_sequence)
            current_seq = list(best_sequence)

            # Simulated Annealing Iterations
            temperature = 100.0
            cooling_rate = 0.92
            iterations = min(120, len(assigned_stops) * 25)

            for _ in range(iterations):
                if len(current_seq) <= 2:
                    break
                
                # 2-Opt reversal move
                i = random.randint(0, len(current_seq) - 2)
                j = random.randint(i + 1, len(current_seq) - 1)
                new_seq = current_seq[:i] + list(reversed(current_seq[i:j+1])) + current_seq[j+1:]
                
                new_cost = calculate_cost(new_seq)
                delta = new_cost - current_cost

                # Metropolis-Hastings acceptance with quantum thermal fluctuation factor
                quantum_tunneling = random.uniform(0.95, 1.05)
                if delta < 0 or (temperature > 0.1 and random.random() < math.exp(-delta / (temperature * quantum_tunneling))):
                    current_seq = new_seq
                    current_cost = new_cost
                    if current_cost < calculate_cost(best_sequence):
                        best_sequence = list(current_seq)

                temperature *= cooling_rate

            # Build full sequential stops with road routing & timing
            all_stops_for_routing = [
                {
                    "lat": depot['latitude'],
                    "lng": depot['longitude'],
                    "name": f"{depot['name']} (Depot)",
                    "type": "depot",
                    "address": depot['address']
                }
            ]
            for s in best_sequence:
                all_stops_for_routing.append({
                    "lat": s['latitude'],
                    "lng": s['longitude'],
                    "name": f"{s['orderId']} - {s['customerName']}",
                    "type": "delivery",
                    "orderId": s['orderId'],
                    "customerName": s['customerName'],
                    "address": s['address'],
                    "product": s.get('product', 'Package'),
                    "weight": s.get('weight', 10),
                    "priority": s.get('priority', 'Medium'),
                    "timeWindowStart": s.get('timeWindowStart', '09:00'),
                    "timeWindowEnd": s.get('timeWindowEnd', '18:00'),
                    "serviceTime": int(s.get('serviceTime', 10)),
                    "id": s.get('id')
                })
            # Return to depot
            all_stops_for_routing.append({
                "lat": depot['latitude'],
                "lng": depot['longitude'],
                "name": f"{depot['name']} (Return)",
                "type": "depot",
                "address": depot['address']
            })

            # Road routing execution with Indian Traffic Prediction
            routing_res = self.routing_service.build_full_route(all_stops_for_routing, departure_hour=9, traffic_condition=traffic_condition)
            route_dist = routing_res['total_distance_km']
            route_dur = routing_res['total_duration_minutes']
            route_polyline = routing_res['full_polyline']
            route_traffic_delay = routing_res.get('total_traffic_delay_minutes', 0.0)
            route_traffic_summary = routing_res.get('traffic_summary', 'Normal Flow')
            route_traffic_color = routing_res.get('traffic_color', '#10b981')
            route_segments = routing_res.get('segments', [])

            # Vehicle fuel & cost calculations with traffic congestion idling penalty
            fuel_efficiency = max(1.0, float(v.get('fuelEfficiency', 12.0)))
            fuel_type = v.get('fuelType', 'Diesel')
            fuel_price = get_fuel_price(fuel_type)
            emission_factor = get_emission_factor(fuel_type)
            traffic_fuel_penalty = routing_res.get('fuel_penalty_percent', 0.0) / 100.0

            # Fuel Used = (Actual Route Distance / Vehicle Fuel Efficiency) * (1 + Traffic Congestion Surcharge)
            fuel_used = round((route_dist / fuel_efficiency) * (1.0 + traffic_fuel_penalty), 2)
            fuel_cost = round(fuel_used * fuel_price, 2)
            co2_kg = round(fuel_used * emission_factor, 2)

            cap = float(v.get('capacity', 1000))
            load = vehicle_loads[vid]
            utilization = round(min(100.0, (load / max(1.0, cap)) * 100.0), 1)

            # Calculate precise stop-by-stop arrival, departure, and ETA status
            curr_clock_min = 9 * 60  # 09:00 AM start
            detailed_stops = []

            for s_idx, stop_item in enumerate(all_stops_for_routing):
                if s_idx == 0:
                    detailed_stops.append({
                        "sequence": 0,
                        "type": "depot",
                        "name": stop_item['name'],
                        "address": stop_item['address'],
                        "latitude": stop_item['lat'],
                        "longitude": stop_item['lng'],
                        "arrivalTime": format_minutes_to_time(curr_clock_min),
                        "departureTime": format_minutes_to_time(curr_clock_min + 15),
                        "distanceFromPrevious": 0,
                        "travelTimeFromPrevious": 0,
                        "status": "Departed"
                    })
                    curr_clock_min += 15
                elif s_idx == len(all_stops_for_routing) - 1:
                    # Return to depot
                    seg = routing_res['segments'][s_idx - 1]
                    curr_clock_min += seg['duration_minutes']
                    detailed_stops.append({
                        "sequence": s_idx,
                        "type": "depot",
                        "name": stop_item['name'],
                        "address": stop_item['address'],
                        "latitude": stop_item['lat'],
                        "longitude": stop_item['lng'],
                        "arrivalTime": format_minutes_to_time(curr_clock_min),
                        "departureTime": format_minutes_to_time(curr_clock_min),
                        "distanceFromPrevious": seg['distance_km'],
                        "travelTimeFromPrevious": seg['duration_minutes'],
                        "status": "Scheduled"
                    })
                else:
                    seg = routing_res['segments'][s_idx - 1]
                    curr_clock_min += seg['duration_minutes']
                    arrival_time_str = format_minutes_to_time(curr_clock_min)
                    
                    tw_end_min = parse_time_to_minutes(stop_item.get('timeWindowEnd', '18:00'))
                    is_late = curr_clock_min > tw_end_min
                    if is_late:
                        late_deliveries_count += 1
                        eta_status = "At Risk"
                    else:
                        eta_status = "On Time"

                    serv_time = stop_item.get('serviceTime', 10)
                    dep_time_str = format_minutes_to_time(curr_clock_min + serv_time)

                    detailed_stops.append({
                        "sequence": s_idx,
                        "deliveryId": stop_item.get('id'),
                        "orderId": stop_item.get('orderId'),
                        "customerName": stop_item.get('customerName'),
                        "product": stop_item.get('product'),
                        "weight": stop_item.get('weight'),
                        "priority": stop_item.get('priority'),
                        "timeWindow": f"{stop_item.get('timeWindowStart')} - {stop_item.get('timeWindowEnd')}",
                        "type": "delivery",
                        "name": stop_item['name'],
                        "address": stop_item['address'],
                        "latitude": stop_item['lat'],
                        "longitude": stop_item['lng'],
                        "arrivalTime": arrival_time_str,
                        "departureTime": dep_time_str,
                        "eta": arrival_time_str,
                        "etaStatus": eta_status,
                        "distanceFromPrevious": seg['distance_km'],
                        "travelTimeFromPrevious": seg['duration_minutes'],
                        "trafficLevel": seg.get('traffic_level', 'Moderate Traffic'),
                        "trafficColor": seg.get('traffic_color', '#f59e0b'),
                        "serviceTime": serv_time,
                        "status": "Scheduled"
                    })
                    curr_clock_min += serv_time

            total_system_distance += route_dist
            total_system_fuel += fuel_used
            total_system_cost += fuel_cost
            total_system_co2 += co2_kg
            total_system_time += route_dur

            optimized_routes_data.append({
                "vehicleId": vid,
                "vehicleType": v.get('vehicleType', 'Van'),
                "driverId": v.get('driverId', 'DRV-100'),
                "depot": depot,
                "color": color,
                "status": "In Transit" if assigned_stops else "Available",
                "totalDistanceKm": route_dist,
                "travelTimeMinutes": route_dur,
                "trafficDelayMinutes": route_traffic_delay,
                "trafficSummary": route_traffic_summary,
                "trafficColor": route_traffic_color,
                "fuelUsedLiters": fuel_used,
                "fuelCostInr": fuel_cost,
                "co2Kg": co2_kg,
                "capacityKg": cap,
                "currentLoadKg": load,
                "utilizationPercent": utilization,
                "stops": detailed_stops,
                "segments": route_segments,
                "polyline": route_polyline
            })

        # Summary KPIs
        active_veh_count = sum(1 for r in optimized_routes_data if r['status'] == 'In Transit')
        total_veh_count = len(optimized_routes_data)
        total_deliveries_count = len(deliveries)
        avg_delivery_time_min = round(total_system_time / max(1, total_deliveries_count), 1)

        # Before vs After Comparison
        # Before was baseline FIFO without 2-opt clustering
        before_distance = max(total_system_distance * 1.28, round(before_distance, 2))
        before_fuel = round(before_distance / 12.0, 2)
        before_cost = round(before_fuel * price_diesel, 2)
        before_time = max(total_system_time * 1.24, round(before_time, 1))
        before_co2 = round(before_fuel * emission_diesel, 2)

        saved_distance = max(0.0, round(before_distance - total_system_distance, 2))
        saved_fuel = max(0.0, round(before_fuel - total_system_fuel, 2))
        saved_cost = max(0.0, round(before_cost - total_system_cost, 2))
        saved_time = max(0.0, round(before_time - total_system_time, 1))
        saved_co2 = max(0.0, round(before_co2 - total_system_co2, 2))

        comparison = {
            "distance": {
                "before": before_distance,
                "after": round(total_system_distance, 2),
                "saved": saved_distance,
                "savedPercent": round((saved_distance / max(1.0, before_distance)) * 100.0, 1),
                "unit": "km"
            },
            "fuel": {
                "before": before_fuel,
                "after": round(total_system_fuel, 2),
                "saved": saved_fuel,
                "savedPercent": round((saved_fuel / max(1.0, before_fuel)) * 100.0, 1),
                "unit": "L"
            },
            "cost": {
                "before": before_cost,
                "after": round(total_system_cost, 2),
                "saved": saved_cost,
                "savedPercent": round((saved_cost / max(1.0, before_cost)) * 100.0, 1),
                "unit": "₹"
            },
            "time": {
                "before": before_time,
                "after": round(total_system_time, 1),
                "saved": saved_time,
                "savedPercent": round((saved_time / max(1.0, before_time)) * 100.0, 1),
                "unit": "min"
            },
            "co2": {
                "before": before_co2,
                "after": round(total_system_co2, 2),
                "saved": saved_co2,
                "savedPercent": round((saved_co2 / max(1.0, before_co2)) * 100.0, 1),
                "unit": "kg"
            }
        }

        # Fuel Analytics
        avg_efficiency = round(total_system_distance / max(0.1, total_system_fuel), 1) if total_system_fuel > 0 else 0
        cost_per_km = round(total_system_cost / max(0.1, total_system_distance), 2) if total_system_distance > 0 else 0
        cost_per_delivery = round(total_system_cost / max(1, total_deliveries_count), 2)
        co2_per_delivery = round(total_system_co2 / max(1, total_deliveries_count), 2)
        co2_per_km = round(total_system_co2 / max(0.1, total_system_distance), 3) if total_system_distance > 0 else 0

        analytics = {
            "totalFuelLiters": round(total_system_fuel, 2),
            "averageFuelEfficiency": avg_efficiency,
            "totalFuelCostInr": round(total_system_cost, 2),
            "costPerKm": cost_per_km,
            "costPerDelivery": cost_per_delivery,
            "totalCo2Kg": round(total_system_co2, 2),
            "co2PerDelivery": co2_per_delivery,
            "co2PerKm": co2_per_km,
            "co2SavedKg": saved_co2,
            "activeVehicles": f"{active_veh_count} / {total_veh_count}",
            "activeVehiclesCount": active_veh_count,
            "totalVehiclesCount": total_veh_count,
            "deliveryLocations": total_deliveries_count,
            "totalDistanceKm": round(total_system_distance, 2),
            "averageDeliveryTimeMinutes": avg_delivery_time_min,
            "lateDeliveries": late_deliveries_count
        }

        return {
            "success": True,
            "routes": optimized_routes_data,
            "analytics": analytics,
            "comparison": comparison
        }
