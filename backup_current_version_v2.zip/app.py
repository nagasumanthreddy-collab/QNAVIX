import os
import json
import csv
import io
from flask import Flask, request, jsonify, send_from_directory, Response
from flask_cors import CORS
from database import get_db, init_db
from drivers import generate_driver
from geocoding import geocode_address, search_places_suggestions, reverse_geocode
from routing import RoutingService
from optimizer import QuantumHybridOptimizer

app = Flask(__name__, static_folder='static', static_url_path='')
CORS(app)

# Initialize database on startup
init_db()

def get_app_settings():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT key, value FROM settings')
    settings = {row['key']: row['value'] for row in cursor.fetchall()}
    conn.close()
    return settings

# ==================== STATIC ROUTES ====================
@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

# ==================== DEPOTS APIS ====================
@app.route('/api/depots', methods=['GET'])
def list_depots():
    conn = get_db()
    cursor = conn.cursor()
    
    state_filter = request.args.get('state')
    city_filter = request.args.get('city')
    type_filter = request.args.get('type')
    search = request.args.get('search')
    
    query = 'SELECT * FROM depots WHERE active = 1'
    params = []
    
    if state_filter:
        query += ' AND state = ?'
        params.append(state_filter)
    if city_filter:
        query += ' AND city = ?'
        params.append(city_filter)
    if type_filter:
        query += ' AND depotType = ?'
        params.append(type_filter)
    if search:
        query += ' AND (name LIKE ? OR city LIKE ? OR address LIKE ?)'
        params.extend([f'%{search}%', f'%{search}%', f'%{search}%'])
        
    query += ' ORDER BY city ASC, name ASC'
    cursor.execute(query, params)
    depots = [dict(row) for row in cursor.fetchall()]
    
    # Also fetch distinct states and cities for UI filters
    cursor.execute('SELECT DISTINCT state FROM depots WHERE active = 1 ORDER BY state ASC')
    states = [r['state'] for r in cursor.fetchall()]
    cursor.execute('SELECT DISTINCT city FROM depots WHERE active = 1 ORDER BY city ASC')
    cities = [r['city'] for r in cursor.fetchall()]
    
    conn.close()
    return jsonify({"depots": depots, "states": states, "cities": cities})

@app.route('/api/depots', methods=['POST'])
def add_depot():
    data = request.json or {}
    name = data.get('name')
    city = data.get('city')
    state = data.get('state', 'India')
    address = data.get('address')
    depot_type = data.get('depotType', 'City Warehouse')
    capacity = int(data.get('capacity', 75000))
    lat = data.get('latitude')
    lng = data.get('longitude')

    if not name or not address:
        return jsonify({"error": "Depot name and address are required"}), 400

    # Auto geocode if coordinates not supplied
    if lat is None or lng is None:
        settings = get_app_settings()
        geo = geocode_address(f"{address}, {city or ''}, {state or ''}", settings.get('google_maps_api_key'))
        if geo:
            lat = geo['latitude']
            lng = geo['longitude']
        else:
            lat, lng = 17.3850, 78.4867

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
    INSERT INTO depots (name, city, state, country, address, latitude, longitude, depotType, capacity, active)
    VALUES (?, ?, ?, 'India', ?, ?, ?, ?, ?, 1)
    ''', (name, city or 'Metropolis', state, address, lat, lng, depot_type, capacity))
    depot_id = cursor.lastrowid
    conn.commit()
    conn.close()

    return jsonify({"success": True, "id": depot_id, "name": name, "latitude": lat, "longitude": lng})

@app.route('/api/depots/<int:depot_id>', methods=['DELETE'])
def delete_depot(depot_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM depots WHERE id = ?', (depot_id,))
    conn.commit()
    conn.close()
    return jsonify({"success": True})

# ==================== VEHICLES & DRIVERS APIS ====================
@app.route('/api/vehicles', methods=['GET'])
def list_vehicles():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
    SELECT v.*, d.name as depotName, d.city as depotCity, d.latitude as depotLat, d.longitude as depotLng,
           dr.name as driverName, dr.phone as driverPhone, dr.rating as driverRating, dr.licenseType as driverLicense
    FROM vehicles v
    LEFT JOIN depots d ON v.depotId = d.id
    LEFT JOIN drivers dr ON v.driverId = dr.driverId
    ORDER BY v.vehicleId ASC
    ''')
    vehicles = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return jsonify({"vehicles": vehicles})

@app.route('/api/vehicles/generate', methods=['POST'])
def generate_fleet():
    """Dynamically generate fleet of N vehicles with realistic fictional Indian drivers."""
    data = request.json or {}
    count = int(data.get('count', 3))
    default_depot_id = data.get('depotId')
    vehicle_type = data.get('vehicleType', 'Van')
    capacity = float(data.get('capacity', 1000))
    fuel_type = data.get('fuelType', 'Diesel')
    fuel_efficiency = float(data.get('fuelEfficiency', 14.0))
    fuel_tank = float(data.get('fuelTankCapacity', 50.0))
    max_range = float(data.get('maximumRange', 600.0))

    conn = get_db()
    cursor = conn.cursor()

    # Get default depot if not selected
    if not default_depot_id:
        cursor.execute('SELECT id FROM depots WHERE active = 1 LIMIT 1')
        row = cursor.fetchone()
        if row:
            default_depot_id = row['id']

    # Get max current vehicle index
    cursor.execute('SELECT vehicleId FROM vehicles ORDER BY id DESC')
    existing = cursor.fetchall()
    start_num = 1
    if existing:
        for r in existing:
            v_str = r['vehicleId'].replace('V', '')
            if v_str.isdigit():
                start_num = max(start_num, int(v_str) + 1)

    created_vehicles = []
    for i in range(count):
        idx = start_num + i
        v_id = f"V{idx:03d}"
        
        # Automatically generate realistic fictional driver
        driver = generate_driver(v_id, idx)
        cursor.execute('''
        INSERT OR REPLACE INTO drivers (driverId, name, age, experience, phone, licenseType, rating, vehicleId, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (driver['driverId'], driver['name'], driver['age'], driver['experience'], driver['phone'], 
              driver['licenseType'], driver['rating'], driver['vehicleId'], driver['status']))

        cursor.execute('''
        INSERT INTO vehicles (vehicleId, vehicleType, capacity, currentLoad, fuelType, fuelEfficiency, 
                             fuelTankCapacity, maximumRange, depotId, driverId, status)
        VALUES (?, ?, ?, 0, ?, ?, ?, ?, ?, ?, 'Available')
        ''', (v_id, vehicle_type, capacity, fuel_type, fuel_efficiency, fuel_tank, max_range, default_depot_id, driver['driverId']))

        created_vehicles.append({
            "vehicleId": v_id,
            "vehicleType": vehicle_type,
            "capacity": capacity,
            "fuelType": fuel_type,
            "fuelEfficiency": fuel_efficiency,
            "depotId": default_depot_id,
            "driver": driver
        })

    conn.commit()
    conn.close()
    return jsonify({"success": True, "created": created_vehicles})

@app.route('/api/vehicles/<int:id>', methods=['PUT'])
def update_vehicle(id):
    data = request.json or {}
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
    UPDATE vehicles SET 
        vehicleType = coalesce(?, vehicleType),
        capacity = coalesce(?, capacity),
        fuelType = coalesce(?, fuelType),
        fuelEfficiency = coalesce(?, fuelEfficiency),
        fuelTankCapacity = coalesce(?, fuelTankCapacity),
        maximumRange = coalesce(?, maximumRange),
        depotId = coalesce(?, depotId)
    WHERE id = ?
    ''', (data.get('vehicleType'), data.get('capacity'), data.get('fuelType'), 
          data.get('fuelEfficiency'), data.get('fuelTankCapacity'), data.get('maximumRange'),
          data.get('depotId'), id))
    conn.commit()
    conn.close()
    return jsonify({"success": True})

@app.route('/api/vehicles/<int:id>', methods=['DELETE'])
def delete_vehicle(id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT vehicleId, driverId FROM vehicles WHERE id = ?', (id,))
    v = cursor.fetchone()
    if v:
        cursor.execute('DELETE FROM drivers WHERE driverId = ?', (v['driverId'],))
        cursor.execute('DELETE FROM vehicles WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    return jsonify({"success": True})

@app.route('/api/vehicles/clear', methods=['POST'])
def clear_vehicles():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM vehicles')
    cursor.execute('DELETE FROM drivers')
    cursor.execute('DELETE FROM routes')
    cursor.execute('DELETE FROM route_stops')
    conn.commit()
    conn.close()
    return jsonify({"success": True})

@app.route('/api/drivers/<driver_id>', methods=['PUT'])
def update_driver(driver_id):
    data = request.json or {}
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
    UPDATE drivers SET
        name = coalesce(?, name),
        age = coalesce(?, age),
        experience = coalesce(?, experience),
        phone = coalesce(?, phone),
        licenseType = coalesce(?, licenseType),
        rating = coalesce(?, rating)
    WHERE driverId = ?
    ''', (data.get('name'), data.get('age'), data.get('experience'), data.get('phone'),
          data.get('licenseType'), data.get('rating'), driver_id))
    conn.commit()
    conn.close()
    return jsonify({"success": True})

# ==================== DELIVERIES APIS ====================
@app.route('/api/deliveries', methods=['GET'])
def list_deliveries():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM deliveries ORDER BY id ASC')
    deliveries = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return jsonify({"deliveries": deliveries})

@app.route('/api/deliveries', methods=['POST'])
def add_delivery():
    data = request.json or {}
    order_id = data.get('orderId')
    customer_name = data.get('customerName', 'Customer')
    address = data.get('address')
    product = data.get('product', 'Merchandise')
    quantity = int(data.get('quantity', 1))
    weight = float(data.get('weight', 10.0))
    priority = data.get('priority', 'Medium')
    tw_start = data.get('timeWindowStart', '09:00')
    tw_end = data.get('timeWindowEnd', '18:00')
    service_time = int(data.get('serviceTime', 10))
    lat = data.get('latitude')
    lng = data.get('longitude')

    if not address:
        return jsonify({"error": "Delivery address is required"}), 400

    conn = get_db()
    cursor = conn.cursor()

    if not order_id:
        cursor.execute('SELECT COUNT(*) FROM deliveries')
        cnt = cursor.fetchone()[0] + 1
        order_id = f"ORD-{cnt:03d}"

    # Geocode if missing
    if lat is None or lng is None:
        settings = get_app_settings()
        geo = geocode_address(address, settings.get('google_maps_api_key'))
        if geo:
            lat = geo['latitude']
            lng = geo['longitude']
            address = geo['address']
        else:
            lat, lng = 17.3850, 78.4867

    cursor.execute('''
    INSERT OR REPLACE INTO deliveries (orderId, customerName, address, latitude, longitude, product,
                            quantity, weight, priority, timeWindowStart, timeWindowEnd, serviceTime, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending')
    ''', (order_id, customer_name, address, lat, lng, product, quantity, weight, priority, tw_start, tw_end, service_time))
    
    delivery_id = cursor.lastrowid
    conn.commit()
    conn.close()

    return jsonify({
        "success": True,
        "delivery": {
            "id": delivery_id,
            "orderId": order_id,
            "customerName": customer_name,
            "address": address,
            "latitude": lat,
            "longitude": lng,
            "product": product,
            "quantity": quantity,
            "weight": weight,
            "priority": priority,
            "timeWindowStart": tw_start,
            "timeWindowEnd": tw_end,
            "serviceTime": service_time,
            "status": "Pending"
        }
    })

@app.route('/api/deliveries/<int:id>', methods=['DELETE'])
def delete_delivery(id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM deliveries WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    return jsonify({"success": True})

@app.route('/api/deliveries/clear', methods=['POST'])
def clear_deliveries():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM deliveries')
    cursor.execute('DELETE FROM routes')
    cursor.execute('DELETE FROM route_stops')
    conn.commit()
    conn.close()
    return jsonify({"success": True})

# ==================== GEOCODING & SEARCH ====================
@app.route('/api/geocode', methods=['GET'])
def geocode_api():
    query = request.args.get('q', '')
    settings = get_app_settings()
    res = geocode_address(query, settings.get('google_maps_api_key'))
    if res:
        return jsonify(res)
    return jsonify({"error": "Location not found"}), 404

@app.route('/api/places/search', methods=['GET'])
def places_search():
    query = request.args.get('q', '')
    settings = get_app_settings()
    suggestions = search_places_suggestions(query, settings.get('google_maps_api_key'))
    return jsonify({"suggestions": suggestions})

@app.route('/api/reverse-geocode', methods=['GET'])
def reverse_geocode_api():
    lat = request.args.get('lat')
    lng = request.args.get('lng')
    if lat is None or lng is None:
        return jsonify({"error": "Latitude and Longitude parameters required"}), 400
    settings = get_app_settings()
    result = reverse_geocode(lat, lng, settings.get('google_maps_api_key'))
    return jsonify(result)

@app.route('/api/search', methods=['GET'])
def global_search_api():
    query = request.args.get('q', '').strip()
    if not query:
        return jsonify({"depots": [], "vehicles": [], "deliveries": [], "routes": []})

    q_like = f"%{query}%"
    conn = get_db()
    cursor = conn.cursor()

    # Search depots
    cursor.execute('''
        SELECT * FROM depots 
        WHERE active = 1 AND (name LIKE ? OR city LIKE ? OR state LIKE ? OR address LIKE ? OR depotType LIKE ?)
        LIMIT 6
    ''', (q_like, q_like, q_like, q_like, q_like))
    depots = [dict(r) for r in cursor.fetchall()]

    # Search vehicles & drivers
    cursor.execute('''
        SELECT v.*, dr.name as driverName, dr.phone as driverPhone, dr.rating as driverRating,
               d.name as depotName, d.city as depotCity
        FROM vehicles v
        LEFT JOIN drivers dr ON v.driverId = dr.driverId
        LEFT JOIN depots d ON v.depotId = d.id
        WHERE v.vehicleId LIKE ? OR v.vehicleType LIKE ? OR v.fuelType LIKE ? 
           OR dr.name LIKE ? OR dr.driverId LIKE ? OR dr.phone LIKE ?
        LIMIT 6
    ''', (q_like, q_like, q_like, q_like, q_like, q_like))
    vehicles = [dict(r) for r in cursor.fetchall()]

    # Search deliveries
    cursor.execute('''
        SELECT * FROM deliveries
        WHERE orderId LIKE ? OR customerName LIKE ? OR address LIKE ? OR product LIKE ? OR priority LIKE ? OR assignedVehicle LIKE ?
        LIMIT 8
    ''', (q_like, q_like, q_like, q_like, q_like, q_like))
    deliveries = [dict(r) for r in cursor.fetchall()]

    # Search routes
    cursor.execute('''
        SELECT r.*, d.name as depotName, d.city as depotCity
        FROM routes r
        JOIN depots d ON r.depotId = d.id
        WHERE r.vehicleId LIKE ? OR d.name LIKE ? OR d.city LIKE ?
        LIMIT 4
    ''', (q_like, q_like, q_like))
    routes = [dict(r) for r in cursor.fetchall()]

    conn.close()
    return jsonify({
        "query": query,
        "depots": depots,
        "vehicles": vehicles,
        "deliveries": deliveries,
        "routes": routes
    })


# ==================== OPTIMIZATION ENGINE ====================
@app.route('/api/optimize', methods=['POST'])
def run_optimization():
    conn = get_db()
    cursor = conn.cursor()

    # Load depots
    cursor.execute('SELECT * FROM depots WHERE active = 1')
    depots = [dict(r) for r in cursor.fetchall()]
    depots_dict = {d['id']: d for d in depots}

    # Load vehicles
    cursor.execute('SELECT * FROM vehicles')
    vehicles = [dict(r) for r in cursor.fetchall()]

    # Load deliveries
    cursor.execute('SELECT * FROM deliveries')
    deliveries = [dict(r) for r in cursor.fetchall()]

    # Load settings
    cursor.execute('SELECT key, value FROM settings')
    settings = {r['key']: r['value'] for r in cursor.fetchall()}

    req_json = request.json or {}
    auto_depot = req_json.get('autoDepot', False)
    selected_vehicle_ids = req_json.get('selectedVehicleIds', None)
    traffic_condition = req_json.get('trafficCondition', 'auto')

    if not vehicles:
        conn.close()
        return jsonify({"error": "No vehicles found. Please add vehicles first."}), 400

    if not deliveries:
        conn.close()
        return jsonify({"error": "No delivery locations found. Please add delivery orders first."}), 400

    routing_svc = RoutingService(settings.get('google_maps_api_key'))
    optimizer = QuantumHybridOptimizer(routing_svc)

    result = optimizer.optimize(depots_dict, vehicles, deliveries, settings, auto_depot, selected_vehicle_ids, traffic_condition)

    if "error" in result:
        conn.close()
        return jsonify({"error": result["error"]}), 400

    # Save routes and stops to database
    cursor.execute('DELETE FROM routes')
    cursor.execute('DELETE FROM route_stops')

    for r_data in result['routes']:
        cursor.execute('''
        INSERT INTO routes (vehicleId, depotId, totalDistance, travelTime, fuelUsed, fuelCost, co2, routeStatus, polyline)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (r_data['vehicleId'], r_data['depot']['id'], r_data['totalDistanceKm'], r_data['travelTimeMinutes'],
              r_data['fuelUsedLiters'], r_data['fuelCostInr'], r_data['co2Kg'], r_data['status'],
              json.dumps(r_data['polyline'])))
        route_id = cursor.lastrowid

        for stop in r_data['stops']:
            cursor.execute('''
            INSERT INTO route_stops (routeId, sequence, deliveryId, stopType, latitude, longitude, name, address,
                                   arrivalTime, departureTime, distanceFromPrevious, travelTimeFromPrevious, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (route_id, stop['sequence'], stop.get('deliveryId'), stop['type'], stop['latitude'], stop['longitude'],
                  stop['name'], stop.get('address'), stop['arrivalTime'], stop['departureTime'],
                  stop.get('distanceFromPrevious', 0), stop.get('travelTimeFromPrevious', 0), stop.get('etaStatus', 'Scheduled')))
            
            # Update delivery status & ETA in deliveries table
            if stop.get('deliveryId'):
                cursor.execute('''
                UPDATE deliveries SET assignedVehicle = ?, status = 'In Transit', eta = ?
                WHERE id = ?
                ''', (r_data['vehicleId'], stop['arrivalTime'], stop['deliveryId']))

    conn.commit()
    conn.close()

    return jsonify(result)

# ==================== INSTANT RECALCULATION ====================
@app.route('/api/recalculate', methods=['POST'])
def recalculate_metrics():
    """Recalculate fuel, costs, and emissions based on updated prices or vehicle fuel efficiencies without re-routing."""
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute('SELECT * FROM routes')
    routes = [dict(r) for r in cursor.fetchall()]

    cursor.execute('SELECT * FROM vehicles')
    vehicles = {v['vehicleId']: dict(v) for v in cursor.fetchall()}

    cursor.execute('SELECT key, value FROM settings')
    settings = {r['key']: r['value'] for r in cursor.fetchall()}

    price_diesel = float(settings.get('price_diesel', 92.50))
    price_petrol = float(settings.get('price_petrol', 104.20))
    price_cng = float(settings.get('price_cng', 86.50))
    price_electric = float(settings.get('price_electric', 12.00))

    emission_diesel = float(settings.get('emission_diesel', 2.68))
    emission_petrol = float(settings.get('emission_petrol', 2.31))
    emission_cng = float(settings.get('emission_cng', 1.82))
    emission_electric = float(settings.get('emission_electric', 0.45))

    def get_price(ft):
        ft = str(ft).lower()
        if 'petrol' in ft: return price_petrol
        if 'cng' in ft: return price_cng
        if 'electric' in ft or 'ev' in ft: return price_electric
        return price_diesel

    def get_emission(ft):
        ft = str(ft).lower()
        if 'petrol' in ft: return emission_petrol
        if 'cng' in ft: return emission_cng
        if 'electric' in ft or 'ev' in ft: return emission_electric
        return emission_diesel

    total_dist = 0.0
    total_fuel = 0.0
    total_cost = 0.0
    total_co2 = 0.0

    updated_routes = []
    for r in routes:
        vid = r['vehicleId']
        veh = vehicles.get(vid, {})
        eff = max(1.0, float(veh.get('fuelEfficiency', 14.0)))
        ft = veh.get('fuelType', 'Diesel')
        dist = float(r['totalDistance'])
        
        fuel_used = round(dist / eff, 2)
        fuel_cost = round(fuel_used * get_price(ft), 2)
        co2 = round(fuel_used * get_emission(ft), 2)

        cursor.execute('''
        UPDATE routes SET fuelUsed = ?, fuelCost = ?, co2 = ? WHERE id = ?
        ''', (fuel_used, fuel_cost, co2, r['id']))

        total_dist += dist
        total_fuel += fuel_used
        total_cost += fuel_cost
        total_co2 += co2

        updated_routes.append({
            "id": r['id'],
            "vehicleId": vid,
            "totalDistanceKm": dist,
            "fuelUsedLiters": fuel_used,
            "fuelCostInr": fuel_cost,
            "co2Kg": co2
        })

    conn.commit()

    cursor.execute('SELECT COUNT(*) FROM deliveries')
    deliv_count = cursor.fetchone()[0]
    conn.close()

    return jsonify({
        "success": True,
        "updatedRoutes": updated_routes,
        "analytics": {
            "totalDistanceKm": round(total_dist, 2),
            "totalFuelLiters": round(total_fuel, 2),
            "totalFuelCostInr": round(total_cost, 2),
            "totalCo2Kg": round(total_co2, 2),
            "costPerKm": round(total_cost / max(0.1, total_dist), 2) if total_dist > 0 else 0,
            "costPerDelivery": round(total_cost / max(1, deliv_count), 2)
        }
    })

# ==================== SETTINGS APIS ====================
@app.route('/api/settings', methods=['GET'])
def get_settings():
    return jsonify(get_app_settings())

DAILY_INDIAN_FUEL_RATES = {
    'Hyderabad': {'diesel': 95.65, 'petrol': 107.41, 'cng': 91.00, 'electric': 11.50, 'state': 'Telangana', 'updated': 'Today, 06:00 AM IST'},
    'Mumbai': {'diesel': 92.15, 'petrol': 104.21, 'cng': 86.00, 'electric': 13.20, 'state': 'Maharashtra', 'updated': 'Today, 06:00 AM IST'},
    'Delhi': {'diesel': 87.62, 'petrol': 94.72, 'cng': 79.50, 'electric': 10.00, 'state': 'Delhi NCR', 'updated': 'Today, 06:00 AM IST'},
    'Bengaluru': {'diesel': 88.94, 'petrol': 102.86, 'cng': 83.50, 'electric': 12.00, 'state': 'Karnataka', 'updated': 'Today, 06:00 AM IST'},
    'Chennai': {'diesel': 92.34, 'petrol': 100.75, 'cng': 87.00, 'electric': 12.80, 'state': 'Tamil Nadu', 'updated': 'Today, 06:00 AM IST'},
    'Kolkata': {'diesel': 90.76, 'petrol': 103.94, 'cng': 89.00, 'electric': 11.80, 'state': 'West Bengal', 'updated': 'Today, 06:00 AM IST'},
    'Pune': {'diesel': 90.50, 'petrol': 103.80, 'cng': 87.50, 'electric': 12.50, 'state': 'Maharashtra', 'updated': 'Today, 06:00 AM IST'},
    'Ahmedabad': {'diesel': 90.10, 'petrol': 94.44, 'cng': 82.00, 'electric': 11.20, 'state': 'Gujarat', 'updated': 'Today, 06:00 AM IST'}
}

@app.route('/api/fuel/daily-rates', methods=['GET', 'POST'])
def daily_fuel_rates_api():
    if request.method == 'POST':
        data = request.json or {}
        city = data.get('city', 'Hyderabad')
        rates = DAILY_INDIAN_FUEL_RATES.get(city, DAILY_INDIAN_FUEL_RATES['Hyderabad'])
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('price_diesel', ?)", (str(rates['diesel']),))
        cursor.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('price_petrol', ?)", (str(rates['petrol']),))
        cursor.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('price_cng', ?)", (str(rates['cng']),))
        cursor.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('price_electric', ?)", (str(rates['electric']),))
        conn.commit()
        conn.close()
        return jsonify({"success": True, "city": city, "rates": rates})
    else:
        city = request.args.get('city', 'Hyderabad')
        rates = DAILY_INDIAN_FUEL_RATES.get(city, DAILY_INDIAN_FUEL_RATES['Hyderabad'])
        return jsonify({"success": True, "city": city, "rates": rates, "all_cities": DAILY_INDIAN_FUEL_RATES})

@app.route('/api/settings', methods=['POST'])
def update_settings():
    data = request.json or {}
    conn = get_db()
    cursor = conn.cursor()
    for k, v in data.items():
        cursor.execute('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', (str(k), str(v)))
    conn.commit()
    conn.close()
    return jsonify({"success": True})

# ==================== EXPORT REPORTS ====================
@app.route('/api/reports/export', methods=['GET'])
def export_report():
    category = request.args.get('category', 'routes')
    conn = get_db()
    cursor = conn.cursor()

    output = io.StringIO()
    writer = csv.writer(output)

    if category == 'routes':
        writer.writerow(['Vehicle ID', 'Depot Name', 'Distance (km)', 'Travel Time (min)', 'Fuel Used (L)', 'Fuel Cost (INR)', 'CO2 (kg)', 'Status'])
        cursor.execute('''
        SELECT r.vehicleId, d.name as depotName, r.totalDistance, r.travelTime, r.fuelUsed, r.fuelCost, r.co2, r.routeStatus
        FROM routes r
        JOIN depots d ON r.depotId = d.id
        ''')
        for row in cursor.fetchall():
            writer.writerow([row['vehicleId'], row['depotName'], row['totalDistance'], row['travelTime'], row['fuelUsed'], row['fuelCost'], row['co2'], row['routeStatus']])
        filename = "india_logistics_routes_report.csv"

    elif category == 'vehicles':
        writer.writerow(['Vehicle ID', 'Type', 'Capacity (kg)', 'Fuel Type', 'Efficiency (km/L)', 'Driver ID', 'Driver Name', 'Driver Rating', 'Status'])
        cursor.execute('''
        SELECT v.vehicleId, v.vehicleType, v.capacity, v.fuelType, v.fuelEfficiency, v.status,
               dr.driverId, dr.name as driverName, dr.rating
        FROM vehicles v
        LEFT JOIN drivers dr ON v.driverId = dr.driverId
        ''')
        for row in cursor.fetchall():
            writer.writerow([row['vehicleId'], row['vehicleType'], row['capacity'], row['fuelType'], row['fuelEfficiency'], row['driverId'], row['driverName'], row['rating'], row['status']])
        filename = "india_fleet_vehicles_report.csv"

    elif category == 'deliveries':
        writer.writerow(['Order ID', 'Customer', 'Address', 'Product', 'Quantity', 'Weight (kg)', 'Priority', 'Time Window', 'Assigned Vehicle', 'Status', 'ETA'])
        cursor.execute('SELECT * FROM deliveries')
        for row in cursor.fetchall():
            tw = f"{row['timeWindowStart']} - {row['timeWindowEnd']}"
            writer.writerow([row['orderId'], row['customerName'], row['address'], row['product'], row['quantity'], row['weight'], row['priority'], tw, row['assignedVehicle'], row['status'], row['eta']])
        filename = "india_deliveries_report.csv"

    else:
        # Default fuel report
        writer.writerow(['Vehicle ID', 'Fuel Type', 'Fuel Efficiency', 'Total Distance (km)', 'Fuel Used (L)', 'Fuel Cost (INR)', 'CO2 (kg)'])
        cursor.execute('''
        SELECT r.vehicleId, v.fuelType, v.fuelEfficiency, r.totalDistance, r.fuelUsed, r.fuelCost, r.co2
        FROM routes r
        JOIN vehicles v ON r.vehicleId = v.vehicleId
        ''')
        for row in cursor.fetchall():
            writer.writerow([row['vehicleId'], row['fuelType'], row['fuelEfficiency'], row['totalDistance'], row['fuelUsed'], row['fuelCost'], row['co2']])
        filename = "india_fuel_emissions_report.csv"

    conn.close()
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-disposition": f"attachment; filename={filename}"}
    )

# ==================== DATASET FILES DOWNLOAD ====================
@app.route('/api/dataset/<filename>', methods=['GET'])
def download_dataset_file(filename):
    data_dir = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data'))
    return send_from_directory(data_dir, filename, as_attachment=True)

# ==================== DEMO SCENARIO & RESET ====================
@app.route('/api/demo/load', methods=['POST'])
def load_demo_scenario():
    """
    Pre-loads realistic multi-vehicle, multi-stop scenario (e.g. Hyderabad E-Commerce Hub).
    Satisfies Acceptance Test 1-15 instantly for quick demo and testing!
    """
    scenario_type = request.json.get('city', 'hyderabad') if request.json else 'hyderabad'
    conn = get_db()
    cursor = conn.cursor()

    # Clear previous
    cursor.execute('DELETE FROM vehicles')
    cursor.execute('DELETE FROM drivers')
    cursor.execute('DELETE FROM deliveries')
    cursor.execute('DELETE FROM routes')
    cursor.execute('DELETE FROM route_stops')

    if scenario_type == 'mumbai':
        # Mumbai Depot & deliveries
        cursor.execute("SELECT id FROM depots WHERE city = 'Mumbai' LIMIT 1")
        depot_id = cursor.fetchone()['id']
        depot_city = "Mumbai"
        
        sample_deliveries = [
            ("ORD-101", "Reliance Retail Hub", "BKC Bandra Kurla Complex, Mumbai", 19.0657, 72.8687, "Electronics", 4, 35, "Critical", "09:30", "12:30", 15),
            ("ORD-102", "Amazon Fulfillment Center", "Andheri East MIDC, Mumbai", 19.1136, 72.8697, "Retail Goods", 8, 48, "High", "10:00", "13:00", 10),
            ("ORD-103", "Tata Consumer Center", "Hiranandani Gardens, Powai, Mumbai", 19.1176, 72.9060, "Consumer Goods", 5, 25, "Medium", "11:00", "14:30", 12),
            ("ORD-104", "DMart Distribution Store", "Thane West Commercial Center, Maharashtra", 19.2183, 72.9781, "Groceries", 12, 120, "High", "10:30", "14:00", 15),
            ("ORD-105", "Flipkart Last-Mile Hub", "Vashi Commercial Sector, Navi Mumbai", 19.0330, 73.0297, "Apparel & Devices", 6, 40, "Medium", "12:00", "16:00", 10),
            ("ORD-106", "Godrej Enterprise", "Worli Sea Face Corridor, Mumbai", 19.0176, 72.8181, "Hardware", 3, 30, "Low", "13:00", "17:00", 10),
            ("ORD-107", "L&T Business Park", "Kurla West Cargo Depot, Mumbai", 19.0726, 72.8845, "Machinery Parts", 2, 75, "High", "10:00", "13:30", 15),
            ("ORD-108", "Croma Megastore", "Dadar Central Commercial Hub, Mumbai", 19.0178, 72.8478, "Home Appliances", 4, 90, "Critical", "09:00", "12:00", 20)
        ]
    else:
        # Hyderabad Depot & deliveries (Default)
        cursor.execute("SELECT id FROM depots WHERE city = 'Hyderabad' LIMIT 1")
        row = cursor.fetchone()
        depot_id = row['id'] if row else 1
        depot_city = "Hyderabad"

        sample_deliveries = [
            ("ORD-001", "Infosys Campus B9", "Gachibowli Financial District, Hyderabad", 17.4401, 78.3489, "Server Equipment", 5, 45, "Critical", "09:30", "12:00", 15),
            ("ORD-002", "Microsoft IDC Hub", "HITEC City, Madhapur, Hyderabad", 17.4474, 78.3762, "IT Peripherals", 8, 30, "High", "10:00", "13:00", 10),
            ("ORD-003", "Apollo Health Pharmacy", "Jubilee Hills Check Post, Hyderabad", 17.4325, 78.4071, "Pharmaceuticals", 12, 25, "Critical", "09:00", "11:30", 12),
            ("ORD-004", "Taj Falaknuma Supply", "Charminar Old City, Hyderabad", 17.3616, 78.4747, "Luxury Gourmet Goods", 6, 60, "Medium", "11:30", "15:00", 15),
            ("ORD-005", "Dr. Reddy's Lab Supply", "Begumpet Airport Road, Hyderabad", 17.4447, 78.4664, "Medical Consumables", 10, 40, "High", "10:30", "13:30", 10),
            ("ORD-006", "IKEA Delivery Center", "Kondapur, Hyderabad", 17.4699, 78.3578, "Furniture & Decor", 4, 110, "Medium", "12:00", "16:00", 20),
            ("ORD-007", "Secunderabad Rail Freight", "Secunderabad Station Area, Hyderabad", 17.4399, 78.4983, "Electronics Parts", 7, 50, "Low", "13:00", "17:00", 10),
            ("ORD-008", "BigBasket Megastore", "Kukatpally Housing Board Colony, Hyderabad", 17.4933, 78.4014, "Organic Produce", 15, 95, "High", "10:00", "13:00", 15),
            ("ORD-009", "Care Hospitals Medical Hub", "Road No. 12, Banjara Hills, Hyderabad", 17.4156, 78.4347, "Vaccines (Cold Chain)", 5, 20, "Critical", "09:15", "11:45", 10),
            ("ORD-010", "Nexus Mall Retail", "Kukatpally, Hyderabad", 17.4910, 78.3980, "Apparel Cartons", 10, 70, "Medium", "12:30", "16:30", 15),
            ("ORD-011", "T-Hub Innovation Park", "Madhapur, Hyderabad", 17.4483, 78.3915, "Prototype Hardware", 3, 18, "Medium", "11:00", "14:00", 10),
            ("ORD-012", "Ameerpet Tech Center", "Ameerpet Metro Station Hub, Hyderabad", 17.4375, 78.4482, "Training Kits", 6, 35, "Low", "14:00", "18:00", 10)
        ]

    # Create 3 realistic vehicles with auto-generated drivers
    fleet_configs = [
        ("V001", "Van", 1000.0, "Diesel", 14.0, 50.0, 650.0),
        ("V002", "Light Commercial Vehicle", 1500.0, "CNG", 16.5, 60.0, 500.0),
        ("V003", "EV Cargo Van", 800.0, "Electric", 6.5, 45.0, 280.0)
    ]

    for idx, (v_id, v_type, cap, fuel_type, eff, tank, max_r) in enumerate(fleet_configs, 1):
        driver = generate_driver(v_id, idx)
        cursor.execute('''
        INSERT INTO drivers (driverId, name, age, experience, phone, licenseType, rating, vehicleId, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (driver['driverId'], driver['name'], driver['age'], driver['experience'], driver['phone'], 
              driver['licenseType'], driver['rating'], driver['vehicleId'], driver['status']))

        cursor.execute('''
        INSERT INTO vehicles (vehicleId, vehicleType, capacity, currentLoad, fuelType, fuelEfficiency, 
                             fuelTankCapacity, maximumRange, depotId, driverId, status)
        VALUES (?, ?, ?, 0, ?, ?, ?, ?, ?, ?, 'Available')
        ''', (v_id, v_type, cap, fuel_type, eff, tank, max_r, depot_id, driver['driverId']))

    # Insert deliveries
    for order in sample_deliveries:
        cursor.execute('''
        INSERT INTO deliveries (orderId, customerName, address, latitude, longitude, product,
                               quantity, weight, priority, timeWindowStart, timeWindowEnd, serviceTime, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending')
        ''', order)

    conn.commit()
    conn.close()

    return jsonify({
        "success": True,
        "message": f"Successfully loaded demo scenario for {depot_city} with 3 vehicles, 3 auto-generated drivers, and {len(sample_deliveries)} deliveries!"
    })

@app.route('/api/reset', methods=['POST'])
def reset_all():
    """Reset all data to empty state as required by master prompt Section 47."""
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM vehicles')
    cursor.execute('DELETE FROM drivers')
    cursor.execute('DELETE FROM deliveries')
    cursor.execute('DELETE FROM routes')
    cursor.execute('DELETE FROM route_stops')
    conn.commit()
    conn.close()
    return jsonify({
        "success": True,
        "message": "Application reset to initial empty state (0 vehicles, 0 deliveries, 0 routes)."
    })

if __name__ == '__main__':
    print("=" * 60)
    print("QNAVIX — QUANTUM ROUTE INTELLIGENCE PLATFORM")
    print("Server starting at http://127.0.0.1:5000")
    print("=" * 60)
    app.run(host='0.0.0.0', port=5000, debug=False)
