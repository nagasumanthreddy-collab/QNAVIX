import requests
import json
import urllib.parse

# Comprehensive lookup of popular Indian locations & landmarks for instant offline fallback
KNOWN_INDIAN_LOCATIONS = {
    # Hyderabad
    "hyderabad": {"lat": 17.3850, "lng": 78.4867, "address": "Hyderabad, Telangana, India"},
    "hitec city": {"lat": 17.4474, "lng": 78.3762, "address": "HITEC City, Madhapur, Hyderabad, Telangana"},
    "madhapur": {"lat": 17.4483, "lng": 78.3915, "address": "Madhapur, Hyderabad, Telangana"},
    "gachibowli": {"lat": 17.4401, "lng": 78.3489, "address": "Gachibowli Financial District, Hyderabad, Telangana"},
    "kondapur": {"lat": 17.4699, "lng": 78.3578, "address": "Kondapur, Hyderabad, Telangana"},
    "kukatpally": {"lat": 17.4933, "lng": 78.4014, "address": "Kukatpally Housing Board Colony, Hyderabad, Telangana"},
    "banjara hills": {"lat": 17.4156, "lng": 78.4347, "address": "Road No. 12, Banjara Hills, Hyderabad, Telangana"},
    "jubilee hills": {"lat": 17.4325, "lng": 78.4071, "address": "Jubilee Hills Check Post, Hyderabad, Telangana"},
    "secunderabad": {"lat": 17.4399, "lng": 78.4983, "address": "Secunderabad Station Area, Hyderabad, Telangana"},
    "begumpet": {"lat": 17.4447, "lng": 78.4664, "address": "Begumpet Airport Road, Hyderabad, Telangana"},
    "charminar": {"lat": 17.3616, "lng": 78.4747, "address": "Charminar Old City, Hyderabad, Telangana"},
    "ameerpet": {"lat": 17.4375, "lng": 78.4482, "address": "Ameerpet Metro Station Hub, Hyderabad, Telangana"},
    "shamshabad": {"lat": 17.2403, "lng": 78.4294, "address": "RGIA Airport Cargo, Shamshabad, Hyderabad, Telangana"},
    
    # Mumbai MMR
    "mumbai": {"lat": 19.0760, "lng": 72.8777, "address": "Mumbai, Maharashtra, India"},
    "bhiwandi": {"lat": 19.2967, "lng": 73.0631, "address": "Bhiwandi Logistics Park, Thane, Mumbai MMR"},
    "andheri": {"lat": 19.1136, "lng": 72.8697, "address": "Andheri East MIDC, Mumbai, Maharashtra"},
    "bandra": {"lat": 19.0596, "lng": 72.8295, "address": "BKC Bandra Kurla Complex, Mumbai, Maharashtra"},
    "bkc": {"lat": 19.0657, "lng": 72.8687, "address": "Bandra Kurla Complex (BKC), Mumbai, Maharashtra"},
    "thane": {"lat": 19.2183, "lng": 72.9781, "address": "Thane West Commercial Center, Maharashtra"},
    "navi mumbai": {"lat": 19.0330, "lng": 73.0297, "address": "Vashi Commercial Sector, Navi Mumbai, Maharashtra"},
    "powai": {"lat": 19.1176, "lng": 72.9060, "address": "Hiranandani Gardens, Powai, Mumbai, Maharashtra"},
    "dadar": {"lat": 19.0178, "lng": 72.8478, "address": "Dadar Central Commercial Hub, Mumbai, Maharashtra"},
    "worli": {"lat": 19.0176, "lng": 72.8181, "address": "Worli Sea Face Corridor, Mumbai, Maharashtra"},
    "kurla": {"lat": 19.0726, "lng": 72.8845, "address": "Kurla West Cargo Depot, Mumbai, Maharashtra"},
    
    # Bengaluru
    "bengaluru": {"lat": 12.9716, "lng": 77.5946, "address": "Bengaluru, Karnataka, India"},
    "bangalore": {"lat": 12.9716, "lng": 77.5946, "address": "Bengaluru, Karnataka, India"},
    "koramangala": {"lat": 12.9352, "lng": 77.6245, "address": "Koramangala 4th Block, Bengaluru, Karnataka"},
    "indiranagar": {"lat": 12.9784, "lng": 77.6408, "address": "100 Feet Road, Indiranagar, Bengaluru, Karnataka"},
    "whitefield": {"lat": 12.9698, "lng": 77.7500, "address": "ITPB Whitefield, Bengaluru, Karnataka"},
    "electronic city": {"lat": 12.8452, "lng": 77.6602, "address": "Electronic City Phase 1, Bengaluru, Karnataka"},
    "marathahalli": {"lat": 12.9591, "lng": 77.6974, "address": "Outer Ring Road, Marathahalli, Bengaluru, Karnataka"},
    "hebbal": {"lat": 13.0358, "lng": 77.5970, "address": "Hebbal Flyover Junction, Bengaluru, Karnataka"},
    "jayanagar": {"lat": 12.9308, "lng": 77.5838, "address": "Jayanagar 4th Block, Bengaluru, Karnataka"},
    "peenya": {"lat": 13.0285, "lng": 77.5197, "address": "Peenya Industrial Area, Bengaluru, Karnataka"},
    
    # Delhi NCR
    "delhi": {"lat": 28.6139, "lng": 77.2090, "address": "New Delhi, Delhi, India"},
    "connaught place": {"lat": 28.6315, "lng": 77.2167, "address": "Connaught Place Inner Circle, New Delhi"},
    "okhla": {"lat": 28.5355, "lng": 77.2731, "address": "Okhla Industrial Area Phase-III, New Delhi"},
    "gurugram": {"lat": 28.4595, "lng": 77.0266, "address": "Cyber City DLF Phase 2, Gurugram, Haryana"},
    "noida": {"lat": 28.5355, "lng": 77.3910, "address": "Sector 18 Commercial Hub, Noida, Uttar Pradesh"},
    "dwarka": {"lat": 28.5921, "lng": 77.0460, "address": "Sector 12 City Center, Dwarka, New Delhi"},
    "nehru place": {"lat": 28.5494, "lng": 77.2536, "address": "Nehru Place IT Market, New Delhi"},
    "rohani": {"lat": 28.7166, "lng": 77.1136, "address": "Sector 8 Commercial Complex, Rohini, New Delhi"},
    
    # Chennai
    "chennai": {"lat": 13.0827, "lng": 80.2707, "address": "Chennai, Tamil Nadu, India"},
    "guindy": {"lat": 13.0067, "lng": 80.2025, "address": "Guindy Industrial Estate, Chennai, Tamil Nadu"},
    "omr": {"lat": 12.9249, "lng": 80.2279, "address": "Old Mahabalipuram Road IT Expressway, Chennai"},
    "t nagar": {"lat": 13.0418, "lng": 80.2341, "address": "T. Nagar Commercial Hub, Chennai, Tamil Nadu"},
    "ambattur": {"lat": 13.1143, "lng": 80.1548, "address": "Ambattur Industrial Estate, Chennai, Tamil Nadu"},
    
    # Pune
    "pune": {"lat": 18.5204, "lng": 73.8567, "address": "Pune, Maharashtra, India"},
    "hinjewadi": {"lat": 18.5913, "lng": 73.7389, "address": "Rajiv Gandhi Infotech Park, Hinjewadi, Pune"},
    "viman nagar": {"lat": 18.5679, "lng": 73.9143, "address": "Viman Nagar Commercial Area, Pune, Maharashtra"},
    "hadapsar": {"lat": 18.5089, "lng": 73.9260, "address": "Magarpatta Cybercity, Hadapsar, Pune, Maharashtra"},
    
    # Andhra Pradesh & Others
    "visakhapatnam": {"lat": 17.6868, "lng": 83.2185, "address": "Visakhapatnam Port City, Andhra Pradesh"},
    "vijayawada": {"lat": 16.5062, "lng": 80.6480, "address": "MG Road Logistics Corridor, Vijayawada, Andhra Pradesh"},
    "guntur": {"lat": 16.3067, "lng": 80.4365, "address": "Brodipet Commercial Center, Guntur, Andhra Pradesh"},
    "kolkata": {"lat": 22.5726, "lng": 88.3639, "address": "Kolkata, West Bengal, India"},
    "ahmedabad": {"lat": 23.0225, "lng": 72.5714, "address": "Ahmedabad, Gujarat, India"},
    "surat": {"lat": 21.1702, "lng": 72.8311, "address": "Surat, Gujarat, India"},
    "jaipur": {"lat": 26.9124, "lng": 75.7873, "address": "Jaipur, Rajasthan, India"},
    "lucknow": {"lat": 26.8467, "lng": 80.9462, "address": "Hazratganj, Lucknow, Uttar Pradesh"},
    "chandigarh": {"lat": 30.7333, "lng": 76.7794, "address": "Sector 17 City Centre, Chandigarh"}
}

def geocode_address(query, google_api_key=None):
    """
    Geocode an Indian address or city using:
    1. Google Geocoding API (if key provided)
    2. Local verified Indian landmarks & city directory
    3. OpenStreetMap / Photon / Nominatim API
    """
    clean_query = query.strip()
    if not clean_query:
        return None

    # Check 1: Google Geocoding API if key is present
    if google_api_key:
        try:
            url = f"https://maps.googleapis.com/maps/api/geocode/json?address={urllib.parse.quote(clean_query + ', India')}&key={google_api_key}"
            res = requests.get(url, timeout=4)
            if res.status_code == 200:
                data = res.json()
                if data.get("status") == "OK" and len(data.get("results", [])) > 0:
                    first = data["results"][0]
                    loc = first["geometry"]["location"]
                    return {
                        "address": first.get("formatted_address", clean_query),
                        "latitude": loc["lat"],
                        "longitude": loc["lng"],
                        "source": "google"
                    }
        except Exception as e:
            print(f"Google Geocode error: {e}")

    # Check 2: Known Indian locations dictionary (exact or substring match)
    q_lower = clean_query.lower()
    for key, val in KNOWN_INDIAN_LOCATIONS.items():
        if key in q_lower or q_lower in key:
            return {
                "address": val["address"],
                "latitude": val["lat"],
                "longitude": val["lng"],
                "source": "local_db"
            }

    # Check 3: Free Nominatim / OSM Geocoder with India countrycode
    try:
        headers = {'User-Agent': 'IndiaRouteOptimizer/1.0 (logistics-platform@internal)'}
        url = f"https://nominatim.openstreetmap.org/search?q={urllib.parse.quote(clean_query)}&format=json&countrycodes=in&limit=1"
        res = requests.get(url, headers=headers, timeout=3)
        if res.status_code == 200:
            results = res.json()
            if results and len(results) > 0:
                first = results[0]
                return {
                    "address": first.get("display_name", clean_query),
                    "latitude": float(first["lat"]),
                    "longitude": float(first["lon"]),
                    "source": "osm"
                }
    except Exception as e:
        print(f"OSM Geocode error: {e}")

    # Fallback: Hash-based geographic jitter near central Indian coordinates if all else fails
    # This prevents the app from crashing even if offline without internet!
    hash_val = abs(hash(clean_query)) % 1000
    lat_offset = (hash_val % 40 - 20) * 0.01
    lng_offset = ((hash_val // 40) % 40 - 20) * 0.01
    
    return {
        "address": f"{clean_query}, India",
        "latitude": 17.4065 + lat_offset,
        "longitude": 78.4772 + lng_offset,
        "source": "estimated"
    }

def search_places_suggestions(query, google_api_key=None):
    """Return autocomplete suggestions for Indian locations."""
    clean_query = query.strip().lower()
    if not clean_query:
        return []

    suggestions = []
    # Match local database
    for key, val in KNOWN_INDIAN_LOCATIONS.items():
        if clean_query in key or key in clean_query:
            suggestions.append({
                "title": key.title(),
                "address": val["address"],
                "lat": val["lat"],
                "lng": val["lng"]
            })
            if len(suggestions) >= 6:
                return suggestions

    # Also query Photon / OSM if needed
    try:
        url = f"https://photon.komoot.io/api/?q={urllib.parse.quote(clean_query)}&limit=5&lat=20.5937&lon=78.9629"
        res = requests.get(url, timeout=2.5)
        if res.status_code == 200:
            data = res.json()
            for feature in data.get("features", []):
                props = feature.get("properties", {})
                coords = feature.get("geometry", {}).get("coordinates", [])
                if len(coords) == 2:
                    name = props.get("name", "")
                    city = props.get("city", props.get("state", ""))
                    country = props.get("country", "")
                    if name:
                        suggestions.append({
                            "title": name,
                            "address": f"{name}, {city}, {country}".strip(", "),
                            "lat": coords[1],
                            "lng": coords[0]
                        })
    except Exception:
        pass

    return suggestions[:6]

def reverse_geocode(lat, lng, google_api_key=None):
    """Resolve human-readable address from latitude and longitude coordinates in India."""
    try:
        lat = float(lat)
        lng = float(lng)
    except Exception:
        return {"address": "Selected Location, India", "latitude": lat, "longitude": lng}

    # 1. Google Reverse Geocode if key available
    if google_api_key:
        try:
            url = f"https://maps.googleapis.com/maps/api/geocode/json?latlng={lat},{lng}&key={google_api_key}"
            res = requests.get(url, timeout=3.5)
            if res.status_code == 200:
                data = res.json()
                if data.get("status") == "OK" and len(data.get("results", [])) > 0:
                    return {
                        "address": data["results"][0].get("formatted_address", f"Lat: {lat:.4f}, Lng: {lng:.4f}"),
                        "latitude": lat,
                        "longitude": lng,
                        "source": "google"
                    }
        except Exception:
            pass

    # 2. OpenStreetMap Nominatim Reverse Geocoding
    try:
        headers = {'User-Agent': 'IndiaRouteOptimizer/1.0 (logistics-platform@internal)'}
        url = f"https://nominatim.openstreetmap.org/reverse?lat={lat}&lon={lng}&format=json"
        res = requests.get(url, headers=headers, timeout=3.0)
        if res.status_code == 200:
            data = res.json()
            if "display_name" in data:
                return {
                    "address": data["display_name"],
                    "latitude": lat,
                    "longitude": lng,
                    "source": "osm"
                }
    except Exception:
        pass

    # 3. Nearest landmark lookup from local dictionary
    import math
    nearest_loc = None
    min_dist = float('inf')
    for name, loc in KNOWN_INDIAN_LOCATIONS.items():
        d = math.hypot(lat - loc['lat'], lng - loc['lng'])
        if d < min_dist:
            min_dist = d
            nearest_loc = loc

    if nearest_loc and min_dist < 0.25:
        return {
            "address": f"Near {nearest_loc['address']}",
            "latitude": lat,
            "longitude": lng,
            "source": "local_nearest"
        }

    return {
        "address": f"Location ({lat:.4f}°N, {lng:.4f}°E), India",
        "latitude": lat,
        "longitude": lng,
        "source": "coordinates"
    }

